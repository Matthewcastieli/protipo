# Projecte Solidari · El Far

El Far is a Laravel 12 web app with an installable PWA interface for creating and viewing local safety alerts. This is an educational demo, not an emergency service. Call 112 directly in an immediate emergency.

## Quick start

```bash
cp .env.example .env
touch database/database.sqlite
composer install
php artisan key:generate
php artisan migrate
php artisan serve
```

Visit `http://127.0.0.1:8000`. Keep the terminal open while using the app.

The public home page displays an OpenStreetMap with active alerts and refreshes the feed every 20 seconds; visitors can also refresh it manually. The map uses Leaflet and OpenStreetMap tiles, so displaying the street map requires an internet connection. “Els meus avisos” combines synced account alerts with drafts stored only on the current browser/device; drafts can be edited and removed locally. Submitted alerts are visible to everyone but cannot be edited or deleted by the reporter.

Creating a regular account is optional. Accounts use an email address and a password of at least 10 characters; passwords are stored as hashes. Alerts sent while signed in are linked to that account and their current status appears in “Els meus avisos” across devices. Anonymous reports remain available and their local drafts stay on the device. Public visitors are not shown an administrator link; the separate administrator sign-in remains available directly at `/admin/login` and uses the configured administrator credentials.

### Private follow-up for alerts

For alerts submitted by a reporter, “Els meus avisos” provides a private, alert-specific message thread with the El Far team. Only the matching reporter browser (or the signed-in account that owns the alert) can open the reporter page; access to its message API additionally requires a random, per-alert, HttpOnly cookie token. The database stores only a hash of this access token, and administrators can view and reply from the alert dashboard. Reporter identity and administrator email are not returned in the reporter message API.

This is pseudonymous follow-up, not guaranteed anonymity or end-to-end encryption. The alert itself may contain identifying details, signed-in alerts are associated with their account, and the server/database administrators can access stored alert and conversation data. Browser cookies are needed to retain anonymous access; clearing them may prevent access from that browser. Do not send passwords, banking details, or information you do not want the service team to see. This channel is not for emergencies; call 112 for immediate danger.

## Requirements

- PHP 8.2 or newer with `mbstring`, `pdo_sqlite`, `openssl`, and `fileinfo`
- Composer 2
- A writable `database/` directory (SQLite database file) and writable `storage/` directory

## Install and run

From the project root:

```bash
cp .env.example .env
touch database/database.sqlite
composer install
php artisan key:generate
php artisan migrate
php artisan serve
```

If `.env` or `database/database.sqlite` already exists, skip its corresponding copy/create command. Visit `http://127.0.0.1:8000`. Keep the terminal open while using the app.

Run the feature tests with:

```bash
composer test
```

### Install on Linux / macOS

Open a terminal in the project folder and run:

```bash
cp .env.example .env
touch database/database.sqlite
composer install
php artisan key:generate
php artisan migrate
php artisan serve
```

Visit `http://127.0.0.1:8000`. On macOS, if `php` is not found, install it via Homebrew (`brew install php`) or use Laravel Herd. Ensure the `mbstring`, `pdo_sqlite`, `openssl`, and `fileinfo` PHP extensions are enabled.

### Install on Windows

Run these commands in PowerShell from the project root:

```powershell
Copy-Item .env.example .env
New-Item -ItemType File -Path database\database.sqlite
composer install
php artisan key:generate
php artisan migrate
php artisan serve
```

Visit `http://127.0.0.1:8000`. Keep the terminal open while using the app.

## Production deployment

For a publicly reachable instance:

1. Set `APP_ENV=production` and `APP_DEBUG=false` in `.env`.
2. Generate a strong `APP_KEY` (`php artisan key:generate`).
3. Choose unique, strong administrator credentials and set `ALERT_ADMIN_EMAIL` and `ALERT_ADMIN_PASSWORD` in `.env`. Do not commit real credentials to source control.
4. Point your web server document root at the project's `public/` directory and serve over HTTPS (required for geolocation and PWA features on phones).
5. Optimize for production:

```bash
composer install --optimize-autoloader --no-dev
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

6. Protect the admin login and API endpoints with infrastructure-level rate limiting / DDoS controls. Urgent alerts bypass the application-level throttle so emergency reports cannot be blocked by it.

Run `php artisan config:clear`, `route:clear`, and `view:clear` if you change configuration or routes after caching.

## Project structure

- `app\Http\Controllers\HomeController.php` — reads database alerts for the server-rendered home page.
- `app\Http\Controllers\Account\` — regular account registration, sign-in, and private alert listing.
- `app\Http\Controllers\Api\AlertController.php` — validates and serves alert API requests.
- `app\Http\Controllers\Admin\AlertManagementController.php` — filters alerts and updates their status.
- `app\Http\Controllers\Admin\AdminLoginController.php` — manages administrator sign-in.
- `app\Models\Alert.php` and `app\Models\User.php` — alert and regular-account models.
- `database\migrations\` — alert table schema.
- `resources\views\home.blade.php` — Blade app page.
- `routes\web.php` and `routes\api.php` — web and JSON API routes.
- `public\css` and `public\js` — app styles and browser behavior.
- `public\css\chat.css` and `public\js\chat.js` — chat-specific styles and polling client.
- `resources\views\chat\` — Blade views for conversations, help requests, and workers listing.
- `public\icons`, `public\manifest.webmanifest`, and `public\sw.js` — PWA install and offline assets.
- `public\index.php` — Laravel web entry point.

Laravel stores alert data in SQLite by default. Change `.env` and `config\database.php` to use another supported database. Existing browser-local drafts stay in that browser; the old JSON storage is no longer used.

The SQLite connection uses WAL journal mode with a 5-second busy timeout and `synchronous=normal` by default (configurable via `DB_JOURNAL_MODE`, `DB_BUSY_TIMEOUT`, and `DB_SYNCHRONOUS` in `.env`). This improves concurrent read/write performance on Windows, Linux, and macOS.

### Performance

- The active-alert migration adds a composite index on `(status, received_at)` so the public feed query stays fast as data grows.
- The public map/API feed is bounded at 100 alerts per page so memory stays predictable.
- Re-running `analyze()` on an existing alert updates its single `AlertVerification` record instead of inserting duplicates.
- `NearbyAlertMatcher` pre-filters duplicate incident descriptions by category before running string similarity, keeping the matcher fast even when many nearby alerts share a category.
- Run `composer install --optimize-autoloader --no-dev` plus `config:cache`, `route:cache`, and `view:cache` for production (see Production deployment above).

## Alert status and verification management

Set `ALERT_ADMIN_EMAIL` and `ALERT_ADMIN_PASSWORD` in `.env` to enable the administrator dashboard at `/admin/login`. Use a unique, strong password and keep these credentials out of source control. The dashboard is session-protected and rate-limits sign-in attempts. Administrators can filter alerts and set their status to Open, Checking, Resolved, Verification, or False. Newly submitted alerts start as Open; Resolved and False alerts no longer appear in the public active-alert feed.

A dedicated **Avisos resolts** (resolved alerts) archive is available at `/admin/alerts/resolved`, showing only alerts with status Resolved or False, with filters by category, confidence, urgency, and date range, plus the human verification decision and resolution timestamp for each entry. Navigate to it from the main administration dashboard.

### Local testing accounts

The following credentials are for local testing only. Do not use them on a public or production deployment.

| Account | Email | Password | Setup |
|---|---|---|---|
| Administrator | `admin@example.test` | `ElFar-Admin-Local-2026!` | Put these values in `ALERT_ADMIN_EMAIL` and `ALERT_ADMIN_PASSWORD` in `.env`, then restart the Laravel server. Sign in at `http://127.0.0.1:8000/admin/login`. |
| Regular user | `usuari.prova@example.test` | `ElFar-User-Local-2026!` | Create this account at `http://127.0.0.1:8000/account/register`; regular accounts are not created automatically. |

For PowerShell setup, open `.env` with `notepad .env`, set the administrator values, save, and restart `php artisan serve`. The regular account can then be registered through the browser form. Choose different credentials before deploying or sharing a publicly reachable instance.

The admin panel also shows an explainable confidence score, GPS accuracy, nearby matching alerts, missing evidence, and the latest human verification decision. Staff can record Confirmed, False report, or Inconclusive with notes. The algorithmic confidence is only a triage aid: it never changes the alert status or replaces a human decision.

Confidence uses configurable weights in `config\alert_verification.php`: reporter reliability 25%, nearby incidents 25%, GPS quality 30%, time relevance 10%, and category similarity 10%. Available components are reweighted proportionally when evidence is missing. GPS accuracy is prioritized using the device-reported accuracy in meters: ≤20m scores 100, ≤50m scores 90, ≤100m scores 75, ≤250m scores 55, less precise reports score 20, and accuracy worse than 5km scores 0. Nearby matching requires both alerts to have reported GPS accuracy within 500m. These thresholds and classification cutoffs are configurable. The Haversine matcher searches within 2km and 24 hours, gives stronger proximity weight within 500m, excludes alerts from the same anonymous browser identity, and clusters near-identical descriptions to reduce duplicate corroboration.

Reporter reliability uses the smoothed formula `((confirmed + 5) / (verified + 10)) * 100`; only the latest Confirmed or False report decision per alert affects it. New reporters begin at 50. The reporter identity is an encrypted, HttpOnly, SameSite cookie, not an authenticated account: clearing browser cookies or changing devices creates a new pseudonymous identity, so reliability is a weak signal rather than verified identity.

Non-urgent alert submission is limited to 10 requests per minute per IP. Urgent alerts bypass that application-level throttle so automated limits cannot prevent them from being received; protect deployments with infrastructure-level DDoS controls that do not discard individual emergency reports. All requests validate IDs, categories, coordinate pairs, and accuracy, and never overwrite an existing alert ID. Urgent alerts are stored even when GPS is unavailable. The public map/API rounds coordinates to roughly 100m and omits reporter names and GPS accuracy; authorized administrators retain exact location and accuracy for review. GPS accuracy is browser-reported and can be spoofed, so it is prioritization evidence, not proof.

No external news or municipal source is configured. `ExternalEvidenceService` explicitly reports that evidence as unavailable; no network request or paid API is used. Missing external reports do not lower confidence, and urgent submissions do not wait for external lookups. Connect only documented, authorized public feeds in a separate non-blocking integration when a source is selected.

## Chat system and help requests

Registered users can start one-to-one conversations with other users, workers, and volunteers. Conversations are listed at `/chat`, and opening a conversation shows its message history with a compose box for sending new messages. Messages poll the server every 4 seconds for new replies. Each conversation shows participant names and roles so you know who you are talking to.

### User roles

Every account has a role that determines what they can do:

| Role | Description |
|------|-------------|
| `user` | Regular reporter. Can read and send messages in conversations they join. |
| `worker` | Staff member. Can view and respond to help requests, close them, and list workers/volunteers. |
| `volunteer` | Can create “I need help” requests and respond to them. |
| `admin` | Full staff access to help requests and the admin dashboard. |

New accounts register as `user`. Roles are stored on the `users` table and can be changed by an administrator directly in the database.

### Help requests (“Volunteers need help”)

Workers and volunteers can create a help request at `/chat/help-requests` to signal they need assistance. Any logged-in user can see their own help requests; workers and admins can see all help requests. Responses can be posted on open help requests, and the owner or a worker/admin can close a resolved request.

A new conversation can also be started directly from the workers/volunteers page (`/chat/workers`, staff only) by selecting a person and sending an opening message.

### API

All chat endpoints live under `/api/chat/*` and require an active web session:

- `GET /api/chat/conversations` — list your conversations
- `POST /api/chat/conversations` — create a conversation (`participant_ids`, `body`)
- `GET /api/chat/conversations/{id}` — view a conversation with messages and participants
- `GET /api/chat/conversations/{id}/messages` — list messages in a conversation
- `POST /api/chat/conversations/{id}/messages` — send a message (`body`)
- `GET /api/chat/users` — list other users (for starting conversations)
- `GET /api/chat/help-requests` — list help requests (own, or all if staff)
- `POST /api/chat/help-requests` — create a help request (worker/volunteer only; `title`, `description`, `category`)
- `GET /api/chat/help-requests/{id}/responses` — list responses on a help request
- `POST /api/chat/help-requests/{id}/respond` — post a response (`body`)
- `POST /api/chat/help-requests/{id}/close` — close a help request

## Install on Android or iOS

Deploy the Laravel app to a PHP host over HTTPS, with the web server document root pointed at the project's `public\` directory. HTTPS is required for reliable geolocation and service-worker/PWA features on phones. Android users can choose Chrome's Install/Add to Home Screen option; iOS users can choose Safari's Share → Add to Home Screen. PNG app icons and Apple touch icons are provided for broad launcher support. The page also shows device-specific install help when the browser does not support the native install prompt. This creates an installable PWA, not a Play Store APK or App Store IPA. The Laravel server and database must remain available for shared alerts.

The app stores user-submitted alerts on the server. It does not notify El Far or emergency services, and it does not call 112. Photos and audio are not uploaded.

## Front-end assets

Readable sources live in `resources/assets/{js,css}`. The files served from `public/` (`js/*.js`, `css/*.css`, `sw.js`) are minified builds of them, so **edit the sources, not `public/`**, then rebuild:

```bash
npm install
npm run build
```

Bump the `?v=` query string in the Blade views (and `CACHE` in `resources/assets/js/sw.js`) whenever an asset changes, so installed PWAs pick up the new files.

## Chat without logging in

Opening `/chat` gives the visitor an anonymous identity (shown as "Anònim A1B2C3"). A random secret is kept in an HttpOnly `far_chat` cookie; only its SHA-256 hash is stored in `users.access_hash`. Anonymous visitors can message the team (worker/volunteer/admin) but cannot see or message each other, and new identities are limited to 20 per hour per IP. Staff accounts still need a normal login. Registering from a device with an anonymous identity converts it into a real account and keeps its conversations.

After deploying run `php artisan migrate`. Unused anonymous identities are pruned daily by `chat:prune-anonymous`, which needs the scheduler (`* * * * * php artisan schedule:run`).
