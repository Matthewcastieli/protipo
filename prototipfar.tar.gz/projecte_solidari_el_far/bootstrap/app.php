<?php

use App\Http\Middleware\EnsureAlertAdmin;
use App\Http\Middleware\EnsureAccountUser;
use App\Http\Middleware\EnsureChatUser;
use App\Http\Middleware\AssignAlertReporter;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
  ->withRouting(
    web: __DIR__ . '/../routes/web.php',
    api: __DIR__ . '/../routes/api.php',
    commands: __DIR__ . '/../routes/console.php',
    health: '/up',
  )
  ->withMiddleware(function (Middleware $middleware): void {
    $middleware->alias([
      'alert.admin' => EnsureAlertAdmin::class,
      'account.user' => EnsureAccountUser::class,
      'chat.user' => EnsureChatUser::class,
      'alert.reporter' => AssignAlertReporter::class,
    ]);
  })
  ->withExceptions(function (Exceptions $exceptions): void {
    //
  })
  ->create();
