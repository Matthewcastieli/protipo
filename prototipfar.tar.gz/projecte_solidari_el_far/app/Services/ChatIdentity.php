<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Cookie;

/**
 * Passwordless chat identity.
 *
 * A visitor holds a random 256-bit secret in an HttpOnly cookie. Only its SHA-256 hash (the "user hash")
 * is stored in users.access_hash, so a leaked database cannot be used to impersonate anyone.
 */
final class ChatIdentity
{
  public const COOKIE = 'far_chat';
  public const MAX_NEW_PER_HOUR = 20;
  private const LIFETIME_MINUTES = 60 * 24 * 365;

  public static function hash(string $token): string
  {
    return hash('sha256', $token);
  }

  public static function find(Request $request): ?User
  {
    $token = $request->cookie(self::COOKIE);

    if (!is_string($token) || !preg_match('/^[0-9a-f]{64}$/', $token)) {
      return null;
    }

    return User::query()
      ->where('access_hash', self::hash($token))
      ->where('role', 'user')
      ->first();
  }

  /**
   * @return array{0: User, 1: string} the new anonymous user and the secret token for the cookie
   */
  public static function create(): array
  {
    $token = bin2hex(random_bytes(32));
    $hash = self::hash($token);

    $user = (new User())->forceFill([
      'name' => 'Anònim ' . strtoupper(substr($hash, 0, 6)),
      // users.email is unique and required, so anonymous accounts get a placeholder that can never receive mail.
      'email' => $hash . '@anonymous.invalid',
      'password' => bcrypt(Str::random(64), ['rounds' => 4]),
      'role' => 'user',
      'access_hash' => $hash,
    ]);
    $user->save();

    return [$user, $token];
  }

  public static function cookie(string $token, bool $secure): Cookie
  {
    return cookie(self::COOKIE, $token, self::LIFETIME_MINUTES, '/', null, $secure, true, false, 'lax');
  }
}
