<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class ReporterReliabilityService
{
  public function score(?string $reporterId): array
  {
    if ($reporterId === null) {
      return ['score' => 50, 'verified' => 0, 'confirmed' => 0];
    }

    $latestResults = DB::table('alert_verification_results as candidate')
      ->join('alerts as reporter_alerts', 'reporter_alerts.id', '=', 'candidate.alert_id')
      ->where('reporter_alerts.reporter_id', $reporterId)
      ->selectRaw('MAX(candidate.id) AS id')
      ->groupBy('candidate.alert_id');

    $totals = DB::table('alert_verification_results as results')
      ->joinSub($latestResults, 'latest', static fn ($join) => $join->on('results.id', '=', 'latest.id'))
      ->whereIn('result', ['confirmed', 'false_report'])
      ->selectRaw("COUNT(*) AS verified, SUM(CASE WHEN results.result = 'confirmed' THEN 1 ELSE 0 END) AS confirmed")
      ->first();

    $verified = (int) ($totals->verified ?? 0);
    $confirmed = (int) ($totals->confirmed ?? 0);

    return [
      'score' => (int) round((($confirmed + 5) / ($verified + 10)) * 100),
      'verified' => $verified,
      'confirmed' => $confirmed,
    ];
  }
}
