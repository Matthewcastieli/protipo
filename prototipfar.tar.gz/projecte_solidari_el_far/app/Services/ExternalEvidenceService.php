<?php

namespace App\Services;

use App\Models\Alert;

class ExternalEvidenceService
{
  public function analyze(Alert $alert): array
  {
    return [
      'status' => 'unavailable',
      'sources' => [],
      'reason' => 'No s’ha configurat cap font externa autoritzada.',
    ];
  }
}
