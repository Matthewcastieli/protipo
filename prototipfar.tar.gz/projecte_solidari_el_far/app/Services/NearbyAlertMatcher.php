<?php

namespace App\Services;

use App\Models\Alert;
use Carbon\CarbonInterface;

class NearbyAlertMatcher
{
  public function analyze(Alert $alert): array
  {
    $maximumAccuracy = (int) config('alert_verification.nearby.matching_max_accuracy_meters', 500);
    if (
      $alert->latitude === null
      || $alert->longitude === null
      || $alert->accuracy === null
      || $alert->accuracy > $maximumAccuracy
    ) {
      return [
        'available' => false,
        'matches' => [],
        'independent_count' => 0,
        'nearby_score' => null,
        'temporal_score' => null,
        'category_score' => null,
      ];
    }

    $radius = (float) config('alert_verification.nearby.maximum_radius_meters', 2000);
    $latDelta = $radius / 111320;
    $longitudeScale = max(0.01, cos(deg2rad((float) $alert->latitude)));
    $lngDelta = $radius / (111320 * $longitudeScale);
    $reporterId = $alert->reporter_id;
    $lookback = now()->subHours((int) config('alert_verification.nearby.lookback_hours', 24));

    $candidates = Alert::query()
      ->select([
        'id',
        'category',
        'description',
        'received_at',
        'reporter_id',
        'latitude',
        'longitude',
      ])
      ->whereKeyNot($alert->getKey())
      ->whereNotNull('latitude')
      ->whereNotNull('longitude')
      ->whereNotNull('accuracy')
      ->where('accuracy', '<=', $maximumAccuracy)
      ->where('received_at', '>=', $lookback)
      ->whereBetween('latitude', [$alert->latitude - $latDelta, $alert->latitude + $latDelta])
      ->whereBetween('longitude', [$alert->longitude - $lngDelta, $alert->longitude + $lngDelta])
      ->when($reporterId !== null, static fn ($query) => $query->where('reporter_id', '!=', $reporterId))
      ->orderByDesc('received_at')
      ->limit(100)
      ->get();

    $matches = $candidates
      ->map(function (Alert $candidate) use ($alert, $radius): ?array {
        $distance = $this->distanceMeters(
          (float) $alert->latitude,
          (float) $alert->longitude,
          (float) $candidate->latitude,
          (float) $candidate->longitude
        );

        if ($distance > $radius) {
          return null;
        }

        return [
          'id' => $candidate->id,
          'category' => $candidate->category,
          'description' => $candidate->description,
          'distance_meters' => (int) round($distance),
          'received_at' => $candidate->received_at?->toIso8601String(),
          'reporter_id' => $candidate->reporter_id,
          'same_category' => $candidate->category === $alert->category,
          'time_score' => $this->temporalScore($candidate->received_at, $alert->received_at),
        ];
      })
      ->filter()
      ->values()
      ->all();

    $independentMatches = $this->removeDuplicateIncidents($matches);
    $sameCategoryMatches = array_values(array_filter(
      $independentMatches,
      static fn (array $match): bool => $match['same_category']
    ));

    return [
      'available' => true,
      'matches' => array_map(static function (array $match): array {
        unset($match['reporter_id']);
        return $match;
      }, $independentMatches),
      'independent_count' => count($independentMatches),
      'nearby_score' => $this->nearbyScore($sameCategoryMatches),
      'temporal_score' => $independentMatches === []
        ? null
        : (int) round(array_sum(array_column($independentMatches, 'time_score')) / count($independentMatches)),
      'category_score' => $independentMatches === []
        ? null
        : (int) round(count($sameCategoryMatches) / count($independentMatches) * 100),
    ];
  }

  private function distanceMeters(float $lat1, float $lng1, float $lat2, float $lng2): float
  {
    $earthRadius = 6371000;
    $latDelta = deg2rad($lat2 - $lat1);
    $lngDelta = deg2rad($lng2 - $lng1);
    $a = sin($latDelta / 2) ** 2
      + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($lngDelta / 2) ** 2;

    return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
  }

  private function temporalScore(?CarbonInterface $candidate, ?CarbonInterface $alert): int
  {
    if ($candidate === null || $alert === null) {
      return 0;
    }

    $minutes = abs($candidate->diffInMinutes($alert));

    return match (true) {
      $minutes <= 15 => 100,
      $minutes <= 60 => 80,
      $minutes <= 360 => 60,
      default => 30,
    };
  }

  private function nearbyScore(array $sameCategoryMatches): int
  {
    if ($sameCategoryMatches === []) {
      return 50;
    }

    $strongRadius = (int) config('alert_verification.nearby.strong_radius_meters', 500);
    $strong = count(array_filter(
      $sameCategoryMatches,
      static fn (array $match): bool => $match['distance_meters'] <= $strongRadius
    ));

    return min(100, 60 + ($strong * 15) + (max(0, count($sameCategoryMatches) - $strong) * 5));
  }

  private function removeDuplicateIncidents(array $matches): array
  {
    $independent = [];
    $seen = [];

    foreach ($matches as $match) {
      $category = $match['category'];
      $normalized = mb_strtolower(trim($match['description']));
      $duplicate = false;

      foreach (($seen[$category] ?? []) as $existing) {
        similar_text($normalized, $existing, $similarity);
        if ($similarity >= 75) {
          $duplicate = true;
          break;
        }
      }

      if (!$duplicate) {
        $independent[] = $match;
        $seen[$category][] = $normalized;
      }
    }

    return $independent;
  }
}
