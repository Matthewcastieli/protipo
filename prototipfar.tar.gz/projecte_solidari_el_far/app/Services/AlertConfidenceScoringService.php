<?php

namespace App\Services;

use App\Models\Alert;
use App\Models\AlertVerification;

class AlertConfidenceScoringService
{
  public function __construct(
    private readonly ReporterReliabilityService $reliability,
    private readonly NearbyAlertMatcher $nearbyMatcher,
    private readonly ExternalEvidenceService $externalEvidence,
  ) {
  }

  public function analyze(Alert $alert): AlertVerification
  {
    $reporter = $this->reliability->score($alert->reporter_id);
    $nearby = $this->nearbyMatcher->analyze($alert);
    $hasCoordinates = $alert->latitude !== null && $alert->longitude !== null;
    $gpsScore = $hasCoordinates ? $this->gpsAccuracyScore($alert->accuracy) : null;
    $external = $alert->type === 'urgent'
      ? [
        'status' => 'not_requested',
        'sources' => [],
        'reason' => 'No es consulten fonts externs durant la recepció d’avisos urgents.',
      ]
      : $this->externalEvidence->analyze($alert);

    $components = [
      'user_reliability' => $reporter['score'],
      'nearby_incidents' => $nearby['nearby_score'],
      'geographic' => $gpsScore,
      'temporal' => $nearby['temporal_score'],
      'category' => $nearby['category_score'],
    ];
    $weights = (array) config('alert_verification.weights');
    $availableWeight = 0;
    $weightedScore = 0;
    $missing = [];

    foreach ($components as $name => $score) {
      if ($score === null) {
        $missing[] = $name;
        continue;
      }

      $weight = (int) ($weights[$name] ?? 0);
      $availableWeight += $weight;
      $weightedScore += $score * $weight;
    }

    $score = $availableWeight === 0
      ? 50
      : (int) round($weightedScore / $availableWeight);

    if ($external['status'] !== 'available') {
      $missing[] = 'external_evidence';
    }

    $level = match (true) {
      $score >= (int) config('alert_verification.thresholds.high', 75) => 'high',
      $score >= (int) config('alert_verification.thresholds.medium', 40) => 'medium',
      default => 'low',
    };

    $evidence = [
      'gps_accuracy_meters' => $alert->accuracy,
      'reporter_history' => [
        'verified' => $reporter['verified'],
        'confirmed' => $reporter['confirmed'],
      ],
      'nearby_matches' => $nearby['matches'],
      'external' => $external,
      'calculation' => [
        'weights' => $weights,
        'available_weight' => $availableWeight,
        'normalized' => $availableWeight > 0 && $availableWeight !== array_sum($weights),
        'explanation' => 'Puntuació d’ajuda a la priorització; no és una verificació humana ni prova que l’avís sigui cert o fals.',
      ],
    ];

    $attributes = [
      'alert_id' => $alert->id,
      'user_reliability_score' => $reporter['score'],
      'nearby_incidents_score' => $nearby['nearby_score'],
      'geographic_score' => $gpsScore,
      'temporal_score' => $nearby['temporal_score'],
      'category_score' => $nearby['category_score'],
      'final_confidence_score' => $score,
      'confidence_level' => $level,
      'evidence_details' => $evidence,
      'missing_evidence' => $missing,
      'created_at' => now(),
    ];

    $verification = AlertVerification::query()->where('alert_id', $alert->id)->first();

    if ($verification) {
      $verification->update([
        'user_reliability_score' => $reporter['score'],
        'nearby_incidents_score' => $nearby['nearby_score'],
        'geographic_score' => $gpsScore,
        'temporal_score' => $nearby['temporal_score'],
        'category_score' => $nearby['category_score'],
        'final_confidence_score' => $score,
        'confidence_level' => $level,
        'evidence_details' => $evidence,
        'missing_evidence' => $missing,
      ]);
    } else {
      $verification = AlertVerification::query()->create($attributes);
    }

    $alert->forceFill([
      'confidence_score' => $score,
      'confidence_level' => $level,
      'verification_updated_at' => now(),
    ])->save();

    return $verification;
  }

  private function gpsAccuracyScore(?int $accuracy): ?int
  {
    if ($accuracy === null || $accuracy < 1) {
      return null;
    }

    if ($accuracy > (int) config('alert_verification.gps_accuracy.maximum_meters', 5000)) {
      return 0;
    }

    return match (true) {
      $accuracy <= (int) config('alert_verification.gps_accuracy.excellent_meters', 20) => 100,
      $accuracy <= (int) config('alert_verification.gps_accuracy.good_meters', 50) => 90,
      $accuracy <= (int) config('alert_verification.gps_accuracy.fair_meters', 100) => 75,
      $accuracy <= (int) config('alert_verification.gps_accuracy.usable_meters', 250) => 55,
      default => 20,
    };
  }
}
