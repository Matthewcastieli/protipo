<?php

namespace App\Services;

use App\Models\Alert;
use App\Models\AlertConversation;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Cookie;

class AlertConversationAccessService
{
  private const ACCESS_TOKEN_TTL_MINUTES = 525600;

  public function reporterCanAccess(Request $request, Alert $alert): bool
  {
    $reporterId = $request->attributes->get('alert_reporter_id');
    $user = $request->user('web');

    return (is_string($reporterId)
        && is_string($alert->reporter_id)
        && hash_equals($alert->reporter_id, $reporterId))
      || ($user !== null
        && $alert->user_id !== null
        && (int) $alert->user_id === (int) $user->getAuthIdentifier());
  }

  public function ensureConversation(Alert $alert): AlertConversation
  {
    return AlertConversation::query()->firstOrCreate(
      ['alert_id' => $alert->id],
      [
        'access_token_hash' => hash('sha256', Str::random(64)),
        'access_token_expires_at' => now()->addMinutes(self::ACCESS_TOKEN_TTL_MINUTES),
      ]
    );
  }

  public function openForReporter(Request $request, Alert $alert): array
  {
    $conversation = $this->ensureConversation($alert);
    $cookieName = $this->cookieName($alert);
    $plainToken = $request->cookie($cookieName);

    if (
      is_string($plainToken)
      && $conversation->access_token_expires_at?->isFuture()
      && hash_equals($conversation->access_token_hash, hash('sha256', $plainToken))
    ) {
      return [$conversation, null];
    }

    $plainToken = Str::random(64);
    $conversation->forceFill([
      'access_token_hash' => hash('sha256', $plainToken),
      'access_token_expires_at' => now()->addMinutes(self::ACCESS_TOKEN_TTL_MINUTES),
    ])->save();

    $cookie = cookie(
      $cookieName,
      $plainToken,
      self::ACCESS_TOKEN_TTL_MINUTES,
      '/',
      null,
      $request->isSecure(),
      true,
      false,
      'lax'
    );

    return [$conversation, $cookie];
  }

  public function conversationForToken(Request $request, Alert $alert): ?AlertConversation
  {
    $conversation = AlertConversation::query()->where('alert_id', $alert->id)->first();
    $plainToken = $request->cookie($this->cookieName($alert));

    if (
      $conversation === null
      || !is_string($plainToken)
      || !$conversation->access_token_expires_at?->isFuture()
      || !hash_equals($conversation->access_token_hash, hash('sha256', $plainToken))
    ) {
      return null;
    }

    return $conversation;
  }

  private function cookieName(Alert $alert): string
  {
    return 'far_alert_contact_' . substr(hash('sha256', $alert->id), 0, 20);
  }
}
