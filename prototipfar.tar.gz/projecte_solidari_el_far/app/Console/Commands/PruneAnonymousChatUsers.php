<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class PruneAnonymousChatUsers extends Command
{
  protected $signature = 'chat:prune-anonymous {--days=30 : Minimum age of the identity in days}';

  protected $description = 'Delete old anonymous chat identities that never sent a message or joined a conversation.';

  public function handle(): int
  {
    $days = max(1, (int) $this->option('days'));

    $deleted = User::query()
      ->whereNotNull('access_hash')
      ->where('created_at', '<', now()->subDays($days))
      ->whereDoesntHave('sentMessages')
      ->whereDoesntHave('conversations')
      ->whereDoesntHave('helpRequests')
      ->delete();

    $this->info("Deleted {$deleted} unused anonymous chat identities.");

    return self::SUCCESS;
  }
}
