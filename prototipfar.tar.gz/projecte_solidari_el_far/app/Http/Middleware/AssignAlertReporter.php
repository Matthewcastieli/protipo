<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class AssignAlertReporter
{
  public function handle(Request $request, Closure $next): Response
  {
    $reporterId = null;
    $cookie = $request->cookie('far_reporter');

    if (is_string($cookie) && Str::isUuid($cookie)) {
      $reporterId = $cookie;
    }

    $reporterId ??= (string) Str::uuid();
    $request->attributes->set('alert_reporter_id', $reporterId);

    $response = $next($request);
    $response->headers->setCookie(cookie(
      'far_reporter',
      $reporterId,
      60 * 24 * 365,
      '/',
      null,
      $request->isSecure(),
      true,
      false,
      'lax'
    ));

    return $response;
  }
}
