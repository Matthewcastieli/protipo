<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureAccountUser
{
  public function handle(Request $request, Closure $next): Response
  {
    $user = Auth::guard('web')->user();

    if (!$user) {
      if ($request->expectsJson()) {
        return response()->json(['message' => 'Cal iniciar sessió.'], 401);
      }

      return redirect()->route('account.login');
    }

    $request->attributes->set('account_user', $user);

    return $next($request);
  }
}
