<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Symfony\Component\HttpFoundation\Response;

class ThrottleNonUrgentAlerts
{
  public function handle(Request $request, Closure $next): Response
  {
    if ($request->input('type') === 'urgent') {
      return $next($request);
    }

    $key = 'alert-intake:' . (string) $request->ip();
    $limit = 10;

    if (RateLimiter::tooManyAttempts($key, $limit)) {
      return response()->json([
        'ok' => false,
        'message' => 'S’ha arribat al límit temporal d’avisos no urgents. Torna-ho a provar més tard.',
      ], 429)->header('Retry-After', (string) RateLimiter::availableIn($key));
    }

    RateLimiter::hit($key, 60);

    return $next($request);
  }
}
