<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureRole
{
  public function handle(Request $request, Closure $next, ...$roles): Response
  {
    $user = $request->user();

    if (!$user) {
      if ($request->expectsJson()) {
        return response()->json(['message' => 'Cal iniciar sessió.'], 401);
      }

      return redirect()->route('account.login');
    }

    if (!in_array($user->role, $roles, true)) {
      if ($request->expectsJson()) {
        return response()->json(['message' => 'No tens permís per accedir a aquesta secció.'], 403);
      }

      abort(403, 'No tens permís per accedir a aquesta secció.');
    }

    return $next($request);
  }
}
