<?php

namespace App\Http\Middleware;

use App\Services\ChatIdentity;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Symfony\Component\HttpFoundation\Response;

/**
 * Gives every visitor a chat identity without a login:
 * a signed-in account wins; otherwise the identity is resolved from the far_chat cookie hash,
 * and a new anonymous identity is created (rate limited per IP) when there is none.
 */
class EnsureChatUser
{
  public function handle(Request $request, Closure $next): Response
  {
    $guard = Auth::guard('web');

    if ($guard->user()) {
      return $next($request);
    }

    $user = ChatIdentity::find($request);
    $token = null;

    if (!$user) {
      $key = 'chat-identity:' . $request->ip();

      if (RateLimiter::tooManyAttempts($key, ChatIdentity::MAX_NEW_PER_HOUR)) {
        $message = 'Massa sol·licituds noves des d’aquesta xarxa. Torna-ho a provar més tard.';

        return $request->expectsJson()
          ? response()->json(['message' => $message], 429)
          : abort(429, $message);
      }

      RateLimiter::hit($key, 3600);
      [$user, $token] = ChatIdentity::create();
    }

    // Request-scoped only: nothing is written to the session.
    $guard->setUser($user);
    $request->attributes->set('account_user', $user);

    $response = $next($request);

    if ($token !== null) {
      $response->headers->setCookie(ChatIdentity::cookie($token, $request->isSecure()));
    }

    return $response;
  }
}
