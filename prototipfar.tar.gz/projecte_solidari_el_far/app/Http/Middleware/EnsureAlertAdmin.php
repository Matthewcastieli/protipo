<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureAlertAdmin
{
  public function handle(Request $request, Closure $next): Response
  {
    if (!$request->session()->get('alert_admin_authenticated', false)) {
      return redirect()->route('admin.login');
    }

    $response = $next($request);
    $response->headers->set('Cache-Control', 'no-store, private');

    return $response;
  }
}
