<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Http\Request;

class AdminLoginController extends Controller
{
  public function create(Request $request): View|RedirectResponse|Response
  {
    if ($request->session()->get('alert_admin_authenticated', false)) {
      return redirect()->route('admin.alerts.index');
    }

    return response()
      ->view('admin.login')
      ->header('Cache-Control', 'no-store, private');
  }

  public function store(Request $request): RedirectResponse
  {
    $validated = $request->validate([
      'email' => ['required', 'email', 'max:255'],
      'password' => ['required', 'string', 'max:255'],
    ]);

    $configuredEmail = (string) config('alert_admin.email', '');
    $configuredPassword = (string) config('alert_admin.password', '');
    $isConfigured = $configuredEmail !== '' && $configuredPassword !== '';
    $credentialsMatch = $isConfigured
      && hash_equals($configuredEmail, $validated['email'])
      && hash_equals($configuredPassword, $validated['password']);

    if (!$credentialsMatch) {
      return back()
        ->withErrors(['email' => 'Credencials incorrectes o accés d’administració no configurat.'])
        ->onlyInput('email');
    }

    $request->session()->regenerate();
    $request->session()->put('alert_admin_authenticated', true);
    $request->session()->put('alert_admin_email', $configuredEmail);

    return redirect()->intended(route('admin.alerts.index'));
  }

  public function destroy(Request $request): RedirectResponse
  {
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect()->route('admin.login');
  }
}
