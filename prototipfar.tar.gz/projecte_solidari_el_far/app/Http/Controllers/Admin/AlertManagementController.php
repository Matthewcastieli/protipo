<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Alert;
use App\Models\AlertVerificationResult;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;
use Illuminate\Validation\Rule;

class AlertManagementController extends Controller
{
  public function index(Request $request): View
  {
    $validated = $request->validate([
      'status' => ['nullable', Rule::in(Alert::STATUSES)],
      'category' => ['nullable', Rule::in(Alert::CATEGORIES)],
      'confidence' => ['nullable', Rule::in(['high', 'medium', 'low'])],
      'type' => ['nullable', Rule::in(['normal', 'urgent'])],
      'date_from' => ['nullable', 'date_format:Y-m-d'],
      'date_to' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:date_from'],
    ]);

    $counts = Alert::query()
      ->selectRaw('status, COUNT(*) AS aggregate')
      ->groupBy('status')
      ->pluck('aggregate', 'status');

    $alerts = Alert::query()
      ->with(['latestVerification', 'latestVerificationResult'])
      ->when($validated['status'] ?? null, static fn (Builder $query, string $status) => $query->where('status', $status))
      ->when($validated['category'] ?? null, static fn (Builder $query, string $category) => $query->where('category', $category))
      ->when($validated['confidence'] ?? null, static fn (Builder $query, string $confidence) => $query->where('confidence_level', $confidence))
      ->when($validated['type'] ?? null, static fn (Builder $query, string $type) => $query->where('type', $type))
      ->when($validated['date_from'] ?? null, static fn (Builder $query, string $date) => $query->where('received_at', '>=', Carbon::parse($date)->startOfDay()))
      ->when($validated['date_to'] ?? null, static fn (Builder $query, string $date) => $query->where('received_at', '<', Carbon::parse($date)->addDay()->startOfDay()))
      ->orderByDesc('received_at')
      ->simplePaginate(25)
      ->withQueryString();

    return view('admin.alerts', [
      'alerts' => $alerts,
      'counts' => $counts,
      'statuses' => Alert::STATUS_LABELS,
      'categories' => Alert::CATEGORY_LABELS,
      'filters' => array_merge([
        'status' => '',
        'category' => '',
        'confidence' => '',
        'type' => '',
        'date_from' => '',
        'date_to' => '',
      ], $validated),
    ]);
  }

  public function resolved(Request $request): View
  {
    $validated = $request->validate([
      'category' => ['nullable', Rule::in(Alert::CATEGORIES)],
      'confidence' => ['nullable', Rule::in(['high', 'medium', 'low'])],
      'type' => ['nullable', Rule::in(['normal', 'urgent'])],
      'date_from' => ['nullable', 'date_format:Y-m-d'],
      'date_to' => ['nullable', 'date_format:Y-m-d', 'after_or_equal:date_from'],
    ]);

    $counts = Alert::query()
      ->whereIn('status', ['resolved', 'false'])
      ->selectRaw('status, COUNT(*) AS aggregate')
      ->groupBy('status')
      ->pluck('aggregate', 'status');

    $alerts = Alert::query()
      ->whereIn('status', ['resolved', 'false'])
      ->with(['latestVerification', 'latestVerificationResult'])
      ->when($validated['category'] ?? null, static fn (Builder $query, string $category) => $query->where('category', $category))
      ->when($validated['confidence'] ?? null, static fn (Builder $query, string $confidence) => $query->where('confidence_level', $confidence))
      ->when($validated['type'] ?? null, static fn (Builder $query, string $type) => $query->where('type', $type))
      ->when($validated['date_from'] ?? null, static fn (Builder $query, string $date) => $query->where('received_at', '>=', Carbon::parse($date)->startOfDay()))
      ->when($validated['date_to'] ?? null, static fn (Builder $query, string $date) => $query->where('received_at', '<', Carbon::parse($date)->addDay()->startOfDay()))
      ->orderByDesc('verification_updated_at')
      ->simplePaginate(25)
      ->withQueryString();

    return view('admin.resolved', [
      'alerts' => $alerts,
      'counts' => $counts,
      'statuses' => Alert::STATUS_LABELS,
      'categories' => Alert::CATEGORY_LABELS,
      'filters' => array_merge([
        'category' => '',
        'confidence' => '',
        'type' => '',
        'date_from' => '',
        'date_to' => '',
      ], $validated),
    ]);
  }

  public function updateStatus(Request $request, Alert $alert): RedirectResponse
  {
    $validated = $request->validate([
      'status' => ['required', Rule::in(Alert::STATUSES)],
    ]);

    $alert->update(['status' => $validated['status']]);

    return back()->with('status-message', 'S’ha actualitzat l’estat de l’avís.');
  }

  public function verify(Request $request, Alert $alert): RedirectResponse
  {
    $validated = $request->validate([
      'result' => ['required', Rule::in(['confirmed', 'false_report', 'inconclusive'])],
      'notes' => ['nullable', 'string', 'max:1200'],
    ]);

    $verifier = (string) $request->session()->get('alert_admin_email', config('alert_admin.email'));
    if ($verifier === '') {
      return back()->withErrors(['result' => 'No s’ha pogut identificar l’administrador per registrar l’auditoria.']);
    }

    DB::transaction(function () use ($alert, $validated, $verifier): void {
      AlertVerificationResult::query()->create([
        'alert_id' => $alert->id,
        'verifier_id' => $verifier,
        'result' => $validated['result'],
        'notes' => $validated['notes'] ?? null,
        'created_at' => now(),
      ]);
    });

    Log::info('Alert human verification recorded', [
      'alert_id' => $alert->id,
      'verifier_id' => $verifier,
      'result' => $validated['result'],
    ]);

    return back()->with('status-message', 'La decisió humana s’ha registrat a l’historial.');
  }
}
