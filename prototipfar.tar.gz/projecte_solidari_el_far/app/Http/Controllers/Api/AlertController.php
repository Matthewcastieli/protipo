<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Alert;
use App\Services\AlertConfidenceScoringService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

class AlertController extends Controller
{
  public function index(): JsonResponse
  {
    $alerts = Alert::query()
      ->select([
        'id',
        'type',
        'description',
        'risk_level',
        'status',
        'category',
        'latitude',
        'longitude',
        'client_created_at',
        'received_at',
      ])
      ->active()
      ->orderByDesc('received_at')
      ->limit(100)
      ->get()
      ->map(static fn (Alert $alert): array => $alert->toClientArray())
      ->all();

    return response()->json(['ok' => true, 'alerts' => $alerts])
      ->header('Cache-Control', 'no-store, private');
  }

  public function store(Request $request, AlertConfidenceScoringService $scoring): JsonResponse
  {
    if (is_string($request->input('description'))) {
      $request->merge([
        'description' => trim(strip_tags($request->input('description'))),
      ]);
    }

    $validated = $request->validate([
      'id' => ['nullable', 'string', 'max:80'],
      'type' => ['required', 'in:normal,urgent'],
      'description' => ['required', 'string', 'max:1200'],
      'user' => ['nullable', 'string', 'max:40'],
      'category' => ['nullable', 'in:' . implode(',', Alert::CATEGORIES)],
      'riskLevel' => ['nullable', 'in:possible,danger,urgent'],
      'location' => ['nullable', 'array'],
      'location.latitude' => ['nullable', 'numeric', 'between:-90,90'],
      'location.longitude' => ['nullable', 'numeric', 'between:-180,180'],
      'location.accuracy' => ['nullable', 'integer', 'min:0', 'max:100000'],
      'createdAt' => ['nullable', 'date'],
    ]);

    if (isset($validated['location']) && (
      isset($validated['location']['latitude']) xor isset($validated['location']['longitude'])
    )) {
      return response()->json([
        'ok' => false,
        'message' => 'Cal enviar les dues coordenades o cap.',
        'errors' => ['location' => ['Cal enviar les dues coordenades o cap.']],
      ], 422);
    }

    $id = ($validated['id'] ?? null) ?: (string) Str::uuid();
    $existing = Alert::query()->find($id);
    if ($existing) {
      if ($existing->reporter_id === $request->attributes->get('alert_reporter_id')) {
        if ($existing->confidence_score === null) {
          $verification = $scoring->analyze($existing);
          $confidence = [
            'score' => $verification->final_confidence_score,
            'level' => $verification->confidence_level,
            'missingEvidence' => $verification->missing_evidence,
          ];
        } else {
          $confidence = [
            'score' => $existing->confidence_score,
            'level' => $existing->confidence_level,
            'missingEvidence' => $existing->latestVerification?->missing_evidence ?? [],
          ];
        }

        return response()->json([
          'ok' => true,
          'message' => 'Aquest avís ja havia estat rebut pel servidor.',
          'alert' => $existing->toClientArray(),
          'confidence' => $confidence,
        ], 200)->header('Cache-Control', 'no-store, private');
      }

      return response()->json([
        'ok' => false,
        'message' => 'Aquest identificador d’avís ja s’ha utilitzat.',
      ], 409);
    }

    $location = $validated['location'] ?? [];
    if (isset($location['accuracy']) && (int) $location['accuracy'] === 0) {
      $location = [];
    }

    $alert = Alert::query()->forceCreate([
      'id' => $id,
      'type' => $validated['type'],
      'description' => $validated['description'],
      'user' => trim($validated['user'] ?? 'Usuari') ?: 'Usuari',
      'category' => $validated['category'] ?? 'other',
      'user_id' => Auth::guard('web')->id(),
      'reporter_id' => $request->attributes->get('alert_reporter_id'),
      'risk_level' => $validated['riskLevel'] ?? 'possible',
      'latitude' => $location['latitude'] ?? null,
      'longitude' => $location['longitude'] ?? null,
      'accuracy' => $location['accuracy'] ?? null,
      'client_created_at' => $validated['createdAt'] ?? now(),
      'received_at' => now(),
    ]);

    $verification = $scoring->analyze($alert);

    return response()->json([
      'ok' => true,
      'message' => 'Avís rebut. La puntuació ajuda l’equip a prioritzar-ne la verificació.',
      'alert' => $alert->toClientArray(),
      'confidence' => [
        'score' => $verification->final_confidence_score,
        'level' => $verification->confidence_level,
        'missingEvidence' => $verification->missing_evidence,
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }
}
