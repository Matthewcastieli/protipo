<?php

namespace App\Http\Controllers;

use App\Models\Alert;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
  public function __invoke(): View
  {
    $accountUser = Auth::guard('web')->user();

    $alerts = Alert::query()
      ->active()
      ->orderByDesc('received_at')
      ->limit(5)
      ->get()
      ->map(static function (Alert $alert): array {
        $latitude = $alert->latitude !== null ? round((float) $alert->latitude, 3) : null;
        $longitude = $alert->longitude !== null ? round((float) $alert->longitude, 3) : null;

        return [
        'id' => $alert->id,
        'type' => $alert->type,
        'title' => $alert->description !== '' ? $alert->description : 'Incidència oberta',
        'user' => 'Usuari',
        'lat' => $latitude,
        'lng' => $longitude,
        'time' => 'just ara',
      ];
      })
      ->all();

    return view('home', ['initialMapAlerts' => $alerts, 'accountUser' => $accountUser]);
  }
}
