<?php

namespace App\Http\Controllers;

use App\Models\Alert;
use App\Models\AlertConversation;
use App\Models\AlertConversationMessage;
use App\Services\AlertConversationAccessService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;

class AlertConversationController extends Controller
{
  public function showReporter(
    Request $request,
    Alert $alert,
    AlertConversationAccessService $access
  ): Response {
    abort_unless($access->reporterCanAccess($request, $alert), 404);

    [$conversation, $cookie] = $access->openForReporter($request, $alert);
    $response = response()->view('alerts.contact', [
      'alert' => $alert,
      'conversation' => $conversation,
      'messages' => $this->recentMessages($conversation),
    ])->header('Cache-Control', 'no-store, private');

    if ($cookie !== null) {
      $response->headers->setCookie($cookie);
    }

    return $response;
  }

  public function reporterMessages(
    Request $request,
    Alert $alert,
    AlertConversationAccessService $access
  ): JsonResponse {
    $conversation = $access->conversationForToken($request, $alert);
    abort_unless($conversation !== null, 404);

    return response()->json([
      'messages' => $this->recentMessages($conversation)->map(static fn (AlertConversationMessage $message): array => [
        'id' => $message->id,
        'sender' => $message->sender_type === 'reporter' ? 'you' : 'team',
        'body' => $message->body,
        'createdAt' => $message->created_at?->toIso8601String(),
      ])->all(),
    ])->header('Cache-Control', 'no-store, private');
  }

  public function storeReporterMessage(
    Request $request,
    Alert $alert,
    AlertConversationAccessService $access
  ): JsonResponse {
    $conversation = $access->conversationForToken($request, $alert);
    abort_unless($conversation !== null, 404);

    $validated = $request->validate([
      'body' => ['required', 'string', 'max:3000'],
    ]);
    $body = trim(strip_tags($validated['body']));
    if ($body === '') {
      return response()->json([
        'message' => 'Escriu un missatge abans d’enviar-lo.',
        'errors' => ['body' => ['Escriu un missatge abans d’enviar-lo.']],
      ], 422);
    }

    $message = DB::transaction(function () use ($conversation, $body): AlertConversationMessage {
      $message = $conversation->messages()->create([
        'sender_type' => 'reporter',
        'body' => $body,
        'created_at' => now(),
      ]);
      $conversation->update(['last_message_at' => $message->created_at]);

      return $message;
    });

    return response()->json([
      'message' => [
        'id' => $message->id,
        'sender' => 'you',
        'body' => $message->body,
        'createdAt' => $message->created_at?->toIso8601String(),
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }

  public function showAdmin(Alert $alert, AlertConversationAccessService $access): View
  {
    $conversation = $access->ensureConversation($alert);

    return view('admin.alert_conversation', [
      'alert' => $alert,
      'conversation' => $conversation,
      'messages' => $this->recentMessages($conversation),
    ]);
  }

  public function storeAdminMessage(
    Request $request,
    Alert $alert,
    AlertConversationAccessService $access
  ): RedirectResponse {
    $validated = $request->validate([
      'body' => ['required', 'string', 'max:3000'],
    ]);
    $body = trim(strip_tags($validated['body']));
    if ($body === '') {
      return back()->withErrors(['body' => 'Escriu un missatge abans d’enviar-lo.']);
    }

    $adminEmail = (string) $request->session()->get('alert_admin_email', config('alert_admin.email', ''));
    if ($adminEmail === '') {
      return back()->withErrors(['body' => 'No s’ha pogut identificar l’administrador per registrar el missatge.']);
    }

    $conversation = $access->ensureConversation($alert);
    DB::transaction(function () use ($conversation, $body, $adminEmail): void {
      $message = $conversation->messages()->create([
        'sender_type' => 'admin',
        'admin_email' => $adminEmail,
        'body' => $body,
        'created_at' => now(),
      ]);
      $conversation->update(['last_message_at' => $message->created_at]);
    });

    return back()->with('status-message', 'S’ha enviat el missatge al reportant anònim.');
  }

  private function recentMessages(AlertConversation $conversation)
  {
    return $conversation->messages()
      ->orderByDesc('created_at')
      ->orderByDesc('id')
      ->limit(100)
      ->get()
      ->reverse()
      ->values();
  }
}
