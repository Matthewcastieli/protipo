<?php

namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatConversationController extends Controller
{
  public function index(Request $request): View|JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $conversations = Conversation::query()
      ->whereExists(function ($query) use ($user): void {
        $query->selectRaw('1')
          ->from('conversation_participants')
          ->whereColumn('conversation_participants.conversation_id', 'conversations.id')
          ->where('conversation_participants.user_id', $user->id);
      })
      ->with(['lastMessage', 'participants' => function ($query) use ($user): void {
        $query->where('users.id', '!=', $user->id);
      }])
      ->orderByDesc('last_message_at')
      ->get()
      ->map(function (Conversation $conversation): array {
        $lastMessage = $conversation->lastMessage;

        return [
          'id' => $conversation->id,
          'title' => $conversation->title,
          'is_group' => (bool) $conversation->is_group,
          'created_by' => $conversation->created_by,
          'last_message_at' => $conversation->last_message_at?->toIso8601String(),
          'last_message' => $lastMessage ? [
            'body' => $lastMessage->body,
            'user_id' => $lastMessage->user_id,
            'created_at' => $lastMessage->created_at?->toIso8601String(),
          ] : null,
          'participants' => $conversation->participants->map(fn (User $u): array => [
            'id' => $u->id,
            'name' => $u->name,
            'role' => $u->role,
          ])->all(),
        ];
      })->all();

    if (!$request->expectsJson()) {
      return view('chat.index', ['accountUser' => $user, 'conversations' => $conversations]);
    }

    return response()->json(['conversations' => $conversations])
      ->header('Cache-Control', 'no-store, private');
  }

  public function store(Request $request): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $validated = $request->validate([
      'participant_ids' => ['required', 'array', 'min:1'],
      'participant_ids.*' => ['required', 'integer', 'exists:users,id'],
      'title' => ['nullable', 'string', 'max:160'],
      'body' => ['required', 'string', 'max:5000'],
    ]);

    $participantIds = array_unique(array_filter(array_map('intval', $validated['participant_ids'] ?? [])));

    if (in_array($user->id, $participantIds, true)) {
      $participantIds = array_values(array_diff($participantIds, [$user->id]));
    }

    if (count($participantIds) === 0) {
      return response()->json(['message' => 'Cal afegir almenys un altre participant.'], 422);
    }

    // Anonymous visitors can only start conversations with the team.
    if ($user->isAnonymous()
      && User::query()->whereIn('id', $participantIds)->whereIn('role', User::STAFF_ROLES)->count() !== count($participantIds)) {
      return response()->json(['message' => 'Només pots escriure a l’equip del projecte.'], 403);
    }

    $isGroup = count($participantIds) > 1;

    $conversation = Conversation::query()->create([
      'title' => $isGroup ? ($validated['title'] ?? 'Conversació de grup') : null,
      'is_group' => $isGroup,
      'created_by' => $user->id,
      'last_message_at' => now(),
    ]);

    $conversation->participants()->attach($user->id);
    foreach ($participantIds as $pid) {
      $conversation->participants()->attach($pid);
    }

    $message = Message::query()->create([
      'conversation_id' => $conversation->id,
      'user_id' => $user->id,
      'body' => $validated['body'],
    ]);

    return response()->json([
      'conversation' => [
        'id' => $conversation->id,
        'title' => $conversation->title,
        'is_group' => $conversation->is_group,
        'last_message_at' => $conversation->last_message_at?->toIso8601String(),
      ],
      'message' => [
        'id' => $message->id,
        'body' => $message->body,
        'user_id' => $message->user_id,
        'created_at' => $message->created_at?->toIso8601String(),
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }

  public function show(Request $request, Conversation $conversation): View|JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $isParticipant = $conversation->participants()->where('users.id', $user->id)->exists();

    if (!$isParticipant) {
      if (!$request->expectsJson()) {
        abort(403, 'No tens accés a aquesta conversa.');
      }

      return response()->json(['message' => 'No tens accés a aquesta conversa.'], 403);
    }

    // Latest 100 messages, returned oldest-first for display.
    $messages = $conversation->messages()
      ->with('user')
      ->orderByDesc('created_at')
      ->orderByDesc('id')
      ->limit(100)
      ->get()
      ->reverse()
      ->values()
      ->map(fn (Message $m): array => [
        'id' => $m->id,
        'body' => $m->body,
        'user_id' => $m->user_id,
        'user_name' => $m->user->name,
        'user_role' => $m->user->role,
        'created_at' => $m->created_at?->toIso8601String(),
        'read_at' => $m->read_at?->toIso8601String(),
      ])->all();

    $participants = $conversation->participants()->get()->map(fn (User $u): array => [
      'id' => $u->id,
      'name' => $u->name,
      'role' => $u->role,
    ])->all();

    if (!$request->expectsJson()) {
      return view('chat.conversation', [
        'accountUser' => $user,
        'conversation' => $conversation,
        'messages' => $messages,
        'participants' => $participants,
      ]);
    }

    return response()->json([
      'conversation' => [
        'id' => $conversation->id,
        'title' => $conversation->title,
        'is_group' => (bool) $conversation->is_group,
        'created_by' => $conversation->created_by,
        'last_message_at' => $conversation->last_message_at?->toIso8601String(),
      ],
      'messages' => $messages,
      'participants' => $participants,
    ])->header('Cache-Control', 'no-store, private');
  }
}
