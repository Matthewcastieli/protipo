<?php

namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatMessageController extends Controller
{
  public function store(Request $request, Conversation $conversation): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $isParticipant = $conversation->participants()->where('users.id', $user->id)->exists();

    if (!$isParticipant) {
      return response()->json(['message' => 'No tens accés a aquesta conversa.'], 403);
    }

    $validated = $request->validate([
      'body' => ['required', 'string', 'max:5000'],
    ]);

    $message = Message::query()->create([
      'conversation_id' => $conversation->id,
      'user_id' => $user->id,
      'body' => $validated['body'],
    ]);

    $conversation->update(['last_message_at' => now()]);

    return response()->json([
      'message' => [
        'id' => $message->id,
        'body' => $message->body,
        'user_id' => $message->user_id,
        'user_name' => $user->name,
        'user_role' => $user->role,
        'created_at' => $message->created_at?->toIso8601String(),
        'read_at' => null,
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }

  public function index(Request $request, Conversation $conversation): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $isParticipant = $conversation->participants()->where('users.id', $user->id)->exists();

    if (!$isParticipant) {
      return response()->json(['message' => 'No tens accés a aquesta conversa.'], 403);
    }

    // Latest 100 messages, returned oldest-first for display.
    $messages = $conversation->messages()
      ->with('user')
      ->orderByDesc('created_at')
      ->orderByDesc('id')
      ->limit(100)
      ->get()
      ->reverse()
      ->values()
      ->map(fn (Message $m): array => [
        'id' => $m->id,
        'body' => $m->body,
        'user_id' => $m->user_id,
        'user_name' => $m->user->name,
        'user_role' => $m->user->role,
        'created_at' => $m->created_at?->toIso8601String(),
        'read_at' => $m->read_at?->toIso8601String(),
      ])->all();

    return response()->json(['messages' => $messages])
      ->header('Cache-Control', 'no-store, private');
  }

  public function users(Request $request): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $users = User::query()
      ->where('id', '!=', $user->id)
      // Anonymous visitors are never listed, and they can only see the team.
      ->whereNull('access_hash')
      ->when($user->isAnonymous(), fn ($query) => $query->whereIn('role', User::STAFF_ROLES))
      ->orderBy('name')
      ->get()
      ->map(fn (User $u): array => [
        'id' => $u->id,
        'name' => $u->name,
        'role' => $u->role,
      ])->all();

    return response()->json(['users' => $users])
      ->header('Cache-Control', 'no-store, private');
  }
}
