<?php

namespace App\Http\Controllers\Chat;

use App\Http\Controllers\Controller;
use App\Models\Conversation;
use App\Models\HelpRequest;
use App\Models\HelpRequestResponse;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HelpRequestController extends Controller
{
  public function index(Request $request): View|JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    $query = HelpRequest::query()->with('user');

    if (!$user->hasRole('worker') && !$user->hasRole('admin')) {
      $query->where('user_id', $user->id);
    }

    $requests = $query->orderByDesc('created_at')->get()->map(fn (HelpRequest $r): array => [
      'id' => $r->id,
      'user_id' => $r->user_id,
      'user_name' => $r->user->name,
      'user_role' => $r->user->role,
      'title' => $r->title,
      'description' => $r->description,
      'category' => $r->category,
      'status' => $r->status,
      'closed_at' => $r->closed_at?->toIso8601String(),
      'created_at' => $r->created_at?->toIso8601String(),
      'response_count' => $r->responses->count(),
    ])->all();

    if (!$request->expectsJson()) {
      return view('chat.help_requests', ['accountUser' => $user, 'helpRequests' => $requests]);
    }

    return response()->json(['help_requests' => $requests])
      ->header('Cache-Control', 'no-store, private');
  }

  public function store(Request $request): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    if (!$user->hasRole('worker') && !$user->hasRole('volunteer')) {
      return response()->json(['message' => 'Només treballadors i voluntaris poden sol·licitar ajuda.'], 403);
    }

    $validated = $request->validate([
      'title' => ['required', 'string', 'max:160'],
      'description' => ['required', 'string', 'max:3000'],
      'category' => ['nullable', 'string', 'max:24', 'in:' . implode(',', array_keys(HelpRequest::CATEGORIES))],
    ]);

    $helpRequest = HelpRequest::query()->create([
      'user_id' => $user->id,
      'title' => $validated['title'],
      'description' => $validated['description'],
      'category' => $validated['category'] ?? 'other',
      'status' => 'open',
    ]);

    return response()->json([
      'help_request' => [
        'id' => $helpRequest->id,
        'title' => $helpRequest->title,
        'description' => $helpRequest->description,
        'category' => $helpRequest->category,
        'status' => $helpRequest->status,
        'created_at' => $helpRequest->created_at?->toIso8601String(),
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }

  public function responses(Request $request, HelpRequest $helpRequest): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    if (!$user->hasRole('worker') && !$user->hasRole('admin') && $helpRequest->user_id !== $user->id) {
      return response()->json(['message' => 'No tens accés a aquesta sol·licitud d’ajuda.'], 403);
    }

    $responses = $helpRequest->responses()->with('user')->orderBy('created_at')->get()->map(fn (HelpRequestResponse $r): array => [
      'id' => $r->id,
      'user_id' => $r->user_id,
      'user_name' => $r->user->name,
      'body' => $r->body,
      'created_at' => $r->created_at?->toIso8601String(),
    ])->all();

    return response()->json(['responses' => $responses])
      ->header('Cache-Control', 'no-store, private');
  }

  public function respond(Request $request, HelpRequest $helpRequest): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    if (!$user->hasRole('worker') && !$user->hasRole('admin') && $helpRequest->user_id !== $user->id) {
      return response()->json(['message' => 'No tens accés a aquesta sol·licitud d’ajuda.'], 403);
    }

    $validated = $request->validate([
      'body' => ['required', 'string', 'max:3000'],
    ]);

    $response = HelpRequestResponse::query()->create([
      'help_request_id' => $helpRequest->id,
      'user_id' => $user->id,
      'body' => $validated['body'],
    ]);

    return response()->json([
      'response' => [
        'id' => $response->id,
        'user_id' => $response->user_id,
        'user_name' => $user->name,
        'body' => $response->body,
        'created_at' => $response->created_at?->toIso8601String(),
      ],
    ], 201)->header('Cache-Control', 'no-store, private');
  }

  public function close(Request $request, HelpRequest $helpRequest): JsonResponse
  {
    /** @var User $user */
    $user = Auth::guard('web')->user();

    if ($helpRequest->user_id !== $user->id && !$user->hasRole('worker') && !$user->hasRole('admin')) {
      return response()->json(['message' => 'No tens permís per tancar aquesta sol·licitud.'], 403);
    }

    $helpRequest->update(['status' => 'closed', 'closed_at' => now()]);

    return response()->json([
      'help_request' => [
        'id' => $helpRequest->id,
        'status' => $helpRequest->status,
        'closed_at' => $helpRequest->closed_at?->toIso8601String(),
      ],
    ])->header('Cache-Control', 'no-store, private');
  }
}
