<?php

namespace App\Http\Controllers\Account;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\ChatIdentity;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class AccountController extends Controller
{
  public function showLogin(Request $request): View|RedirectResponse
  {
    if ($this->currentUser()) {
      return redirect()->route('home');
    }

    return view('account.login');
  }

  public function login(Request $request): RedirectResponse
  {
    if ($this->currentUser()) {
      return redirect()->route('home');
    }

    $validated = $request->validate([
      'email' => ['required', 'email', 'max:255'],
      'password' => ['required', 'string', 'max:255'],
    ]);

    $email = mb_strtolower($validated['email']);
    $user = User::query()->where('email', $email)->first();

    if (!$user || $user->isAnonymous() || !Hash::check($validated['password'], $user->password)) {
      return back()
        ->withErrors(['email' => 'Correu electrònic o contrasenya incorrectes.'])
        ->onlyInput('email');
    }

    $request->session()->regenerate();
    Auth::guard('web')->login($user);

    return redirect()->intended(route('home'));
  }

  public function showRegistration(Request $request): View|RedirectResponse
  {
    if ($this->currentUser()) {
      return redirect()->route('home');
    }

    return view('account.register');
  }

  public function register(Request $request): RedirectResponse
  {
    if ($this->currentUser($request)) {
      return redirect()->route('home');
    }

    $request->merge([
      'email' => is_string($request->input('email')) ? mb_strtolower(trim($request->input('email'))) : $request->input('email'),
      'name' => is_string($request->input('name')) ? trim($request->input('name')) : $request->input('name'),
    ]);

    $validated = $request->validate([
      'name' => ['required', 'string', 'max:80'],
      'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')],
      'password' => ['required', 'string', 'min:10', 'confirmed'],
    ]);

    $credentials = [
      'name' => $validated['name'],
      'email' => $validated['email'],
      'password' => Hash::make($validated['password']),
    ];
    $anonymous = ChatIdentity::find($request);

    if ($anonymous) {
      // Keep this device's chat history: the anonymous identity becomes the real account.
      $user = $anonymous->forceFill($credentials + ['access_hash' => null]);
      $user->save();
    } else {
      $user = User::query()->create($credentials);
    }

    $request->session()->regenerate();
    Auth::guard('web')->login($user);

    return redirect()->route('home')
      ->with('account_notice', 'Compte creat. Els avisos nous quedaran vinculats al teu compte.')
      ->withoutCookie(ChatIdentity::COOKIE);
  }

  public function logout(Request $request): RedirectResponse
  {
    Auth::guard('web')->logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect()->route('home');
  }

  private function currentUser(): ?User
  {
    return Auth::guard('web')->user();
  }
}
