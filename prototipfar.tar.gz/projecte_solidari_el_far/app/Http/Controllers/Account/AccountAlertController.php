<?php

namespace App\Http\Controllers\Account;

use App\Http\Controllers\Controller;
use App\Models\Alert;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AccountAlertController extends Controller
{
  public function index(Request $request): JsonResponse
  {
    /** @var User $user */
    $user = $request->attributes->get('account_user');
    $alerts = $user->alerts()
      ->select(['id', 'type', 'description', 'category', 'status', 'client_created_at', 'received_at'])
      ->orderByDesc('received_at')
      ->get()
      ->map(static fn ($alert): array => [
        'id' => $alert->id,
        'type' => $alert->type,
        'description' => $alert->description,
        'category' => $alert->category,
        'status' => $alert->status,
        'createdAt' => $alert->client_created_at?->toIso8601String() ?? $alert->received_at?->toIso8601String(),
      ])
      ->all();

    return response()->json(['alerts' => $alerts])
      ->header('Cache-Control', 'no-store, private');
  }

  public function update(Request $request, Alert $alert): JsonResponse
  {
    /** @var User $user */
    $user = $request->attributes->get('account_user');

    if ($alert->user_id !== $user->id) {
      return response()->json(['message' => 'No autoritzat'], 403)
        ->header('Cache-Control', 'no-store, private');
    }

    if (in_array($alert->status, ['resolved', 'false'], true)) {
      return response()->json(['message' => "No es pot editar un avís amb estat {$alert->status}"], 422)
        ->header('Cache-Control', 'no-store, private');
    }

    $validated = $request->validate([
      'description' => ['sometimes', 'string', 'max:1200'],
      'category' => ['sometimes', 'string', 'in:' . implode(',', Alert::CATEGORIES)],
    ]);

    $alert->update($validated);

    return response()->json([
      'alert' => [
        'id' => $alert->id,
        'type' => $alert->type,
        'description' => $alert->description,
        'category' => $alert->category,
        'status' => $alert->status,
        'createdAt' => $alert->client_created_at?->toIso8601String() ?? $alert->received_at?->toIso8601String(),
      ],
    ])->header('Cache-Control', 'no-store, private');
  }
}
