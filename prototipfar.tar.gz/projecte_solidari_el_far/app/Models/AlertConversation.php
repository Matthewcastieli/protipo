<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AlertConversation extends Model
{
  protected $fillable = [
    'alert_id',
    'access_token_hash',
    'access_token_expires_at',
    'last_message_at',
  ];

  protected function casts(): array
  {
    return [
      'access_token_expires_at' => 'immutable_datetime',
      'last_message_at' => 'immutable_datetime',
    ];
  }

  public function alert(): BelongsTo
  {
    return $this->belongsTo(Alert::class);
  }

  public function messages(): HasMany
  {
    return $this->hasMany(AlertConversationMessage::class);
  }
}
