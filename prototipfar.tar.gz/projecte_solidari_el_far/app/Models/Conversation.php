<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Conversation extends Model
{
  protected $fillable = [
    'title',
    'is_group',
    'created_by',
    'last_message_at',
  ];

  protected function casts(): array
  {
    return [
      'is_group' => 'boolean',
      'last_message_at' => 'datetime',
    ];
  }

  public function participants(): BelongsToMany
  {
    return $this->belongsToMany(User::class, 'conversation_participants')
      ->withPivot('read_at')
      ->withTimestamps();
  }

  public function messages(): HasMany
  {
    return $this->hasMany(Message::class);
  }

  public function creator(): BelongsTo
  {
    return $this->belongsTo(User::class, 'created_by');
  }

  public function lastMessage(): HasOne
  {
    return $this->hasOne(Message::class)->latestOfMany();
  }
}
