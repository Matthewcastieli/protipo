<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AlertVerification extends Model
{
  public $timestamps = false;

  protected $fillable = [
    'alert_id',
    'user_reliability_score',
    'nearby_incidents_score',
    'geographic_score',
    'temporal_score',
    'category_score',
    'final_confidence_score',
    'confidence_level',
    'evidence_details',
    'missing_evidence',
    'created_at',
  ];

  protected function casts(): array
  {
    return [
      'evidence_details' => 'array',
      'missing_evidence' => 'array',
      'created_at' => 'immutable_datetime',
    ];
  }

  public function alert(): BelongsTo
  {
    return $this->belongsTo(Alert::class);
  }
}
