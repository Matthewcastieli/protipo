<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Alert extends Model
{
  public const STATUSES = [
    'open',
    'checking',
    'resolved',
    'verification',
    'false',
  ];

  public const STATUS_LABELS = [
    'open' => 'Obert',
    'checking' => 'En revisió',
    'resolved' => 'Resolt',
    'verification' => 'Verificació',
    'false' => 'Fals',
  ];

  public const CATEGORIES = [
    'medical',
    'fire',
    'safety',
    'infrastructure',
    'other',
  ];

  public const CATEGORY_LABELS = [
    'medical' => 'Salut',
    'fire' => 'Incendi',
    'safety' => 'Seguretat',
    'infrastructure' => 'Infraestructura',
    'other' => 'Altres',
  ];

  public $incrementing = false;

  protected $keyType = 'string';

  public $timestamps = false;

  protected $attributes = [
    'status' => 'open',
    'category' => 'other',
  ];

  protected $fillable = [
    'id',
    'type',
    'description',
    'user',
    'user_id',
    'risk_level',
    'status',
    'category',
    'latitude',
    'longitude',
    'accuracy',
    'client_created_at',
    'received_at',
  ];

  protected function casts(): array
  {
    return [
      'latitude' => 'float',
      'longitude' => 'float',
      'accuracy' => 'integer',
      'confidence_score' => 'integer',
      'verification_updated_at' => 'immutable_datetime',
      'client_created_at' => 'immutable_datetime',
      'received_at' => 'immutable_datetime',
    ];
  }

  /** Alerts shown publicly: not resolved/false and (when configured) recent enough. */
  public function scopeActive(Builder $query): Builder
  {
    $query->whereNotIn('status', ['resolved', 'false']);

    $hours = (int) config('alerts.active_hours', 24);

    return $hours > 0 ? $query->where('received_at', '>=', now()->subHours($hours)) : $query;
  }

  public function toClientArray(): array
  {
    return [
      'id' => $this->id,
      'type' => $this->type,
      'description' => $this->description,
      'user' => 'Usuari',
      'riskLevel' => $this->risk_level,
      'status' => $this->status,
      'category' => $this->category,
      'location' => [
        'latitude' => $this->latitude !== null ? round($this->latitude, 3) : null,
        'longitude' => $this->longitude !== null ? round($this->longitude, 3) : null,
        'accuracy' => null,
      ],
      'createdAt' => $this->client_created_at?->toIso8601String(),
      'receivedAt' => $this->received_at?->toIso8601String(),
    ];
  }

  public function verifications(): HasMany
  {
    return $this->hasMany(AlertVerification::class);
  }

  public function accountOwner(): BelongsTo
  {
    return $this->belongsTo(User::class, 'user_id');
  }

  public function latestVerification(): HasOne
  {
    return $this->hasOne(AlertVerification::class)->latestOfMany();
  }

  public function verificationResults(): HasMany
  {
    return $this->hasMany(AlertVerificationResult::class);
  }

  public function contactConversation(): HasOne
  {
    return $this->hasOne(AlertConversation::class);
  }

  public function latestVerificationResult(): HasOne
  {
    return $this->hasOne(AlertVerificationResult::class)->latestOfMany();
  }
}
