<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
  public const ROLES = [
    'user' => 'Usuari',
    'worker' => 'Treballador',
    'volunteer' => 'Voluntari',
    'admin' => 'Administrador',
  ];

  public const STAFF_ROLES = ['worker', 'volunteer', 'admin'];

  protected $fillable = [
    'name',
    'email',
    'password',
    'role',
  ];

  protected $hidden = [
    'password',
    'access_hash',
  ];

  public function alerts(): HasMany
  {
    return $this->hasMany(Alert::class);
  }

  public function conversations(): BelongsToMany
  {
    return $this->belongsToMany(Conversation::class, 'conversation_participants')
      ->withPivot('read_at')
      ->withTimestamps();
  }

  public function sentMessages(): HasMany
  {
    return $this->hasMany(Message::class, 'user_id');
  }

  public function helpRequests(): HasMany
  {
    return $this->hasMany(HelpRequest::class);
  }

  public function helpRequestResponses(): HasMany
  {
    return $this->hasMany(HelpRequestResponse::class);
  }

  public function hasRole(string $role): bool
  {
    return $this->role === $role;
  }

  public function isWorkerOrVolunteer(): bool
  {
    return in_array($this->role, self::STAFF_ROLES, true);
  }

  /** True for passwordless chat identities created from a cookie hash (see ChatIdentity). */
  public function isAnonymous(): bool
  {
    return $this->access_hash !== null;
  }

  public function isStaff(): bool
  {
    return in_array($this->role, ['worker', 'admin'], true);
  }
}
