<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AlertVerificationResult extends Model
{
  public $timestamps = false;

  protected $fillable = [
    'alert_id',
    'verifier_id',
    'result',
    'notes',
    'created_at',
  ];

  protected function casts(): array
  {
    return ['created_at' => 'immutable_datetime'];
  }

  public function alert(): BelongsTo
  {
    return $this->belongsTo(Alert::class);
  }
}
