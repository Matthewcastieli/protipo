<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class HelpRequest extends Model
{
  protected $fillable = [
    'user_id',
    'title',
    'description',
    'category',
    'status',
    'closed_at',
  ];

  protected function casts(): array
  {
    return [
      'closed_at' => 'datetime',
    ];
  }

  public const CATEGORIES = [
    'medical' => 'Salut',
    'fire' => 'Incendi',
    'safety' => 'Seguretat',
    'infrastructure' => 'Infraestructura',
    'other' => 'Altres',
  ];

  public function user(): BelongsTo
  {
    return $this->belongsTo(User::class);
  }

  public function responses(): HasMany
  {
    return $this->hasMany(HelpRequestResponse::class);
  }
}
