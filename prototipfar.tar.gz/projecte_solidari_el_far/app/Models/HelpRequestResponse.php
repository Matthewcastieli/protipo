<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HelpRequestResponse extends Model
{
  protected $fillable = [
    'help_request_id',
    'user_id',
    'body',
  ];

  public function helpRequest(): BelongsTo
  {
    return $this->belongsTo(HelpRequest::class);
  }

  public function user(): BelongsTo
  {
    return $this->belongsTo(User::class);
  }
}
