<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AlertConversationMessage extends Model
{
  public $timestamps = false;

  protected $fillable = [
    'alert_conversation_id',
    'sender_type',
    'admin_email',
    'body',
    'created_at',
  ];

  protected function casts(): array
  {
    return [
      'created_at' => 'immutable_datetime',
    ];
  }

  public function conversation(): BelongsTo
  {
    return $this->belongsTo(AlertConversation::class, 'alert_conversation_id');
  }
}
