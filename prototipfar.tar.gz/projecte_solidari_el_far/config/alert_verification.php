<?php

return [
  'weights' => [
    'user_reliability' => 25,
    'nearby_incidents' => 25,
    'geographic' => 30,
    'temporal' => 10,
    'category' => 10,
  ],
  'thresholds' => [
    'high' => 75,
    'medium' => 40,
  ],
  'nearby' => [
    'strong_radius_meters' => 500,
    'maximum_radius_meters' => 2000,
    'matching_max_accuracy_meters' => 500,
    'lookback_hours' => 24,
  ],
  'gps_accuracy' => [
    'excellent_meters' => 20,
    'good_meters' => 50,
    'fair_meters' => 100,
    'usable_meters' => 250,
    'maximum_meters' => 5000,
  ],
];
