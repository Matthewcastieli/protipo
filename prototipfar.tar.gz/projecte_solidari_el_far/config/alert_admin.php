<?php

return [
  'email' => env('ALERT_ADMIN_EMAIL'),
  'password' => env('ALERT_ADMIN_PASSWORD'),
];
