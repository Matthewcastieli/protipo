<?php

return [
  'name' => env('APP_NAME', 'El Far'),
  'env' => env('APP_ENV', 'production'),
  'debug' => (bool) env('APP_DEBUG', false),
  'url' => env('APP_URL', 'http://localhost'),
  'timezone' => 'Europe/Madrid',
  'locale' => 'ca',
  'fallback_locale' => 'en',
  'faker_locale' => 'ca_ES',
  'key' => env('APP_KEY'),
  'cipher' => 'AES-256-CBC',
  'previous_keys' => array_filter(explode(',', env('APP_PREVIOUS_KEYS', ''))),
  'maintenance' => [
    'driver' => env('APP_MAINTENANCE_DRIVER', 'file'),
    'store' => env('APP_MAINTENANCE_STORE', 'file'),
  ],
];
