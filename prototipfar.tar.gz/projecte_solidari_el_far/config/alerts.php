<?php

return [
  // Alerts older than this many hours stop appearing on the public map (they stay in the database
  // and in the admin panel). Set ALERT_ACTIVE_HOURS=0 to show them until they are resolved.
  'active_hours' => (int) env('ALERT_ACTIVE_HOURS', 24),
];
