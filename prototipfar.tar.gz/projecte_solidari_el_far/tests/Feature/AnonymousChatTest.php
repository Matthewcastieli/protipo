<?php

namespace Tests\Feature;

use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use App\Services\ChatIdentity;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AnonymousChatTest extends TestCase
{
  use RefreshDatabase;

  private function member(string $name, string $role = 'user'): User
  {
    return User::query()->create([
      'name' => $name,
      'email' => strtolower($name) . '@example.test',
      'password' => Hash::make('a-strong-password'),
      'role' => $role,
    ]);
  }

  private function conversationBetween(User ...$users): Conversation
  {
    $conversation = Conversation::query()->create([
      'is_group' => count($users) > 2,
      'created_by' => $users[0]->id,
      'last_message_at' => now(),
    ]);
    $conversation->participants()->attach(array_map(fn (User $u): int => $u->id, $users));
    Message::query()->create(['conversation_id' => $conversation->id, 'user_id' => $users[0]->id, 'body' => 'Missatge de prova']);

    return $conversation;
  }

  public function test_visitor_gets_an_anonymous_chat_identity_without_logging_in(): void
  {
    $this->get('/chat')
      ->assertOk()
      ->assertSee('Anònim')
      ->assertCookie(ChatIdentity::COOKIE);

    $user = User::query()->whereNotNull('access_hash')->firstOrFail();
    $this->assertSame('user', $user->role);
    $this->assertSame(64, strlen($user->access_hash));
  }

  public function test_the_cookie_secret_is_never_stored_only_its_hash(): void
  {
    [$user, $token] = ChatIdentity::create();

    $this->assertNotSame($token, $user->access_hash);
    $this->assertSame(hash('sha256', $token), $user->access_hash);
    $this->assertArrayNotHasKey('access_hash', $user->toArray());
  }

  public function test_returning_visitor_keeps_the_same_identity(): void
  {
    [$user, $token] = ChatIdentity::create();

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->get('/chat')
      ->assertOk()
      ->assertSee($user->name)
      ->assertCookieMissing(ChatIdentity::COOKIE);

    $this->assertSame(1, User::query()->count());
  }

  public function test_invalid_cookie_is_ignored_and_a_new_identity_is_created(): void
  {
    $this->withCookie(ChatIdentity::COOKIE, 'not-a-valid-token')
      ->get('/chat')
      ->assertOk()
      ->assertCookie(ChatIdentity::COOKIE);

    $this->assertSame(1, User::query()->whereNotNull('access_hash')->count());
  }

  public function test_new_identities_are_rate_limited_per_ip(): void
  {
    for ($i = 0; $i < ChatIdentity::MAX_NEW_PER_HOUR; $i++) {
      $this->get('/chat')->assertOk();
    }

    $this->get('/chat')->assertStatus(429);
    $this->getJson('/api/chat/users')->assertStatus(429);
    $this->assertSame(ChatIdentity::MAX_NEW_PER_HOUR, User::query()->count());
  }

  public function test_signed_in_account_takes_precedence_over_the_anonymous_identity(): void
  {
    $member = $this->member('Pere');

    $this->actingAs($member)
      ->get('/chat')
      ->assertOk()
      ->assertSee('Pere')
      ->assertCookieMissing(ChatIdentity::COOKIE);

    $this->assertSame(0, User::query()->whereNotNull('access_hash')->count());
  }

  public function test_anonymous_visitors_only_see_staff_in_the_user_list(): void
  {
    [, $token] = ChatIdentity::create();
    ChatIdentity::create();
    $worker = $this->member('Marta', 'worker');
    $this->member('Pere');

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->getJson('/api/chat/users')
      ->assertOk()
      ->assertJsonCount(1, 'users')
      ->assertJsonPath('users.0.id', $worker->id);
  }

  public function test_anonymous_visitors_are_never_listed_to_other_users(): void
  {
    [$anonymous] = ChatIdentity::create();
    $worker = $this->member('Marta', 'worker');

    $this->actingAs($this->member('Pere'))
      ->getJson('/api/chat/users')
      ->assertOk()
      ->assertJsonCount(1, 'users')
      ->assertJsonPath('users.0.id', $worker->id)
      ->assertJsonMissing(['id' => $anonymous->id]);
  }

  public function test_anonymous_visitor_can_start_a_conversation_with_staff(): void
  {
    [, $token] = ChatIdentity::create();
    $worker = $this->member('Marta', 'worker');

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->postJson('/api/chat/conversations', ['participant_ids' => [$worker->id], 'body' => 'Hola, necessito ajuda'])
      ->assertCreated();

    $this->assertSame(1, Conversation::query()->count());
    $this->assertSame(1, Message::query()->count());
  }

  public function test_anonymous_visitor_cannot_start_a_conversation_with_non_staff(): void
  {
    [, $token] = ChatIdentity::create();
    [$otherAnonymous] = ChatIdentity::create();
    $regular = $this->member('Pere');

    foreach ([$regular, $otherAnonymous] as $target) {
      $this->withCookie(ChatIdentity::COOKIE, $token)
        ->postJson('/api/chat/conversations', ['participant_ids' => [$target->id], 'body' => 'Hola'])
        ->assertForbidden();
    }

    $this->assertSame(0, Conversation::query()->count());
  }

  public function test_anonymous_visitor_can_only_read_their_own_conversations(): void
  {
    [$mine, $myToken] = ChatIdentity::create();
    [, $otherToken] = ChatIdentity::create();
    $conversation = $this->conversationBetween($mine, $this->member('Marta', 'worker'));

    $this->withCookie(ChatIdentity::COOKIE, $myToken)
      ->getJson("/api/chat/conversations/{$conversation->id}/messages")
      ->assertOk()
      ->assertJsonPath('messages.0.body', 'Missatge de prova');

    $this->withCookie(ChatIdentity::COOKIE, $myToken)
      ->get("/chat/conversations/{$conversation->id}")
      ->assertOk()
      ->assertSee('Missatge de prova');

    $this->withCookie(ChatIdentity::COOKIE, $otherToken)
      ->getJson("/api/chat/conversations/{$conversation->id}/messages")
      ->assertForbidden();

    $this->withCookie(ChatIdentity::COOKIE, $otherToken)
      ->get("/chat/conversations/{$conversation->id}")
      ->assertForbidden();
  }

  public function test_anonymous_visitor_can_send_a_message_in_their_conversation(): void
  {
    [$mine, $token] = ChatIdentity::create();
    $conversation = $this->conversationBetween($mine, $this->member('Marta', 'worker'));

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->postJson("/api/chat/conversations/{$conversation->id}/messages", ['body' => 'Segueixo aquí'])
      ->assertCreated()
      ->assertJsonPath('message.user_id', $mine->id);
  }

  public function test_staff_pages_still_require_a_real_login(): void
  {
    [, $token] = ChatIdentity::create();

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->get('/chat/workers')
      ->assertRedirect(route('account.login'));
  }

  public function test_anonymous_identity_cannot_be_used_to_log_in(): void
  {
    [$anonymous] = ChatIdentity::create();

    $this->post(route('account.login.store'), ['email' => $anonymous->email, 'password' => 'anything-at-all'])
      ->assertSessionHasErrors('email');

    $this->assertGuest();
  }

  public function test_registering_turns_the_anonymous_identity_into_a_real_account(): void
  {
    [$anonymous, $token] = ChatIdentity::create();
    $conversation = $this->conversationBetween($anonymous, $this->member('Marta', 'worker'));

    $this->withCookie(ChatIdentity::COOKIE, $token)
      ->post(route('account.register.store'), [
        'name' => 'Laia',
        'email' => 'laia@example.test',
        'password' => 'a-strong-password',
        'password_confirmation' => 'a-strong-password',
      ])
      ->assertRedirect(route('home'));

    $this->assertSame(2, User::query()->count());

    $user = $anonymous->fresh();
    $this->assertSame('laia@example.test', $user->email);
    $this->assertSame('Laia', $user->name);
    $this->assertNull($user->access_hash);
    $this->assertTrue(Hash::check('a-strong-password', $user->password));
    $this->assertTrue($conversation->participants()->where('users.id', $user->id)->exists());
  }

  public function test_prune_command_removes_only_old_unused_anonymous_identities(): void
  {
    [$oldUnused] = ChatIdentity::create();
    [$oldActive] = ChatIdentity::create();
    [$recent] = ChatIdentity::create();
    $worker = $this->member('Marta', 'worker');

    foreach ([$oldUnused, $oldActive] as $user) {
      $user->forceFill(['created_at' => now()->subDays(40)])->save();
    }
    $this->conversationBetween($oldActive, $worker);

    $this->artisan('chat:prune-anonymous')->assertSuccessful();

    $this->assertNull(User::query()->find($oldUnused->id));
    $this->assertNotNull(User::query()->find($oldActive->id));
    $this->assertNotNull(User::query()->find($recent->id));
    $this->assertNotNull(User::query()->find($worker->id));
  }
}
