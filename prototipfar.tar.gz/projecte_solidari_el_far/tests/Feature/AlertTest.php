<?php

namespace Tests\Feature;

use App\Models\Alert;
use App\Models\AlertConversation;
use App\Models\AlertVerificationResult;
use App\Models\User;
use App\Services\AlertConfidenceScoringService;
use App\Services\ExternalEvidenceService;
use App\Services\ReporterReliabilityService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Tests\TestCase;

class AlertTest extends TestCase
{
  use RefreshDatabase;

  public function test_home_page_renders_without_alerts(): void
  {
    $this->get('/')
      ->assertOk()
      ->assertSee('No hi ha avisos actius.')
      ->assertDontSee(route('admin.login'), false)
      ->assertDontSee('Administració')
      ->assertSee(route('account.register'), false)
      ->assertSee('Els meus avisos')
      ->assertSee('Actualitza')
      ->assertSee('OpenStreetMap');
  }

  public function test_regular_account_can_be_created_with_a_hashed_password(): void
  {
    $this->get(route('account.register'))
      ->assertOk()
      ->assertSee('Crea un compte');

    $this->post(route('account.register.store'), [
      'name' => 'Persona de prova',
      'email' => 'TEST@example.test',
      'password' => 'a-strong-password',
      'password_confirmation' => 'a-strong-password',
    ])->assertRedirect(route('home'));

    $user = User::query()->where('email', 'test@example.test')->firstOrFail();
    $this->assertTrue(Hash::check('a-strong-password', $user->password));
    $this->assertNotSame('a-strong-password', $user->password);
    $this->get('/')
      ->assertOk()
      ->assertSee('Persona de prova')
      ->assertSee('Surt');
  }

  public function test_account_registration_rejects_short_passwords_and_duplicate_emails(): void
  {
    User::query()->create([
      'name' => 'Exist user',
      'email' => 'existing@example.test',
      'password' => Hash::make('existing-password'),
    ]);

    $this->from(route('account.register'))
      ->post(route('account.register.store'), [
        'name' => 'Short',
        'email' => 'new@example.test',
        'password' => 'short',
        'password_confirmation' => 'short',
      ])
      ->assertSessionHasErrors('password');

    $this->from(route('account.register'))
      ->post(route('account.register.store'), [
        'name' => 'Duplicate',
        'email' => 'EXISTING@example.test',
        'password' => 'a-strong-password',
        'password_confirmation' => 'a-strong-password',
      ])
      ->assertSessionHasErrors('email');
  }

  public function test_regular_account_can_log_in_and_out(): void
  {
    User::query()->create([
      'name' => 'Account owner',
      'email' => 'owner@example.test',
      'password' => Hash::make('a-strong-password'),
    ]);

    $this->post(route('account.login.store'), [
      'email' => 'OWNER@example.test',
      'password' => 'a-strong-password',
    ])->assertRedirect(route('home'));

    $this->get('/')
      ->assertOk()
      ->assertSee('Account owner');

    $this->post(route('account.logout'))
      ->assertRedirect(route('home'));

    $this->get('/')
      ->assertOk()
      ->assertDontSee('Account owner');
  }

  public function test_regular_account_cannot_access_administrator_dashboard(): void
  {
    $user = User::query()->create([
      'name' => 'Regular user',
      'email' => 'regular@example.test',
      'password' => Hash::make('a-strong-password'),
    ]);

    $this->actingAs($user)
      ->get('/admin/alerts')
      ->assertRedirect(route('admin.login'));
  }

  public function test_home_page_does_not_show_resolved_alerts_as_active(): void
  {
    Alert::query()->create([
      'id' => 'resolved-home-test',
      'type' => 'normal',
      'description' => 'Avís ja resolt',
      'status' => 'resolved',
      'latitude' => 41.387,
      'longitude' => 2.168,
      'received_at' => now(),
    ]);

    $this->get('/')
      ->assertOk()
      ->assertSee('No hi ha avisos actius.')
      ->assertDontSee('Avís ja resolt');
  }

  public function test_home_page_lists_active_alerts_without_gps_coordinates(): void
  {
    Alert::query()->create([
      'id' => 'no-location-home-alert',
      'type' => 'urgent',
      'description' => 'Avís actiu sense GPS',
      'received_at' => now(),
    ]);

    $this->get('/')
      ->assertOk()
      ->assertSee('Avís actiu sense GPS');
  }

  public function test_alert_can_be_created_and_listed_through_the_api(): void
  {
    $alertId = (string) Str::uuid();
    $this->postJson('/api/alerts', [
      'id' => $alertId,
      'type' => 'urgent',
      'description' => '<b>Incidència</b>',
      'user' => 'Tester',
      'category' => 'safety',
      'riskLevel' => 'urgent',
      'location' => [
        'latitude' => 41.387,
        'longitude' => 2.168,
        'accuracy' => 20,
      ],
      'createdAt' => '2026-11-04T10:00:00+00:00',
    ])
      ->assertCreated()
      ->assertJsonPath('alert.description', 'Incidència')
      ->assertJsonPath('alert.status', 'open');

    $this->assertDatabaseHas('alerts', [
      'id' => $alertId,
      'type' => 'urgent',
      'description' => 'Incidència',
      'user' => 'Tester',
      'category' => 'safety',
      'risk_level' => 'urgent',
      'latitude' => 41.387,
      'longitude' => 2.168,
      'accuracy' => 20,
    ]);

    $this->getJson('/api/alerts')
      ->assertOk()
      ->assertJsonPath('alerts.0.id', $alertId)
      ->assertJsonPath('alerts.0.status', 'open')
      ->assertJsonPath('alerts.0.location.latitude', 41.387)
      ->assertJsonPath('alerts.0.location.accuracy', null);
  }

  public function test_signed_in_alerts_are_linked_to_the_account_and_listed_privately(): void
  {
    $owner = User::query()->create([
      'name' => 'Owner',
      'email' => 'owner@example.test',
      'password' => Hash::make('a-strong-password'),
    ]);
    $other = User::query()->create([
      'name' => 'Other',
      'email' => 'other@example.test',
      'password' => Hash::make('a-strong-password'),
    ]);

    $this->actingAs($owner)
      ->postJson('/api/alerts', [
        'id' => 'account-owned-alert',
        'type' => 'normal',
        'description' => 'Avís del compte',
        'location' => ['latitude' => 41.387, 'longitude' => 2.168, 'accuracy' => 25],
      ])
      ->assertCreated();

    $this->assertDatabaseHas('alerts', [
      'id' => 'account-owned-alert',
      'user_id' => $owner->id,
    ]);

    $this->actingAs($owner)
      ->getJson(route('account.alerts.index'))
      ->assertOk()
      ->assertJsonPath('alerts.0.id', 'account-owned-alert')
      ->assertJsonPath('alerts.0.status', 'open');

    $this->actingAs($other)
      ->getJson(route('account.alerts.index'))
      ->assertOk()
      ->assertJsonCount(0, 'alerts');
  }

  public function test_anonymous_alerts_remain_unlinked_to_a_user_account(): void
  {
    $this->postJson('/api/alerts', [
      'id' => 'anonymous-account-alert',
      'type' => 'normal',
      'description' => 'Avís anònim',
      'location' => ['latitude' => 41.387, 'longitude' => 2.168, 'accuracy' => 25],
    ])->assertCreated();

    $this->assertDatabaseHas('alerts', [
      'id' => 'anonymous-account-alert',
      'user_id' => null,
    ]);
  }

  public function test_alert_management_requires_an_administrator_session(): void
  {
    $this->get(route('admin.login'))
      ->assertOk()
      ->assertHeader('Cache-Control', 'no-store, private');

    $this->get('/admin/alerts')
      ->assertRedirect(route('admin.login'));
  }

  public function test_admin_can_sign_in_and_view_the_dashboard(): void
  {
    config([
      'alert_admin.email' => 'admin@example.test',
      'alert_admin.password' => 'a-strong-test-password',
    ]);

    $this->post(route('admin.login.store'), [
      'email' => 'admin@example.test',
      'password' => 'a-strong-test-password',
    ])->assertRedirect(route('admin.alerts.index'));

    $this->get(route('admin.alerts.index'))
      ->assertOk()
      ->assertSee('Avisos rebuts');
  }

  public function test_dashboard_shows_confidence_and_human_decision_as_distinct_fields(): void
  {
    $alert = $this->makeAlert('dashboard-verification-test');
    $alert->forceFill([
      'confidence_score' => 80,
      'confidence_level' => 'high',
    ])->save();
    $alert->verifications()->create([
      'user_reliability_score' => 50,
      'nearby_incidents_score' => 75,
      'geographic_score' => 100,
      'temporal_score' => 80,
      'category_score' => 100,
      'final_confidence_score' => 80,
      'confidence_level' => 'high',
      'evidence_details' => ['nearby_matches' => [], 'external' => ['status' => 'unavailable']],
      'missing_evidence' => ['external_evidence'],
      'created_at' => now(),
    ]);
    $alert->verificationResults()->create([
      'verifier_id' => 'admin@example.test',
      'result' => 'confirmed',
      'created_at' => now(),
    ]);

    $this->withSession(['alert_admin_authenticated' => true])
      ->get(route('admin.alerts.index'))
      ->assertOk()
      ->assertSee('80/100')
      ->assertSee('Decisió humana: Confirmat')
      ->assertSee('Evidència externa: unavailable');
  }

  public function test_admin_can_record_a_human_verification_decision(): void
  {
    config(['alert_admin.email' => 'admin@example.test']);
    $alert = $this->makeAlert('human-decision-test');

    $this->withSession([
      'alert_admin_authenticated' => true,
      'alert_admin_email' => 'admin@example.test',
    ])->post(route('admin.alerts.verify', $alert), [
      'result' => 'confirmed',
      'notes' => 'Confirmat per revisió humana.',
    ])->assertRedirect();

    $this->assertDatabaseHas('alert_verification_results', [
      'alert_id' => $alert->id,
      'verifier_id' => 'admin@example.test',
      'result' => 'confirmed',
    ]);
  }

  public function test_unauthorized_user_cannot_record_a_human_decision(): void
  {
    $alert = $this->makeAlert('unauthorized-decision-test');

    $this->post(route('admin.alerts.verify', $alert), [
      'result' => 'confirmed',
    ])->assertRedirect(route('admin.login'));

    $this->assertDatabaseCount('alert_verification_results', 0);
  }

  public function test_administrator_can_update_an_alert_status(): void
  {
    $alert = Alert::query()->create([
      'id' => 'status-test',
      'type' => 'normal',
      'description' => 'Test d’estat',
      'received_at' => now(),
    ]);

    $this->withSession(['alert_admin_authenticated' => true])
      ->post(route('admin.alerts.status', $alert), ['status' => 'checking'])
      ->assertRedirect();

    $this->assertDatabaseHas('alerts', [
      'id' => 'status-test',
      'status' => 'checking',
    ]);
  }

  public function test_administrator_cannot_set_an_unknown_alert_status(): void
  {
    $alert = Alert::query()->create([
      'id' => 'invalid-status-test',
      'type' => 'normal',
      'description' => 'Test d’estat invàlid',
      'received_at' => now(),
    ]);

    $this->withSession(['alert_admin_authenticated' => true])
      ->from(route('admin.alerts.index'))
      ->post(route('admin.alerts.status', $alert), ['status' => 'unknown'])
      ->assertSessionHasErrors('status');

    $this->assertDatabaseHas('alerts', [
      'id' => 'invalid-status-test',
      'status' => 'open',
    ]);
  }

  public function test_closed_alerts_are_not_in_the_public_active_alert_feed(): void
  {
    foreach (['resolved', 'false'] as $status) {
      Alert::query()->create([
        'id' => "closed-{$status}",
        'type' => 'normal',
        'description' => 'Avís tancat',
        'status' => $status,
        'received_at' => now(),
      ]);
    }

    $this->getJson('/api/alerts')
      ->assertOk()
      ->assertJsonCount(0, 'alerts');
  }

  public function test_public_active_alert_feed_includes_all_open_alerts(): void
  {
    foreach (range(1, 25) as $number) {
      Alert::query()->create([
        'id' => "public-map-alert-{$number}",
        'type' => 'normal',
        'description' => "Incidència pública {$number}",
        'latitude' => 41.387,
        'longitude' => 2.168,
        'received_at' => now()->addSeconds($number),
      ]);
    }

    $this->getJson('/api/alerts')
      ->assertOk()
      ->assertJsonCount(25, 'alerts');
  }

  public function test_alert_rejects_an_invalid_type(): void
  {
    $this->postJson('/api/alerts', [
      'type' => 'invalid',
      'description' => 'Test',
    ])->assertUnprocessable()
      ->assertJsonValidationErrors(['type']);
  }

  public function test_new_reporter_starts_at_neutral_reliability(): void
  {
    $this->assertSame(50, app(ReporterReliabilityService::class)->score((string) Str::uuid())['score']);
  }

  public function test_only_human_verified_results_change_reporter_reliability(): void
  {
    $reporterId = (string) Str::uuid();
    $alert = $this->makeAlert('reliability-test', $reporterId);
    $unverifiedAlert = $this->makeAlert('unverified-alert', $reporterId);

    $this->assertSame(50, app(ReporterReliabilityService::class)->score($reporterId)['score']);

    AlertVerificationResult::query()->create([
      'alert_id' => $alert->id,
      'verifier_id' => 'admin@example.test',
      'result' => 'confirmed',
      'created_at' => now(),
    ]);
    AlertVerificationResult::query()->create([
      'alert_id' => $unverifiedAlert->id,
      'verifier_id' => 'admin@example.test',
      'result' => 'inconclusive',
      'created_at' => now(),
    ]);

    $this->assertSame(55, app(ReporterReliabilityService::class)->score($reporterId)['score']);

    AlertVerificationResult::query()->create([
      'alert_id' => $alert->id,
      'verifier_id' => 'admin@example.test',
      'result' => 'false_report',
      'created_at' => now()->addSecond(),
    ]);

    $this->assertSame(45, app(ReporterReliabilityService::class)->score($reporterId)['score']);
  }

  public function test_one_false_report_is_bayesian_smoothed(): void
  {
    $reporterId = (string) Str::uuid();
    $alert = $this->makeAlert('few-history-test', $reporterId);
    AlertVerificationResult::query()->create([
      'alert_id' => $alert->id,
      'verifier_id' => 'admin@example.test',
      'result' => 'false_report',
      'created_at' => now(),
    ]);

    $this->assertSame(45, app(ReporterReliabilityService::class)->score($reporterId)['score']);
  }

  public function test_high_gps_accuracy_receives_a_higher_score_than_low_accuracy(): void
  {
    $highAccuracy = $this->makeAlert('gps-high-test', (string) Str::uuid(), 20);
    $lowAccuracy = $this->makeAlert('gps-low-test', (string) Str::uuid(), 600);
    $scoring = app(AlertConfidenceScoringService::class);

    $high = $scoring->analyze($highAccuracy);
    $low = $scoring->analyze($lowAccuracy);

    $this->assertSame(100, $high->geographic_score);
    $this->assertSame(20, $low->geographic_score);
    $this->assertGreaterThan($low->final_confidence_score, $high->final_confidence_score);
  }

  public function test_nearby_duplicate_alerts_do_not_inflate_independent_matches(): void
  {
    $current = $this->makeAlert('nearby-current', (string) Str::uuid(), 30, 'medical', 41.3870, 2.1680, 'Incident al parc');
    $this->makeAlert('nearby-first', (string) Str::uuid(), 30, 'medical', 41.3872, 2.1680, 'Incident al parc central');
    $this->makeAlert('nearby-duplicate', (string) Str::uuid(), 30, 'medical', 41.3873, 2.1680, 'Incident al parc central');

    $verification = app(AlertConfidenceScoringService::class)->analyze($current);

    $this->assertCount(1, $verification->evidence_details['nearby_matches']);
    $this->assertSame(75, $verification->nearby_incidents_score);
  }

  public function test_nearby_matcher_ignores_same_reporter_and_scores_category_mismatch(): void
  {
    $reporterId = (string) Str::uuid();
    $current = $this->makeAlert('category-current', $reporterId, 20, 'safety', 41.3870, 2.1680);
    $this->makeAlert('same-reporter-neighbor', $reporterId, 20, 'safety', 41.3871, 2.1680);
    $this->makeAlert('different-category-neighbor', (string) Str::uuid(), 20, 'fire', 41.3872, 2.1680);

    $verification = app(AlertConfidenceScoringService::class)->analyze($current);

    $this->assertCount(1, $verification->evidence_details['nearby_matches']);
    $this->assertSame(0, $verification->category_score);
    $this->assertSame(50, $verification->nearby_incidents_score);
  }

  public function test_missing_gps_and_external_sources_are_reported_without_zero_filling(): void
  {
    $alert = $this->makeAlert('missing-evidence-test', (string) Str::uuid(), null, 'other', null, null);
    $verification = app(AlertConfidenceScoringService::class)->analyze($alert);

    $this->assertContains('geographic', $verification->missing_evidence);
    $this->assertContains('external_evidence', $verification->missing_evidence);
    $this->assertTrue($verification->evidence_details['calculation']['normalized']);
    $this->assertSame('unavailable', app(ExternalEvidenceService::class)->analyze($alert)['status']);
    $this->assertSame(50, $verification->final_confidence_score);
  }

  public function test_urgent_alert_is_stored_even_when_location_is_unavailable(): void
  {
    $externalEvidence = \Mockery::mock(ExternalEvidenceService::class);
    $externalEvidence->shouldNotReceive('analyze');
    app()->instance(ExternalEvidenceService::class, $externalEvidence);

    $this->postJson('/api/alerts', [
      'id' => (string) Str::uuid(),
      'type' => 'urgent',
      'description' => 'Urgent sense GPS',
      'category' => 'medical',
      'riskLevel' => 'urgent',
    ])->assertCreated()
      ->assertJsonPath('alert.type', 'urgent')
      ->assertJsonPath('alert.status', 'open')
      ->assertJsonPath('confidence.score', 50);

    $this->assertDatabaseHas('alerts', [
      'type' => 'urgent',
      'description' => 'Urgent sense GPS',
      'latitude' => null,
    ]);
  }

  public function test_location_requires_both_coordinates(): void
  {
    $this->postJson('/api/alerts', [
      'type' => 'normal',
      'description' => 'Incomplete coordinates',
      'category' => 'safety',
      'location' => ['latitude' => 41.387],
    ])->assertUnprocessable()
      ->assertJsonValidationErrors('location');
  }

  public function test_reused_alert_id_cannot_overwrite_an_existing_alert(): void
  {
    $id = (string) Str::uuid();
    $reporterId = (string) Str::uuid();
    $payload = [
      'id' => $id,
      'type' => 'urgent',
      'description' => 'Original alert',
      'category' => 'safety',
    ];

    $this->withCredentials()->withCookie('far_reporter', $reporterId)
      ->postJson('/api/alerts', $payload)
      ->assertCreated();
    $this->assertDatabaseHas('alerts', ['id' => $id, 'reporter_id' => $reporterId]);

    $payload['description'] = 'Replacement alert';
    $this->withCookie('far_reporter', $reporterId)
      ->postJson('/api/alerts', $payload)
      ->assertOk()
      ->assertJsonPath('alert.description', 'Original alert');

    $this->assertDatabaseHas('alerts', ['id' => $id, 'description' => 'Original alert']);
  }

  public function test_client_cannot_set_reporter_identity_or_confidence(): void
  {
    $reporterId = (string) Str::uuid();
    $id = (string) Str::uuid();
    $this->withCredentials()->withCookie('far_reporter', $reporterId)
      ->postJson('/api/alerts', [
        'id' => $id,
        'type' => 'normal',
        'description' => 'Ignore forged trust data',
        'category' => 'safety',
        'reporter_id' => (string) Str::uuid(),
        'confidence_score' => 100,
        'status' => 'resolved',
      ])->assertCreated()
      ->assertJsonPath('alert.status', 'open');

    $this->assertDatabaseHas('alerts', [
      'id' => $id,
      'reporter_id' => $reporterId,
      'confidence_score' => 50,
    ]);
  }

  public function test_alert_submission_is_rate_limited(): void
  {
    for ($index = 0; $index < 10; $index++) {
      $this->postJson('/api/alerts', [
        'id' => (string) Str::uuid(),
        'type' => 'normal',
        'description' => 'Rate limit test',
        'category' => 'other',
      ])->assertCreated();
    }

    $this->postJson('/api/alerts', [
      'id' => (string) Str::uuid(),
      'type' => 'normal',
      'description' => 'Rate limit exceeded',
      'category' => 'other',
    ])->assertTooManyRequests();
  }

  public function test_database_cache_store_can_rate_limit_alert_submissions(): void
  {
    config(['cache.default' => 'database']);

    $this->postJson('/api/alerts', [
      'id' => 'database-cache-alert',
      'type' => 'normal',
      'description' => 'Stored with database cache',
      'category' => 'other',
    ])->assertCreated();

    $this->assertDatabaseHas('alerts', ['id' => 'database-cache-alert']);
    $this->assertGreaterThan(0, DB::table('cache')->count());
  }

  public function test_urgent_alerts_are_not_blocked_by_non_urgent_rate_limit(): void
  {
    for ($index = 0; $index < 11; $index++) {
      $this->postJson('/api/alerts', [
        'id' => (string) Str::uuid(),
        'type' => 'urgent',
        'description' => 'Urgent alert must be accepted',
        'category' => 'medical',
      ])->assertCreated();
    }
  }

  public function test_public_feed_does_not_expose_reporter_name_or_exact_gps_accuracy(): void
  {
    $id = (string) Str::uuid();
    $reporterId = (string) Str::uuid();
    $this->withCredentials()->withCookie('far_reporter', $reporterId)
      ->postJson('/api/alerts', [
        'id' => $id,
        'type' => 'normal',
        'description' => 'Private location test',
        'user' => 'Private name',
        'category' => 'other',
        'location' => [
          'latitude' => 41.387123,
          'longitude' => 2.168456,
          'accuracy' => 8,
        ],
      ])->assertCreated();

    $this->getJson('/api/alerts')
      ->assertOk()
      ->assertJsonPath('alerts.0.user', 'Usuari')
      ->assertJsonPath('alerts.0.location.latitude', 41.387)
      ->assertJsonPath('alerts.0.location.accuracy', null)
      ->assertDontSee('Private name');
  }

  public function test_reporter_can_open_only_their_alert_conversation_with_a_private_cookie(): void
  {
    $reporterId = (string) Str::uuid();
    $alert = $this->makeAlert('private-conversation-page', $reporterId);

    $response = $this->withCookie('far_reporter', $reporterId)
      ->get(route('alerts.contact', $alert));

    $response->assertOk()
      ->assertSee('Conversa amb l’equip')
      ->assertDontSee($reporterId);

    $conversation = AlertConversation::query()->where('alert_id', $alert->id)->firstOrFail();
    $this->assertSame(64, strlen($conversation->access_token_hash));
    $this->assertNotSame($reporterId, $conversation->access_token_hash);

    $contactCookie = collect($response->headers->getCookies())
      ->first(fn ($cookie) => str_starts_with($cookie->getName(), 'far_alert_contact_'));
    $this->assertNotNull($contactCookie);
    $this->assertTrue($contactCookie->isHttpOnly());
    $this->assertSame('lax', $contactCookie->getSameSite());

    $this->withCookie('far_reporter', (string) Str::uuid())
      ->get(route('alerts.contact', $alert))
      ->assertNotFound();
  }

  public function test_reporter_messages_require_the_alert_private_token_and_hide_internal_identity(): void
  {
    $alert = $this->makeAlert('private-conversation-api', (string) Str::uuid());
    $token = Str::random(64);
    $cookieName = 'far_alert_contact_' . substr(hash('sha256', $alert->id), 0, 20);
    $conversation = AlertConversation::query()->create([
      'alert_id' => $alert->id,
      'access_token_hash' => hash('sha256', $token),
      'access_token_expires_at' => now()->addYear(),
    ]);

    $this->getJson(route('alerts.messages.index', $alert))->assertNotFound();
    $this->withCredentials()->withCookie($cookieName, Str::random(64))
      ->getJson(route('alerts.messages.index', $alert))
      ->assertNotFound();

    $conversation->update(['access_token_expires_at' => now()->subMinute()]);
    $this->withCredentials()->withCookie($cookieName, $token)
      ->getJson(route('alerts.messages.index', $alert))
      ->assertNotFound();
    $conversation->update(['access_token_expires_at' => now()->addYear()]);

    $this->withCredentials()->withCookie($cookieName, $token)
      ->postJson(route('alerts.messages.store', $alert), [
        'body' => 'Necessito parlar amb l’equip.',
      ])
      ->assertCreated()
      ->assertJsonPath('message.sender', 'you')
      ->assertJsonPath('message.body', 'Necessito parlar amb l’equip.')
      ->assertDontSee('adminEmail')
      ->assertDontSee($alert->reporter_id);

    $this->assertDatabaseHas('alert_conversation_messages', [
      'alert_conversation_id' => $conversation->id,
      'sender_type' => 'reporter',
      'admin_email' => null,
      'body' => 'Necessito parlar amb l’equip.',
    ]);
  }

  public function test_only_an_authenticated_alert_admin_can_read_and_reply_to_private_conversations(): void
  {
    $alert = $this->makeAlert('private-conversation-admin', (string) Str::uuid());

    $this->get(route('admin.alerts.conversation', $alert))
      ->assertRedirect(route('admin.login'));

    $this->withSession([
      'alert_admin_authenticated' => true,
      'alert_admin_email' => 'admin@example.test',
    ])->get(route('admin.alerts.conversation', $alert))
      ->assertOk()
      ->assertSee('Conversa privada')
      ->assertDontSee($alert->reporter_id);

    $this->from(route('admin.alerts.conversation', $alert))
      ->withSession([
        'alert_admin_authenticated' => true,
        'alert_admin_email' => 'admin@example.test',
      ])
      ->post(route('admin.alerts.conversation.store', $alert), [
        'body' => 'T’ajudarem de seguida.',
      ])
      ->assertRedirect(route('admin.alerts.conversation', $alert));

    $this->assertDatabaseHas('alert_conversation_messages', [
      'sender_type' => 'admin',
      'admin_email' => 'admin@example.test',
      'body' => 'T’ajudarem de seguida.',
    ]);
  }

  private function makeAlert(
    string $id,
    ?string $reporterId = null,
    ?int $accuracy = 20,
    string $category = 'medical',
    ?float $latitude = 41.387,
    ?float $longitude = 2.168,
    string $description = 'Test alert'
  ): Alert {
    return Alert::query()->forceCreate([
      'id' => $id,
      'type' => 'normal',
      'description' => $description,
      'category' => $category,
      'reporter_id' => $reporterId,
      'latitude' => $latitude,
      'longitude' => $longitude,
      'accuracy' => $accuracy,
      'received_at' => now(),
    ]);
  }
}
