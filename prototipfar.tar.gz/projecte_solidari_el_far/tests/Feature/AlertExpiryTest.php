<?php

namespace Tests\Feature;

use App\Models\Alert;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AlertExpiryTest extends TestCase
{
  use RefreshDatabase;

  private function alert(string $id, string $description, \DateTimeInterface $receivedAt): void
  {
    Alert::query()->create([
      'id' => $id,
      'type' => 'normal',
      'description' => $description,
      'received_at' => $receivedAt,
    ]);
  }

  public function test_old_alerts_are_hidden_from_the_map_and_the_api(): void
  {
    config(['alerts.active_hours' => 24]);
    $this->alert('old-alert', 'Avís antic', now()->subHours(30));
    $this->alert('fresh-alert', 'Avís recent', now()->subHours(2));

    $this->get('/')
      ->assertOk()
      ->assertSee('Avís recent')
      ->assertDontSee('Avís antic');

    $this->getJson('/api/alerts')
      ->assertOk()
      ->assertJsonCount(1, 'alerts')
      ->assertJsonPath('alerts.0.id', 'fresh-alert');
  }

  public function test_a_zero_limit_keeps_alerts_visible_until_they_are_resolved(): void
  {
    config(['alerts.active_hours' => 0]);
    $this->alert('old-alert', 'Avís antic', now()->subDays(30));

    $this->getJson('/api/alerts')->assertOk()->assertJsonCount(1, 'alerts');
  }
}
