<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#102b3f">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="format-detection" content="telephone=no">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icons/apple-touch-icon.png')); ?>">
  <title>Accés administrador · El Far</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=2">
</head>
<body>
  <main class="auth-shell">
    <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Gestió d’avisos</small></span></a>
    <section class="auth-card">
      <p class="eyebrow">ÀREA PRIVADA</p>
      <h1>Accés administrador</h1>
      <p class="muted">Identifica’t per gestionar els avisos rebuts.</p>
      <?php if($errors->any()): ?>
        <p class="notice error" role="alert"><?php echo e($errors->first()); ?></p>
      <?php endif; ?>
      <form method="post" action="<?php echo e(route('admin.login.store')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">Correu electrònic</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
        <label for="password">Contrasenya</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <button class="button primary" type="submit">Entra</button>
      </form>
    </section>
    <a class="back-link" href="<?php echo e(route('home')); ?>">← Torna a El Far</a>
  </main>
</body>
</html>
<?php /**PATH /home/mcastiel/Escriptori/projecte_solidari_el_far/resources/views/admin/login.blade.php ENDPATH**/ ?>