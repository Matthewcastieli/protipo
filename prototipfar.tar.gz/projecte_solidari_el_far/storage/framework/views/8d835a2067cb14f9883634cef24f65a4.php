<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <title>Missatges privats · El Far</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=14">
  <link rel="stylesheet" href="<?php echo e(asset('css/chat.css')); ?>?v=3">
  <style>
    .contact-shell { width: min(760px, calc(100% - 24px)); min-height: 100dvh; margin: 0 auto; display: flex; flex-direction: column; padding: 18px 0; }
    .contact-card { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
    .contact-heading { padding: 20px; border-bottom: 1px solid #e2e8f0; }
    .contact-heading h1 { margin: 0; color: #102b3f; font-size: 1.4rem; }
    .contact-heading p { margin: 8px 0 0; color: #647987; }
    .contact-messages { flex: 1; min-height: 220px; max-height: 55vh; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; padding: 18px; background: #f3f7f9; }
    .contact-message { max-width: 85%; padding: 10px 13px; border-radius: 12px; line-height: 1.45; overflow-wrap: anywhere; white-space: pre-wrap; }
    .contact-message.you { align-self: flex-end; color: #fff; background: #102b3f; }
    .contact-message.team { align-self: flex-start; color: #1a202c; background: #fff; border: 1px solid #e2e8f0; }
    .contact-message small { display: block; margin-top: 5px; opacity: .75; }
    .contact-empty { margin: auto; color: #718096; }
    .contact-compose { display: grid; gap: 10px; padding: 16px 20px; }
    .contact-compose textarea { width: 100%; }
    .contact-note { margin: 0; padding: 0 20px 16px; color: #647987; font-size: .88rem; }
    .contact-error { min-height: 1.3em; padding: 0 20px; color: #8b3232; }
  </style>
</head>
<body>
<header class="topbar">
  <a class="brand" href="/" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <a class="account-link" href="/">Torna a l’inici</a>
</header>

<main class="contact-shell">
  <section class="panel contact-card">
    <div class="contact-heading">
      <p class="eyebrow">CANAL PRIVAT I PSEUDÒNIM</p>
      <h1>Conversa amb l’equip</h1>
      <p>Missatges relacionats amb l’avís: <?php echo e($alert->description ?: 'Sense detalls addicionals'); ?></p>
      <p>No cal compartir el teu nom. Aquest canal no és un servei d’emergències; en cas de perill immediat, truca al 112.</p>
    </div>
    <div id="contactMessages" class="contact-messages" aria-live="polite">
      <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="contact-message <?php echo e($message->sender_type === 'reporter' ? 'you' : 'team'); ?>">
          <?php echo e($message->body); ?>

          <small><?php echo e($message->sender_type === 'reporter' ? 'Tu' : 'Equip El Far'); ?> · <?php echo e($message->created_at?->format('d/m H:i')); ?></small>
        </article>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="contact-empty">Encara no hi ha missatges. Pots escriure a l’equip de manera privada.</p>
      <?php endif; ?>
    </div>
    <p id="contactStatus" class="contact-error" role="status" aria-live="polite"></p>
    <form id="contactForm" class="contact-compose">
      <label for="contactBody">Missatge</label>
      <textarea id="contactBody" rows="3" maxlength="3000" required placeholder="Escriu el teu missatge…"></textarea>
      <button id="contactSend" class="primary" type="submit">Envia el missatge</button>
    </form>
    <p class="contact-note">L’accés és privat per a aquest avís i aquest navegador. No comparteixis contrasenyes ni dades bancàries.</p>
  </section>
</main>

<script>
  window.EL_FAR_CONTACT_MESSAGES_URL = <?php echo json_encode(route('alerts.messages.index', $alert), 512) ?>;
  window.EL_FAR_CONTACT_SEND_URL = <?php echo json_encode(route('alerts.messages.store', $alert), 512) ?>;
</script>
<script src="<?php echo e(asset('js/alert-contact.js')); ?>?v=2"></script>
</body>
</html>
<?php /**PATH /home/mcastiel/Escriptori/projecte_solidari_el_far/resources/views/alerts/contact.blade.php ENDPATH**/ ?>