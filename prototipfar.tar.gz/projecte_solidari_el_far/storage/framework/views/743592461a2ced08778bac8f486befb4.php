<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icons/apple-touch-icon.png')); ?>">
  <title>Inicia sessió · El Far</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=2">
</head>
<body>
  <main class="auth-shell">
    <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Compte personal</small></span></a>
    <section class="auth-card">
      <p class="eyebrow">COMPTE PERSONAL</p>
      <h1>Inicia sessió</h1>
      <p class="muted">Consulta els avisos vinculats al teu compte des de qualsevol dispositiu.</p>
      <?php if($errors->any()): ?>
        <p class="notice error" role="alert"><?php echo e($errors->first()); ?></p>
      <?php endif; ?>
      <form method="post" action="<?php echo e(route('account.login.store')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email">Correu electrònic</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required autofocus>
        <label for="password">Contrasenya</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
        <button class="button primary" type="submit">Entra al meu compte</button>
      </form>
    </section>
    <p>Encara no tens compte? <a class="back-link" href="<?php echo e(route('account.register')); ?>">Crea'n un</a></p>
    <a class="back-link" href="<?php echo e(route('home')); ?>">← Torna a El Far</a>
  </main>
</body>
</html>
<?php /**PATH /home/mcastiel/Escriptori/projecte_solidari_el_far/resources/views/account/login.blade.php ENDPATH**/ ?>