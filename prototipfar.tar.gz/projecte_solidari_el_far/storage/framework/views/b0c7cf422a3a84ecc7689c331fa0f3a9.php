<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#102b3f">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="format-detection" content="telephone=no">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icons/apple-touch-icon.png')); ?>">
  <title>Gestió d’avisos · El Far</title>
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=2">
</head>
<body>
  <header class="topbar">
    <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Gestió d’avisos</small></span></a>
    <form method="post" action="<?php echo e(route('admin.logout')); ?>">
      <?php echo csrf_field(); ?>
      <button class="button secondary" type="submit">Tanca la sessió</button>
    </form>
  </header>
  <main class="dashboard">
    <div class="page-heading">
      <div><p class="eyebrow">TAULER D’ADMINISTRACIÓ</p><h1>Avisos rebuts</h1><p class="muted">Consulta i actualitza l’estat dels avisos.</p></div>
      <a class="button secondary" href="<?php echo e(route('admin.alerts.resolved')); ?>">Avisos resolts</a>
      <a class="button secondary" href="<?php echo e(route('home')); ?>">Vista pública</a>
    </div>
    <section class="summary-grid" aria-label="Resum d’avisos">
      <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="summary-card"><span><?php echo e($label); ?></span><strong><?php echo e($counts[$key] ?? 0); ?></strong></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
    <?php if(session('status-message')): ?>
      <p class="notice success" role="status"><?php echo e(session('status-message')); ?></p>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <p class="notice error" role="alert"><?php echo e($errors->first()); ?></p>
    <?php endif; ?>
    <section class="panel">
      <form class="filter-form" method="get" action="<?php echo e(route('admin.alerts.index')); ?>">
        <label for="status-filter">Estat</label>
        <select id="status-filter" name="status">
          <option value="">Tots</option>
          <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($filters['status'] === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="category-filter">Categoria</label>
        <select id="category-filter" name="category">
          <option value="">Totes</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($filters['category'] === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="confidence-filter">Confiança</label>
        <select id="confidence-filter" name="confidence">
          <option value="">Tots</option>
          <?php $__currentLoopData = ['high' => 'Alta', 'medium' => 'Mitjana', 'low' => 'Baixa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($key); ?>" <?php if($filters['confidence'] === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="type-filter">Urgència</label>
        <select id="type-filter" name="type">
          <option value="">Totes</option>
          <option value="urgent" <?php if($filters['type'] === 'urgent'): echo 'selected'; endif; ?>>Urgent</option>
          <option value="normal" <?php if($filters['type'] === 'normal'): echo 'selected'; endif; ?>>Normal</option>
        </select>
        <label for="date-from">Des de</label>
        <input id="date-from" type="date" name="date_from" value="<?php echo e($filters['date_from']); ?>">
        <label for="date-to">Fins a</label>
        <input id="date-to" type="date" name="date_to" value="<?php echo e($filters['date_to']); ?>">
        <button class="button secondary" type="submit">Filtra</button>
      </form>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Avís</th><th>Ubicació GPS</th><th>Confiança algorítmica</th><th>Rebut</th><th>Estat i decisió humana</th></tr></thead>
          <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td>
                <strong><?php echo e($alert->description ?: 'Incidència sense detalls'); ?></strong>
                <small>ID <?php echo e($alert->id); ?> · <?php echo e($categories[$alert->category] ?? $alert->category); ?> · <?php echo e($alert->type === 'urgent' ? 'Urgent' : 'Normal'); ?> · Risc <?php echo e($alert->risk_level); ?></small>
                <small>Reporter anònim <?php echo e($alert->reporter_id ? substr($alert->reporter_id, 0, 8) : 'no identificat'); ?></small>
                <a class="button secondary" href="<?php echo e(route('admin.alerts.conversation', $alert)); ?>">Missatges privats</a>
              </td>
              <td>
                <?php if($alert->latitude !== null && $alert->longitude !== null): ?>
                  <?php echo e(number_format((float) $alert->latitude, 6)); ?>, <?php echo e(number_format((float) $alert->longitude, 6)); ?>

                  <small>Precisió GPS reportada ±<?php echo e($alert->accuracy ?? '—'); ?> m</small>
                <?php else: ?>
                  <span class="muted">No indicada</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if($alert->confidence_score !== null): ?>
                  <span class="status-chip confidence-<?php echo e($alert->confidence_level); ?>"><?php echo e($alert->confidence_score); ?>/100 · <?php echo e(['high' => 'Alta', 'medium' => 'Mitjana', 'low' => 'Baixa'][$alert->confidence_level] ?? $alert->confidence_level); ?></span>
                  <?php if($alert->latestVerification): ?>
                    <?php ($evidence = $alert->latestVerification->evidence_details); ?>
                    <?php ($nearbyMatches = $evidence['nearby_matches'] ?? []); ?>
                    <?php ($external = $evidence['external'] ?? []); ?>
                    <small>Emissor: <?php echo e($alert->latestVerification->user_reliability_score ?? '—'); ?>/100 (<?php echo e($evidence['reporter_history']['verified'] ?? 0); ?> verificats) · Incidents: <?php echo e($alert->latestVerification->nearby_incidents_score ?? '—'); ?> · GPS: <?php echo e($alert->latestVerification->geographic_score ?? 'no disponible'); ?> · Temps: <?php echo e($alert->latestVerification->temporal_score ?? '—'); ?> · Categoria: <?php echo e($alert->latestVerification->category_score ?? '—'); ?></small>
                    <small>Anàlisis generada: <?php echo e($alert->verification_updated_at?->format('d/m/Y H:i:s') ?? '—'); ?></small>
                    <small>Incidents propers independents: <?php echo e(count($nearbyMatches)); ?></small>
                    <?php $__currentLoopData = $nearbyMatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <small><?php echo e($match['distance_meters']); ?> m · <?php echo e($categories[$match['category']] ?? $match['category']); ?> · <?php echo e($match['description']); ?></small>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <small>Evidència externa: <?php echo e($external['status'] ?? 'no disponible'); ?><?php if(!empty($external['reason'])): ?> · <?php echo e($external['reason']); ?><?php endif; ?></small>
                    <small><?php echo e($evidence['calculation']['explanation'] ?? ''); ?></small>
                    <?php if(!empty($alert->latestVerification->missing_evidence)): ?>
                      <small>Evidència absent: <?php echo e(implode(', ', $alert->latestVerification->missing_evidence)); ?></small>
                    <?php endif; ?>
                  <?php endif; ?>
                <?php else: ?>
                  <span class="muted">No calculada</span>
                <?php endif; ?>
              </td>
              <td><?php echo e($alert->received_at?->format('d/m/Y H:i') ?? '—'); ?></td>
              <td>
                <span class="status-chip status-<?php echo e($alert->status); ?>"><?php echo e($statuses[$alert->status] ?? $alert->status); ?></span>
                <form class="status-form" method="post" action="<?php echo e(route('admin.alerts.status', $alert)); ?>">
                  <?php echo csrf_field(); ?>
                  <label class="sr-only" for="status-<?php echo e($loop->index); ?>">Estat de l’avís</label>
                  <select id="status-<?php echo e($loop->index); ?>" name="status">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($key); ?>" <?php if($alert->status === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <button class="button primary" type="submit">Desa</button>
                </form>
                <small>Decisió humana: <?php echo e($alert->latestVerificationResult ? ['confirmed' => 'Confirmat', 'false_report' => 'Avís fals', 'inconclusive' => 'Inconclús'][$alert->latestVerificationResult->result] : 'Pendent'); ?></small>
                <?php if($alert->latestVerificationResult): ?>
                  <small><?php echo e($alert->latestVerificationResult->verifier_id); ?> · <?php echo e($alert->latestVerificationResult->created_at?->format('d/m/Y H:i')); ?></small>
                  <?php if($alert->latestVerificationResult->notes): ?>
                    <small><?php echo e($alert->latestVerificationResult->notes); ?></small>
                  <?php endif; ?>
                <?php endif; ?>
                <details class="verify-details">
                  <summary>Registrar decisió humana</summary>
                  <form method="post" action="<?php echo e(route('admin.alerts.verify', $alert)); ?>">
                    <?php echo csrf_field(); ?>
                    <label class="sr-only" for="result-<?php echo e($loop->index); ?>">Resultat de verificació humana</label>
                    <select id="result-<?php echo e($loop->index); ?>" name="result" required>
                      <option value="">Selecciona el resultat</option>
                      <option value="confirmed">Confirmat</option>
                      <option value="false_report">Avís fals</option>
                      <option value="inconclusive">Inconclús</option>
                    </select>
                    <label class="sr-only" for="notes-<?php echo e($loop->index); ?>">Notes de verificació</label>
                    <textarea id="notes-<?php echo e($loop->index); ?>" name="notes" maxlength="1200" placeholder="Notes (opcional)"></textarea>
                    <button class="button secondary" type="submit">Registra decisió</button>
                  </form>
                </details>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td class="empty" colspan="5">No s’han trobat avisos.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="pagination"><?php echo e($alerts->links()); ?></div>
    </section>
  </main>
</body>
</html>
<?php /**PATH /home/mcastiel/Escriptori/projecte_solidari_el_far/resources/views/admin/alerts.blade.php ENDPATH**/ ?>