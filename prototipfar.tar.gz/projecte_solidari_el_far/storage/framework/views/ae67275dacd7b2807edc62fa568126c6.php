<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <meta name="background-color" content="#f3f7f9">
  <meta name="description" content="Comunica incidències al Far de manera ràpida i accessible.">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="El Far">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="format-detection" content="telephone=no">
  <title>Projecte Solidari · El Far</title>
  <link rel="manifest" href="<?php echo e(asset('manifest.webmanifest')); ?>">
  <link rel="icon" href="<?php echo e(asset('icons/icon.svg')); ?>" type="image/svg+xml">
  <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('icons/icon-192.png')); ?>">
  <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icons/apple-touch-icon.png')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>?v=14">
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
</head>
<body>
<header class="topbar">
  <a class="brand" href="#" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <nav class="account-nav" aria-label="Compte">
    <a class="account-link" href="<?php echo e(route('chat.index')); ?>">Xat</a>
    <?php if($accountUser): ?>
      <span class="account-greeting"><?php echo e($accountUser->name); ?></span>
      <form method="post" action="<?php echo e(route('account.logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="account-link" type="submit">Surt</button>
      </form>
    <?php else: ?>
      <a class="account-link" href="<?php echo e(route('account.login')); ?>">Inicia sessió</a>
      <a class="account-link account-link-primary" href="<?php echo e(route('account.register')); ?>">Crea un compte</a>
    <?php endif; ?>
  </nav>
  <button id="installBtn" class="install hidden" type="button">Instal·la l'app</button>
  <details class="install-help">
    <summary>Com instal·lar</summary>
    <p><strong>iPhone o iPad:</strong> obre aquesta pàgina a Safari, toca Compartir i tria “Afegir a la pantalla d’inici”.</p>
    <p><strong>Android:</strong> obre el menú de Chrome i tria “Instal·la l’aplicació” o “Afegeix a la pantalla d’inici”.</p>
    <p>La instal·lació requereix HTTPS.</p>
  </details>
</header>
<main>
  <?php if(session('account_notice')): ?>
    <p class="account-notice" role="status"><?php echo e(session('account_notice')); ?></p>
  <?php endif; ?>
  <section class="hero">
    <p class="eyebrow">AJUDA RÀPIDA</p>
    <h1>Necessites ajuda?</h1>
    <p class="intro">Toca el botó. Explica què passa i comparteix la teva ubicació perquè l'equip pugui ajudar.</p>
  </section>

  <section class="map-panel panel" aria-labelledby="liveMapTitle">
    <div class="map-header">
      <div>
        <p class="eyebrow">MAPA EN DIRECTE</p>
        <h2 id="liveMapTitle">Avisos actius</h2>
      </div>
      <div class="map-tools">
        <span id="alertCount" class="badge<?php echo e(count($initialMapAlerts) > 0 ? ' urgent' : ''); ?>"><?php echo e(count($initialMapAlerts)); ?> actius</span>
        <button id="refreshAlertsBtn" class="secondary map-refresh" type="button">Actualitza</button>
      </div>
    </div>
    <p id="mapRefreshStatus" class="map-refresh-status" role="status" aria-live="polite">Carregant avisos…</p>
    <div id="liveMap" class="live-map" aria-label="Mapa dels avisos actius">
      <p class="map-fallback">El mapa interactiu no està disponible. Consulta la llista d’avisos.</p>
    </div>
    <p class="map-attribution">Ubicacions aproximades per protegir la privacitat. Mapa © <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a>.</p>
    <ul id="alertList" class="alert-list" aria-live="polite">
      <?php if($initialMapAlerts === []): ?>
        <li class="alert-item"><span>No hi ha avisos actius.</span></li>
      <?php else: ?>
        <?php $__currentLoopData = $initialMapAlerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="alert-item">
            <div class="alert-meta">
              <span class="alert-pill <?php echo e($alert['type']); ?>"><?php echo e($alert['type'] === 'urgent' ? 'Urgent' : 'Normal'); ?></span>
              <strong><?php echo e($alert['title']); ?></strong>
            </div>
            <small><?php echo e($alert['user']); ?> · <?php echo e($alert['time']); ?></small>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </ul>
  </section>

  <section class="emergency-card" aria-labelledby="alertTitle">
    <div class="card-heading"><span class="status-dot"></span><span id="alertTitle">Avisar</span></div>
    <div class="alert-actions">
      <button id="normalBtn" class="alert-button" type="button">
        <span class="alert-icon">!</span><span><strong>Toca per avisar</strong><small>Primer comparteix la ubicació</small></span>
      </button>
      <button id="urgentBtn" class="urgent-button" type="button" aria-label="Mantén premut tres segons per preparar un avís urgent">EMERGÈNCIA</button>
    </div>
    <p class="hint">Si hi ha perill immediat per a una persona, truca directament al <a href="tel:112">112</a>. Aquesta web no substitueix els serveis d'emergència.</p>
  </section>

  <section class="panel my-alerts-panel" aria-labelledby="myAlertsTitle">
    <div class="panel-title"><div><p class="eyebrow"><?php echo e($accountUser ? 'AVISOS DEL COMPTE I D’AQUEST DISPOSITIU' : 'NOMÉS EN AQUEST DISPOSITIU'); ?></p><h2 id="myAlertsTitle">Els meus avisos</h2><p id="myAlertsNote" class="muted"><?php echo e($accountUser ? 'Els avisos enviats amb sessió iniciada se sincronitzen al teu compte.' : 'Crea un compte opcional per consultar els avisos enviats en altres dispositius.'); ?></p></div></div>
    <ul id="myAlertsList" class="draft-list" aria-live="polite"></ul>
  </section>

  <section id="reportPanel" class="panel hidden" aria-labelledby="reportTitle">
    <div class="panel-title"><div><p class="eyebrow">DETALLS DE L'AVÍS</p><h2 id="reportTitle">Afegeix informació</h2></div><span id="typeBadge" class="badge">Normal</span></div>
    <form id="reportForm">
      <div class="location-row">
        <div><b>Ubicació</b><p id="locationText">Encara no s'ha obtingut.</p></div>
        <button id="locateBtn" class="secondary" type="button">Obtenir ubicació</button>
      </div>
      <label for="userNameInput">Qui fa l'avís?</label>
      <div class="user-name-row">
        <input id="userNameInput" type="text" maxlength="40" placeholder="Nom o usuari" value="">
        <span class="trust-badge">La fiabilitat es calcula al servidor segons verificacions humanes.</span>
      </div>
      <label for="category">Categoria de l'incident</label>
      <select id="category" required>
        <option value="medical">Salut</option>
        <option value="fire">Incendi</option>
        <option value="safety">Seguretat</option>
        <option value="infrastructure">Infraestructura</option>
        <option value="other" selected>Altres</option>
      </select>
      <label for="riskLevel">Nivell de risc</label>
      <select id="riskLevel">
        <option value="possible">Possible perill</option>
        <option value="danger">Risc evident</option>
        <option value="urgent">Emergència immediata</option>
      </select>
      <label for="description">Detalls addicionals (opcional)</label>
      <textarea id="description" rows="3" maxlength="1200" placeholder="Pots afegir més informació després, si cal..."></textarea>
      <label class="check-row">
        <input id="confirmRealAlert" type="checkbox">
        <span>Confirma que aquest avís és real i no és una broma.</span>
      </label>
      <label class="check-row">
        <input id="confirmWitness" type="checkbox">
        <span>He verificat que hi ha una situació real o de perill.</span>
      </label>
      <label for="photoInput">Fotografia (opcional)</label>
      <input id="photoInput" type="file" accept="image/*" capture="environment">
      <label for="audioInput">Àudio (opcional)</label>
      <input id="audioInput" type="file" accept="audio/*" capture>
      <p class="privacy-note">Una ubicació GPS més precisa ajuda a prioritzar la revisió. Si no pots compartir-la, l'avís encara es pot enviar. La puntuació no substitueix la verificació humana.</p>
      <div class="form-actions">
        <button id="saveDraftBtn" class="secondary" type="button">Guardar per després</button>
        <button id="cancelBtn" class="secondary" type="button">Cancel·la</button>
        <button id="sendBtn" class="primary" type="submit">Envia l'avís</button>
      </div>
    </form>
  </section>

  <section id="confirmation" class="confirmation hidden" role="status" aria-live="polite">
    <div class="check">✓</div><h2>Avís preparat</h2><p id="confirmationText">La incidència s'ha registrat en aquest dispositiu.</p><button id="newReportBtn" class="primary" type="button">Torna a l'inici</button>
  </section>
</main>
<footer>
  <span>Projecte Solidari · Els Cracks</span>
  <span>Prototip web accessible</span>
</footer>
<div id="toast" class="toast" role="status" aria-live="polite"></div>
<script>window.EL_FAR_INITIAL_ALERTS = <?php echo json_encode($initialMapAlerts, 15, 512) ?>; window.EL_FAR_API_URL = <?php echo json_encode(url('/api/alerts'), 15, 512) ?>; window.EL_FAR_ACCOUNT_URL = <?php echo json_encode($accountUser ? route('account.alerts.index') : null, 15, 512) ?>; window.EL_FAR_ALERT_CONTACT_BASE_URL = <?php echo json_encode(url('/alerts'), 15, 512) ?>; window.EL_FAR_SW_URL = <?php echo json_encode(url('/sw.js'), 15, 512) ?>;</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script src="<?php echo e(asset('js/app.js')); ?>?v=18"></script>
</body>
</html><?php /**PATH /home/mcastiel/Escriptori/projecte_solidari_el_far/resources/views/home.blade.php ENDPATH**/ ?>