<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    // SHA-256 of the secret kept in the visitor's cookie. Only set for anonymous chat identities.
    Schema::table('users', function (Blueprint $table): void {
      $table->string('access_hash', 64)->nullable()->unique();
    });
  }

  public function down(): void
  {
    Schema::table('users', function (Blueprint $table): void {
      $table->dropUnique(['access_hash']);
      $table->dropColumn('access_hash');
    });
  }
};
