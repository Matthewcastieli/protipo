<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::table('alerts', function (Blueprint $table): void {
      $table->index(['status', 'received_at'], 'alerts_status_received_at_index');
    });
  }

  public function down(): void
  {
    Schema::table('alerts', function (Blueprint $table): void {
      $table->dropIndex('alerts_status_received_at_index');
    });
  }
};
