<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::create('alerts', function (Blueprint $table): void {
      $table->string('id', 80)->primary();
      $table->string('type', 16);
      $table->string('description', 1200);
      $table->string('user', 40)->default('Usuari');
      $table->string('risk_level', 16)->default('possible');
      $table->decimal('latitude', 10, 7)->nullable();
      $table->decimal('longitude', 10, 7)->nullable();
      $table->unsignedInteger('accuracy')->nullable();
      $table->timestamp('client_created_at')->nullable();
      $table->timestamp('received_at')->index();
    });
  }

  public function down(): void
  {
    Schema::dropIfExists('alerts');
  }
};
