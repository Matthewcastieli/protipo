<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::table('users', function (Blueprint $table): void {
      $table->string('role', 24)->default('user')->after('password');
      $table->index('role');
    });

    Schema::create('conversations', function (Blueprint $table): void {
      $table->id();
      $table->string('title', 160)->nullable();
      $table->boolean('is_group')->default(false);
      $table->unsignedInteger('created_by')->nullable()->index();
      $table->timestamp('last_message_at')->nullable();
      $table->timestamps();
    });

    Schema::create('conversation_participants', function (Blueprint $table): void {
      $table->id();
      $table->foreignId('conversation_id')->constrained()->cascadeOnDelete();
      $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
      $table->timestamp('read_at')->nullable();
      $table->timestamps();
      $table->unique(['conversation_id', 'user_id']);
      $table->index(['user_id', 'read_at']);
    });

    Schema::create('messages', function (Blueprint $table): void {
      $table->id();
      $table->foreignId('conversation_id')->constrained()->cascadeOnDelete();
      $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
      $table->text('body');
      $table->timestamp('read_at')->nullable();
      $table->timestamps();
      $table->index(['conversation_id', 'created_at']);
      $table->index('user_id');
    });

    Schema::create('help_requests', function (Blueprint $table): void {
      $table->id();
      $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
      $table->string('title', 160);
      $table->text('description');
      $table->string('category', 24)->default('other');
      $table->string('status', 24)->default('open');
      $table->timestamp('closed_at')->nullable();
      $table->timestamps();
      $table->index(['status', 'created_at']);
      $table->index('user_id');
    });

    Schema::create('help_request_responses', function (Blueprint $table): void {
      $table->id();
      $table->foreignId('help_request_id')->constrained()->cascadeOnDelete();
      $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
      $table->text('body');
      $table->timestamps();
      $table->index(['help_request_id', 'created_at']);
    });
  }

  public function down(): void
  {
    Schema::dropIfExists('help_request_responses');
    Schema::dropIfExists('help_requests');
    Schema::dropIfExists('messages');
    Schema::dropIfExists('conversation_participants');
    Schema::dropIfExists('conversations');

    Schema::table('users', function (Blueprint $table): void {
      $table->dropIndex(['role']);
      $table->dropColumn(['role']);
    });
  }
};
