<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::table('alerts', function (Blueprint $table): void {
      $table->string('category', 24)->default('other');
      $table->uuid('reporter_id')->nullable()->index();
      $table->unsignedTinyInteger('confidence_score')->nullable();
      $table->string('confidence_level', 16)->nullable();
      $table->timestamp('verification_updated_at')->nullable();
      $table->index(['category', 'received_at']);
      $table->index(['latitude', 'longitude']);
    });

    Schema::create('alert_verifications', function (Blueprint $table): void {
      $table->id();
      $table->string('alert_id', 80);
      $table->unsignedTinyInteger('user_reliability_score')->nullable();
      $table->unsignedTinyInteger('nearby_incidents_score')->nullable();
      $table->unsignedTinyInteger('geographic_score')->nullable();
      $table->unsignedTinyInteger('temporal_score')->nullable();
      $table->unsignedTinyInteger('category_score')->nullable();
      $table->unsignedTinyInteger('final_confidence_score');
      $table->string('confidence_level', 16);
      $table->json('evidence_details');
      $table->json('missing_evidence');
      $table->timestamp('created_at')->useCurrent();
      $table->foreign('alert_id')->references('id')->on('alerts')->cascadeOnDelete();
      $table->index(['alert_id', 'created_at']);
    });

    Schema::create('alert_verification_results', function (Blueprint $table): void {
      $table->id();
      $table->string('alert_id', 80);
      $table->string('verifier_id', 255);
      $table->string('result', 24);
      $table->string('notes', 1200)->nullable();
      $table->timestamp('created_at')->useCurrent();
      $table->foreign('alert_id')->references('id')->on('alerts')->cascadeOnDelete();
      $table->index(['alert_id', 'created_at']);
    });
  }

  public function down(): void
  {
    Schema::dropIfExists('alert_verification_results');
    Schema::dropIfExists('alert_verifications');

    Schema::table('alerts', function (Blueprint $table): void {
      $table->dropIndex(['category', 'received_at']);
      $table->dropIndex(['latitude', 'longitude']);
      $table->dropIndex(['reporter_id']);
      $table->dropColumn([
        'category',
        'reporter_id',
        'confidence_score',
        'confidence_level',
        'verification_updated_at',
      ]);
    });
  }
};
