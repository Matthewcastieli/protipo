<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  public function up(): void
  {
    Schema::create('alert_conversations', function (Blueprint $table): void {
      $table->id();
      $table->string('alert_id', 80)->unique();
      $table->string('access_token_hash', 64);
      $table->timestamp('access_token_expires_at');
      $table->timestamp('last_message_at')->nullable();
      $table->timestamps();
      $table->foreign('alert_id')->references('id')->on('alerts')->cascadeOnDelete();
    });

    Schema::create('alert_conversation_messages', function (Blueprint $table): void {
      $table->id();
      $table->foreignId('alert_conversation_id')->constrained()->cascadeOnDelete();
      $table->string('sender_type', 16);
      $table->string('admin_email', 255)->nullable();
      $table->text('body');
      $table->timestamp('created_at')->useCurrent();
      $table->index(['alert_conversation_id', 'created_at']);
    });
  }

  public function down(): void
  {
    Schema::dropIfExists('alert_conversation_messages');
    Schema::dropIfExists('alert_conversations');
  }
};
