<?php

use Illuminate\Support\Facades\Schedule;

Schedule::command('chat:prune-anonymous')->daily();
