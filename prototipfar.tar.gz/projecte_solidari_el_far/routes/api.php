<?php

use App\Http\Controllers\Api\AlertController;
use App\Http\Controllers\AlertConversationController;
use App\Http\Controllers\Chat\ChatConversationController;
use App\Http\Controllers\Chat\ChatMessageController;
use App\Http\Controllers\Chat\HelpRequestController;
use Illuminate\Support\Facades\Route;

Route::get('/alerts', [AlertController::class, 'index']);
Route::post('/alerts', [AlertController::class, 'store'])
  ->middleware([
    App\Http\Middleware\ThrottleNonUrgentAlerts::class,
    Illuminate\Cookie\Middleware\EncryptCookies::class,
    Illuminate\Session\Middleware\StartSession::class,
    'alert.reporter',
  ]);

Route::middleware([
  Illuminate\Cookie\Middleware\EncryptCookies::class,
  Illuminate\Session\Middleware\StartSession::class,
  'alert.reporter',
])->group(function (): void {
  Route::get('/alerts/{alert}/messages', [AlertConversationController::class, 'reporterMessages'])
    ->middleware('throttle:60,1')
    ->name('alerts.messages.index');
  Route::post('/alerts/{alert}/messages', [AlertConversationController::class, 'storeReporterMessage'])
    ->middleware('throttle:10,1')
    ->name('alerts.messages.store');
});

// Chat JSON API: signed-in accounts, or an anonymous identity resolved from the far_chat cookie hash.
Route::middleware([
  Illuminate\Cookie\Middleware\EncryptCookies::class,
  Illuminate\Session\Middleware\StartSession::class,
  'chat.user',
])->group(function (): void {
  Route::name('chat.')->group(function (): void {
    Route::get('/chat/conversations', [ChatConversationController::class, 'index'])->name('conversations.index');
    Route::post('/chat/conversations', [ChatConversationController::class, 'store'])
      ->middleware('throttle:10,1')
      ->name('conversations.store');
    Route::get('/chat/conversations/{conversation}', [ChatConversationController::class, 'show'])->name('conversations.show');
    Route::get('/chat/conversations/{conversation}/messages', [ChatMessageController::class, 'index'])->name('messages.index');
    Route::post('/chat/conversations/{conversation}/messages', [ChatMessageController::class, 'store'])
      ->middleware('throttle:30,1')
      ->name('messages.store');
    Route::get('/chat/users', [ChatMessageController::class, 'users'])->name('users');
  });

  // Prefixed names so they never collide with the web routes of the same name.
  Route::name('api.chat.')->group(function (): void {
    Route::get('/chat/help-requests', [HelpRequestController::class, 'index'])->name('help_requests.index');
    Route::post('/chat/help-requests', [HelpRequestController::class, 'store'])->name('help_requests.store');
    Route::get('/chat/help-requests/{helpRequest}/responses', [HelpRequestController::class, 'responses'])->name('help_requests.responses');
    Route::post('/chat/help-requests/{helpRequest}/respond', [HelpRequestController::class, 'respond'])->name('help_requests.respond');
    Route::post('/chat/help-requests/{helpRequest}/close', [HelpRequestController::class, 'close'])->name('help_requests.close');
  });
});
