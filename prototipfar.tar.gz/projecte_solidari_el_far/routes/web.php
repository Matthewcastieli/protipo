<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\Account\AccountAlertController;
use App\Http\Controllers\Account\AccountController;
use App\Http\Controllers\AlertConversationController;
use App\Http\Controllers\Admin\AlertManagementController;
use App\Http\Controllers\Admin\AdminLoginController;
use App\Http\Controllers\Chat\ChatConversationController;
use App\Http\Controllers\Chat\ChatMessageController;
use App\Http\Controllers\Chat\HelpRequestController;
use App\Http\Middleware\EnsureRole;
use Illuminate\Support\Facades\Route;

Route::get('/', HomeController::class)->name('home');
Route::get('/alerts/{alert}/contact', [AlertConversationController::class, 'showReporter'])
  ->middleware('alert.reporter')
  ->name('alerts.contact');

Route::prefix('account')->name('account.')->group(function (): void {
  Route::get('/login', [AccountController::class, 'showLogin'])->name('login');
  Route::post('/login', [AccountController::class, 'login'])
    ->middleware('throttle:10,1')
    ->name('login.store');
  Route::get('/register', [AccountController::class, 'showRegistration'])->name('register');
  Route::post('/register', [AccountController::class, 'register'])
    ->middleware('throttle:5,1')
    ->name('register.store');
});

Route::middleware('account.user')->prefix('account')->name('account.')->group(function (): void {
  Route::post('/logout', [AccountController::class, 'logout'])->name('logout');
  Route::get('/alerts', [AccountAlertController::class, 'index'])->name('alerts.index');
  Route::put('/alerts/{alert}', [AccountAlertController::class, 'update'])->name('alerts.update');
});

Route::get('/admin/login', [AdminLoginController::class, 'create'])->name('admin.login');
Route::post('/admin/login', [AdminLoginController::class, 'store'])
  ->middleware('throttle:5,1')
  ->name('admin.login.store');

Route::middleware('alert.admin')->prefix('admin')->name('admin.')->group(function (): void {
  Route::post('/logout', [AdminLoginController::class, 'destroy'])->name('logout');
  Route::get('/alerts', [AlertManagementController::class, 'index'])->name('alerts.index');
  Route::get('/alerts/{alert}/conversation', [AlertConversationController::class, 'showAdmin'])
    ->name('alerts.conversation');
  Route::post('/alerts/{alert}/conversation', [AlertConversationController::class, 'storeAdminMessage'])
    ->middleware('throttle:10,1')
    ->name('alerts.conversation.store');
  Route::post('/alerts/{alert}/status', [AlertManagementController::class, 'updateStatus'])
    ->name('alerts.status');
  Route::post('/alerts/{alert}/verify', [AlertManagementController::class, 'verify'])
    ->middleware('throttle:30,1')
    ->name('alerts.verify');
  Route::get('/alerts/resolved', [AlertManagementController::class, 'resolved'])->name('alerts.resolved');
});

// Chat works without logging in: the visitor gets an anonymous identity from a cookie hash (see EnsureChatUser).
Route::middleware('chat.user')->name('chat.')->group(function (): void {
  Route::get('/chat', [ChatConversationController::class, 'index'])->name('index');
  Route::get('/chat/help-requests', [HelpRequestController::class, 'index'])->name('help_requests.index');
  Route::post('/chat/help-requests', [HelpRequestController::class, 'store'])->name('help_requests.store');
  Route::get('/chat/help-requests/{helpRequest}/responses', [HelpRequestController::class, 'responses'])->name('help_requests.responses');
  Route::post('/chat/help-requests/{helpRequest}/respond', [HelpRequestController::class, 'respond'])->name('help_requests.respond');
  Route::post('/chat/help-requests/{helpRequest}/close', [HelpRequestController::class, 'close'])->name('help_requests.close');
});

Route::middleware(['account.user', EnsureRole::class . ':worker,volunteer,admin'])->name('chat.')->group(function (): void {
  Route::get('/chat/workers', function () {
    $accountUser = \Illuminate\Support\Facades\Auth::guard('web')->user();
    $workers = \App\Models\User::query()->where('role', 'worker')->orderBy('name')->get();
    $volunteers = \App\Models\User::query()->where('role', 'volunteer')->orderBy('name')->get();

    return view('chat.workers', ['accountUser' => $accountUser, 'workers' => $workers, 'volunteers' => $volunteers]);
  })->name('workers');
});

Route::get('/chat/conversations/{conversation}', [ChatConversationController::class, 'show'])
  ->middleware('chat.user')
  ->name('conversations.show');
