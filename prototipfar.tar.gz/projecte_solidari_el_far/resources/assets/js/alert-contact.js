(() => {
  const $ = (id) => document.getElementById(id);
  const messages = $("contactMessages"), form = $("contactForm"), input = $("contactBody"), sendBtn = $("contactSend"), status = $("contactStatus");
  if (!messages || !form || !input || !sendBtn || !status) return;

  const json = (url, opts) => fetch(url, { credentials: "same-origin", headers: { Accept: "application/json", ...(opts?.body && { "Content-Type": "application/json" }) }, ...opts });
  const el = (tag, cls, text) => Object.assign(document.createElement(tag), { className: cls, textContent: text });

  function display(items) {
    messages.replaceChildren();
    if (!items.length) {
      return messages.append(el("p", "contact-empty", "Encara no hi ha missatges. Pots escriure a l’equip de manera privada."));
    }
    for (const item of items) {
      const you = item.sender === "you";
      const date = item.createdAt
        ? new Date(item.createdAt).toLocaleString([], { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })
        : "";
      const m = el("article", `contact-message ${you ? "you" : "team"}`);
      m.append(el("span", "", item.body), el("small", "", `${you ? "Tu" : "Equip El Far"}${date ? ` · ${date}` : ""}`));
      messages.append(m);
    }
    messages.scrollTop = messages.scrollHeight;
  }

  async function load() {
    try {
      const res = await json(window.EL_FAR_CONTACT_MESSAGES_URL, { cache: "no-store" });
      if (!res.ok) {
        status.textContent = res.status === 404
          ? "No es pot validar l’accés a aquesta conversa. Torna a Els meus avisos i obre l’enllaç des d’aquest navegador."
          : "No s’han pogut carregar els missatges.";
        return;
      }
      const { messages: list } = await res.json();
      display(Array.isArray(list) ? list : []);
      status.textContent = "";
    } catch {
      status.textContent = "Sense connexió. Els missatges es tornaran a carregar quan hi hagi xarxa.";
    }
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = input.value.trim();
    if (!body) {
      status.textContent = "Escriu un missatge abans d’enviar-lo.";
      return;
    }
    sendBtn.disabled = true;
    status.textContent = "Enviant…";
    try {
      const res = await json(window.EL_FAR_CONTACT_SEND_URL, { method: "POST", body: JSON.stringify({ body }) });
      const payload = await res.json();
      if (!res.ok) {
        status.textContent = payload.message || "No s’ha pogut enviar el missatge.";
        return;
      }
      input.value = "";
      await load();
    } catch {
      status.textContent = "No s’ha pogut contactar amb l’equip. Torna-ho a provar.";
    } finally {
      sendBtn.disabled = false;
    }
  });

  load();
  setInterval(load, 5000);
})();
