const CACHE = "elfar-v20";
const ASSETS = [
  "./",
  "./css/app.css",
  "./js/app.js",
  "./manifest.webmanifest",
  "./icons/icon.svg",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./icons/apple-touch-icon.png",
];

// Network-only: admin pages, private chats (alert and user chat) and the alerts API.
const bypass = (p) => p.startsWith("/admin") || p.startsWith("/chat") || p.startsWith("/api/chat") || (p.startsWith("/alerts/") && p.endsWith("/contact")) || p.endsWith("/api/alerts");

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith("elfar-") && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const { request } = e;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin || bypass(url.pathname)) return;

  e.respondWith((async () => {
    const cache = await caches.open(CACHE);

    if (request.mode === "navigate") {
      try {
        const res = await fetch(request);
        if (res.ok) await cache.put(request, res.clone());
        return res;
      } catch (err) {
        const offline = (await cache.match(request)) || (await cache.match("./"));
        if (offline) return offline;
        throw err;
      }
    }

    return (await cache.match(request, { ignoreSearch: true })) || fetch(request);
  })());
});
