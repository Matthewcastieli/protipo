const $ = (id) => document.getElementById(id);
const el = (tag, cls, text, ...kids) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  e.append(...kids);
  return e;
};
const W = window;
const SHARED = "far_shared_alerts";
const MINE = "far_my_alerts";
const API = () => W.EL_FAR_API_URL || "/api/alerts";
const TXT_NO_LOC = "Encara no s'ha obtingut.";
const TXT_SEND = "Envia l'avís";
const TXT_NO_DETAILS = "Avís sense detalls";
const S = {
  urgent: false, coords: null, pressTimer: null, holdTriggered: false, lastTap: 0,
  deferredPrompt: null, watchId: null, editingAlertId: null, liveMap: null, markerLayer: null,
  hasFittedMap: false, refreshing: false, syncing: false, accountAlerts: [],
};
const panel = $("reportPanel");
const confirmation = $("confirmation");
const urgentBtn = $("urgentBtn");
const normalBtn = $("normalBtn");
const form = $("reportForm");
const locationText = $("locationText");

const show = (node, on) => node.classList.toggle("hidden", !on);
const reveal = (node, block) => node.scrollIntoView({ behavior: "smooth", block });
const label = (urgent) => (urgent ? "Urgent" : "Normal");
const fmt = (c) => `${(+c.latitude).toFixed(5)}, ${(+c.longitude).toFixed(5)}`;
const setLoc = (c) => { locationText.textContent = c ? `${fmt(c)} (precisió aproximada ±${c.accuracy ?? 30} m)` : TXT_NO_LOC; };
const hhmm = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

function toast(message) {
  const t = $("toast");
  t.textContent = message;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 3200);
}

function setBadge() {
  $("typeBadge").textContent = label(S.urgent);
  $("typeBadge").classList.toggle("urgent", S.urgent);
  $("reportTitle").textContent = S.urgent ? "Avís d'emergència" : "Afegeix informació";
}

const readList = (key) => {
  try {
    const v = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
};
const writeList = (key, v) => localStorage.setItem(key, JSON.stringify(v));
const without = (key, id) => readList(key).filter((a) => a.id !== id);

function userName() {
  const input = $("userNameInput");
  const name = ((input && input.value.trim()) || localStorage.getItem("far_user_name") || "Usuari").trim() || "Usuari";
  localStorage.setItem("far_user_name", name);
  if (input) input.value = name;
  return name;
}

function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 15) | 64;
  b[8] = (b[8] & 63) | 128;
  const h = [...b].map((x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

function parseCoords(e) {
  const l = e.location || {};
  const latitude = Number(l.latitude ?? e.lat ?? e.latitude);
  const longitude = Number(l.longitude ?? e.lng ?? e.longitude);
  return { latitude, longitude, ok: Number.isFinite(latitude) && Number.isFinite(longitude), accuracy: Number(l.accuracy ?? e.accuracy) };
}

function migrateLegacy() {
  const legacy = readList("far_pending_alerts");
  if (!legacy.length) return;
  const pending = readList(SHARED);
  const ids = new Set(pending.map((a) => a.id));
  const migrated = [];

  for (const e of legacy) {
    if (!e || typeof e !== "object") continue;
    const { latitude, longitude, ok, accuracy } = parseCoords(e);
    const id = typeof e.id === "string" && e.id.length > 0 && e.id.length <= 80 ? e.id : uuid();
    if (ids.has(id)) continue;
    ids.add(id);
    const inRange = ok && Math.abs(latitude) <= 90 && Math.abs(longitude) <= 180;
    const alert = {
      id,
      type: e.type === "urgent" ? "urgent" : "normal",
      description: String(e.description || e.title || TXT_NO_DETAILS).slice(0, 1200),
      user: String(e.user || "Usuari").slice(0, 40),
      category: ["medical", "fire", "safety", "infrastructure", "other"].includes(e.category) ? e.category : "other",
      riskLevel: ["possible", "danger", "urgent"].includes(e.riskLevel) ? e.riskLevel : "possible",
      location: inRange
        ? { latitude, longitude, ...(Number.isInteger(accuracy) && accuracy >= 0 && accuracy <= 1e5 ? { accuracy } : {}) }
        : null,
      createdAt: Number.isFinite(Date.parse(e.createdAt || e.receivedAt)) ? e.createdAt || e.receivedAt : new Date().toISOString(),
    };
    migrated.push(alert);
    remember(alert, "pending");
  }

  writeList(SHARED, [...pending, ...migrated]);
  localStorage.removeItem("far_pending_alerts");
}

function openReport(isUrgent = false) {
  S.urgent = isUrgent;
  setBadge();
  show(panel, true);
  show(confirmation, false);
  reveal(panel, "start");
  if (!S.coords) locate();
}

const riskLevel = () => ($("riskLevel") || {}).value || "possible";

function checkSafety(quick = false) {
  if (quick) {
    if (!W.confirm("Confirma que aquest avís és real i no és una broma. Aquesta comprovació ajuda a reduir avisos falsos.")) {
      return "Avís cancel·lat: verifica la situació abans d'enviar-lo.";
    }
  } else if (!$("confirmRealAlert")?.checked || !$("confirmWitness")?.checked) {
    return "Confirma que l'avís és real i que has verificat la situació.";
  }
  if (riskLevel() === "urgent" && !S.urgent) return "L'avís urgent s'ha de marcar com a emergència real abans d'enviar-lo.";
  return "";
}

const buildAlert = (type) => ({
  id: S.editingAlertId || uuid(),
  type,
  description: ($("description")?.value || "").trim() || "Sense detalls addicionals",
  user: userName(),
  category: $("category").value,
  riskLevel: riskLevel(),
  location: S.coords,
  createdAt: new Date().toISOString(),
});

async function sendToServer(data) {
  try {
    const res = await fetch(API(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(data),
    });
    const body = await res.json();
    if (!res.ok) {
      return { ok: false, message: body.message || "No s'ha pogut registrar l'avís al servidor.", retryable: res.status === 429 || res.status >= 500 };
    }
    return { ok: true, message: body.message || "L'avís s'ha rebut al servidor.", confidence: body.confidence };
  } catch {
    return { ok: false, message: "No s'ha pogut contactar amb el servidor. L'avís s'ha desat temporalment en aquest dispositiu.", retryable: true };
  }
}

const statusOf = (r) => (r.ok ? "sent" : r.retryable ? "pending" : "rejected");

async function deliver(data) {
  const r = await sendToServer(data);
  const next = without(SHARED, data.id);
  if (!r.ok && r.retryable) next.push({ ...data, receivedAt: data.createdAt, user: data.user || "Usuari" });
  writeList(SHARED, next);
  remember(data, statusOf(r));
  renderMine();
  if (r.ok && W.EL_FAR_ACCOUNT_URL) loadAccountAlerts();
  return r;
}

async function syncPending() {
  if (S.syncing || navigator.onLine === false) return;
  const pending = readList(SHARED);
  if (!pending.length) return;
  S.syncing = true;
  const remaining = [];
  let updated = false;

  try {
    for (let i = 0; i < pending.length; i++) {
      const r = await sendToServer(pending[i]);
      if (!r.ok && r.retryable) {
        remaining.push(...pending.slice(i));
        break;
      }
      remember(pending[i], r.ok ? "sent" : "rejected");
      updated = true;
    }
    writeList(SHARED, remaining);
    if (updated) {
      renderMine();
      renderLiveMap();
      if (W.EL_FAR_ACCOUNT_URL) loadAccountAlerts();
    }
  } finally {
    S.syncing = false;
  }
}

normalBtn.addEventListener("click", async () => {
  S.urgent = false;
  setBadge();
  if (!S.coords && !(await locate())) return openReport(false);
  const problem = checkSafety(true);
  if (problem) {
    toast(problem);
    return openReport(false);
  }
  const data = buildAlert("normal");
  const r = await deliver(data);
  $("confirmationText").textContent = `${r.message} · ${data.user}`;
  show(confirmation, true);
  reveal(confirmation);
  toast(r.ok ? "Avís enviat correctament." : "Avís desat localment.");
});

function startHold(e) {
  e.preventDefault();
  S.holdTriggered = false;
  urgentBtn.classList.add("holding");
  S.pressTimer = setTimeout(() => {
    S.holdTriggered = true;
    openReport(true);
  }, 3000);
}

function endHold() {
  clearTimeout(S.pressTimer);
  urgentBtn.classList.remove("holding");
}

function urgentClick() {
  if (S.holdTriggered) {
    S.holdTriggered = false;
    return;
  }
  const now = Date.now();
  if (now - S.lastTap < 450) {
    openReport(true);
    S.lastTap = 0;
  } else {
    S.lastTap = now;
    toast("Fes un segon toc ràpid per preparar un avís urgent, o mantén premut 3 segons.");
  }
}

const on = (node, events, fn, opts) => events.forEach((n) => node.addEventListener(n, fn, opts));
on(urgentBtn, ["pointerdown"], startHold);
on(urgentBtn, ["pointerup", "pointerleave", "pointercancel"], endHold);
on(urgentBtn, ["click"], urgentClick);

if (!("PointerEvent" in W)) {
  on(urgentBtn, ["touchstart"], startHold, { passive: false });
  on(urgentBtn, ["touchend"], () => {
    const held = S.holdTriggered;
    endHold();
    if (held) S.holdTriggered = false;
    else urgentClick();
  });
  on(urgentBtn, ["touchcancel", "mouseup", "mouseleave"], endHold);
  on(urgentBtn, ["mousedown"], startHold);
}

function locate() {
  if (!("geolocation" in navigator)) {
    toast("Aquest navegador no permet obtenir la ubicació.");
    return false;
  }
  locationText.textContent = "Obtenint ubicació…";
  const opts = { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 };
  const setPos = ({ coords: c }) => {
    S.coords = { latitude: c.latitude, longitude: c.longitude, accuracy: Math.round(c.accuracy) };
    setLoc(S.coords);
  };

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setPos(p);
        if (S.watchId === null) S.watchId = navigator.geolocation.watchPosition(setPos, () => {}, opts);
        resolve(true);
      },
      (err) => {
        locationText.textContent = "No s'ha pogut obtenir. Pots continuar sense ubicació.";
        toast(err.code === 1 ? "Cal donar permís d'ubicació al navegador." : "No s'ha pogut obtenir la ubicació.");
        resolve(false);
      },
      opts
    );
  });
}

$("locateBtn").addEventListener("click", locate);
$("saveDraftBtn").addEventListener("click", saveDraft);
$("cancelBtn").addEventListener("click", () => {
  show(panel, false);
  S.urgent = false;
  setBadge();
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const send = $("sendBtn");
  const setSend = (busy) => {
    send.disabled = busy;
    send.textContent = busy ? "Enviant…" : TXT_SEND;
  };
  setSend(true);

  const problem = checkSafety();
  if (problem) {
    toast(problem);
    return setSend(false);
  }

  const data = buildAlert(S.urgent ? "urgent" : "normal");
  const hasMedia = $("photoInput").files[0] || $("audioInput").files[0];
  const r = await deliver(data);
  const c = r.confidence;
  $("confirmationText").textContent =
    `${r.message}${c ? ` Confiança inicial: ${c.score}/100 (${c.level}); no és una verificació humana.` : ""} · ${data.user}`;
  if (hasMedia) toast("Nota: en aquesta versió les fotos i els àudios no s'envien al servidor encara.");

  show(panel, false);
  show(confirmation, true);
  reveal(confirmation);
  setSend(false);
  form.reset();
  S.editingAlertId = null;
  S.coords = null;
  setLoc(null);
});

$("newReportBtn").addEventListener("click", () => {
  show(confirmation, false);
  W.scrollTo({ top: 0, behavior: "smooth" });
});

function norm(e, time) {
  if (!e || typeof e !== "object") return null;
  const { latitude, longitude, ok } = parseCoords(e);
  return {
    id: e.id || crypto.randomUUID?.() || `alert-${Date.now()}-${Math.random()}`,
    type: e.type === "urgent" ? "urgent" : "normal",
    title: e.title || e.description || "Incidència oberta",
    lat: ok ? latitude : null,
    lng: ok ? longitude : null,
    time: time || e.time || "just ara",
  };
}

async function currentAlerts() {
  const local = [...readList("far_pending_alerts"), ...readList(SHARED)].map((a) => norm(a)).filter(Boolean);
  const initial = (W.EL_FAR_INITIAL_ALERTS || []).map((a) => norm(a)).filter(Boolean);
  if (location.protocol === "file:") return [...local, ...initial];

  try {
    const res = await fetch(API(), { cache: "no-store" });
    if (!res.ok) throw 0;
    const payload = await res.json();
    W.EL_FAR_ALERTS_FRESH = true;
    const list = Array.isArray(payload?.alerts) ? payload.alerts : Array.isArray(payload) ? payload : [];
    const server = list.map((a) => norm(a, a?.receivedAt ? "fa uns segons" : "just ara")).filter(Boolean);
    const ids = new Set(server.map((a) => a.id));
    return [...local.filter((a) => !ids.has(a.id)), ...server];
  } catch {
    W.EL_FAR_ALERTS_FRESH = false;
    return [...local, ...initial];
  }
}

function initMap() {
  const box = $("liveMap");
  if (!box || !W.L) return false;
  S.liveMap = W.L.map(box, { scrollWheelZoom: false }).setView([41.387, 2.168], 13);
  W.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors",
  }).addTo(S.liveMap);
  S.markerLayer = W.L.layerGroup().addTo(S.liveMap);
  return true;
}

async function renderLiveMap() {
  if (S.refreshing) return;
  S.refreshing = true;
  const status = $("mapRefreshStatus");
  if (status) status.textContent = "Actualitzant avisos…";

  try {
    const alerts = await currentAlerts();
    const list = $("alertList");
    list.replaceChildren();
    S.markerLayer?.clearLayers();

    for (const a of alerts) {
      const urgent = a.type === "urgent";
      const located = Number.isFinite(a.lat) && Number.isFinite(a.lng);
      const marker = S.markerLayer && located
        ? W.L.circleMarker([a.lat, a.lng], {
            radius: urgent ? 9 : 7, color: "#fff", weight: 2,
            fillColor: urgent ? "#c64657" : "#146b82", fillOpacity: 0.95,
          })
            .bindPopup(el("div", "", null, el("strong", "", a.title), el("p", "", `${label(urgent)} · ${a.time}`)))
            .addTo(S.markerLayer)
        : null;

      const item = el("li", "alert-item", null,
        el("div", "alert-meta", null, el("span", `alert-pill ${a.type}`, label(urgent)), el("strong", "", a.title)),
        el("small", "", a.time));
      if (marker) {
        item.tabIndex = 0;
        item.setAttribute("role", "button");
        const focus = () => {
          S.liveMap.setView(marker.getLatLng(), Math.max(S.liveMap.getZoom(), 15));
          marker.openPopup();
        };
        item.addEventListener("click", focus);
        item.addEventListener("keydown", (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            focus();
          }
        });
      }
      list.append(item);
    }

    if (!alerts.length) list.append(el("li", "alert-item", "No hi ha avisos actius."));

    $("alertCount").textContent = `${alerts.length} actius`;
    $("alertCount").classList.toggle("urgent", alerts.some((a) => a.type === "urgent"));
    const located = alerts.filter((a) => Number.isFinite(a.lat) && Number.isFinite(a.lng));
    if (!S.hasFittedMap && located.length && S.liveMap) {
      S.liveMap.fitBounds(W.L.latLngBounds(located.map((a) => [a.lat, a.lng])), { padding: [24, 24], maxZoom: 14 });
      S.hasFittedMap = true;
    }
    if (status) {
      const n = readList(SHARED).length;
      const pending = n ? ` · ${n} ${n === 1 ? "avís pendent només en aquest dispositiu" : "avisos pendents només en aquest dispositiu"}` : "";
      status.textContent = `${W.EL_FAR_ALERTS_FRESH ? "Actualitzat" : "Sense connexió · dades locals"}${pending} · ${hhmm()}`;
    }
  } finally {
    S.refreshing = false;
  }
}

function remember(data, deliveryStatus) {
  const saved = without(MINE, data.id);
  const { id, type, category, description, user, location, createdAt } = data;
  saved.push({
    id, type, category, description, user, location,
    locationText: location ? fmt(location) : "Ubicació no disponible",
    createdAt, deliveryStatus,
  });
  writeList(MINE, saved);
}

const DELIVERY = {
  sent: "Rebut pel servidor",
  pending: "Pendent d’enviar · només en aquest dispositiu",
  rejected: "No enviat · toca per revisar",
  draft: "Esborrany · toca per editar",
};
const STATUS = { open: "Obert", checking: "En revisió", resolved: "Resolt", verification: "Verificació", false: "Fals" };

function editAlert(a) {
  S.editingAlertId = a.id;
  $("description").value = a.description || "";
  if (a.category && $("category")) $("category").value = a.category;
  S.coords = a.location ? { ...a.location } : null;
  setLoc(S.coords);
  S.urgent = a.type === "urgent";
  setBadge();
  show(panel, true);
  show(confirmation, false);
  reveal(panel, "start");
}

function renderMine() {
  const list = $("myAlertsList");
  if (!list) return;

  const accountIds = new Set(S.accountAlerts.map((a) => a.id));
  const alerts = [
    ...readList(MINE).filter((a) => !accountIds.has(a.id)).map((a) => ({ ...a, accountRecord: false })),
    ...S.accountAlerts.map((a) => ({ ...a, deliveryStatus: "sent", accountRecord: true })),
  ].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  list.replaceChildren();

  if (!alerts.length) return list.append(el("li", "draft-empty", "Encara no tens avisos guardats."));

  for (const a of alerts) {
    const canEdit = !a.accountRecord && a.deliveryStatus !== "sent";
    const short = String(a.description || TXT_NO_DETAILS).slice(0, 36);
    const state = a.accountRecord
      ? `Estat: ${STATUS[a.status] || "Obert"} · Sincronitzat amb el compte`
      : `${DELIVERY[a.deliveryStatus] || "Avís guardat"} · ${a.locationText || "Sense ubicació"}`;
    const button = el("button", "draft-button", null,
      el("span", `draft-pill ${a.type === "urgent" ? "urgent" : "normal"}`, label(a.type === "urgent")),
      el("span", "draft-copy", null, el("strong", "", short), el("small", "", state)));
    button.type = "button";
    button.disabled = !canEdit;
    if (canEdit) button.addEventListener("click", () => editAlert(a));

    const actions = el("span", "draft-actions");
    if (a.deliveryStatus === "sent" && W.EL_FAR_ALERT_CONTACT_BASE_URL) {
      const link = el("a", "contact-alert", "Missatge privat");
      link.href = `${W.EL_FAR_ALERT_CONTACT_BASE_URL}/${encodeURIComponent(a.id)}/contact`;
      actions.append(link);
    }
    if (!a.accountRecord) {
      const rm = el("button", "remove-alert", "Elimina");
      rm.type = "button";
      rm.setAttribute("aria-label", `Elimina l’avís ${String(a.description || "").slice(0, 36)} d’aquest dispositiu`);
      rm.addEventListener("click", () => {
        writeList(MINE, without(MINE, a.id));
        writeList(SHARED, without(SHARED, a.id));
        if (S.editingAlertId === a.id) S.editingAlertId = null;
        renderMine();
      });
      actions.append(rm);
    }
    list.append(el("li", "draft-item", null, button, actions));
  }
}

async function loadAccountAlerts() {
  if (!W.EL_FAR_ACCOUNT_URL) return;
  const note = $("myAlertsNote");
  const setNote = (t) => note && (note.textContent = t);
  try {
    const res = await fetch(W.EL_FAR_ACCOUNT_URL, {
      cache: "no-store",
      credentials: "same-origin",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error("No s’han pogut carregar els avisos del compte.");
    const payload = await res.json();
    S.accountAlerts = Array.isArray(payload.alerts) ? payload.alerts : [];
    setNote("Els avisos enviats amb sessió iniciada se sincronitzen al teu compte.");
    renderMine();
  } catch (err) {
    setNote(err.message || "No s’han pogut carregar els avisos del compte.");
  }
}

function saveDraft() {
  const entry = {
    id: S.editingAlertId || uuid(),
    type: S.urgent ? "urgent" : "normal",
    category: $("category").value,
    description: $("description").value.trim() || TXT_NO_DETAILS,
    user: userName(),
    location: S.coords,
    createdAt: new Date().toISOString(),
  };
  remember(entry, "draft");
  writeList(SHARED, without(SHARED, entry.id));
  S.editingAlertId = null;
  renderMine();
  toast("Avís guardat a la llista.");
}

const installBtn = $("installBtn");
W.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  S.deferredPrompt = e;
  show(installBtn, true);
});
installBtn.addEventListener("click", async () => {
  if (!S.deferredPrompt) return;
  S.deferredPrompt.prompt();
  await S.deferredPrompt.userChoice;
  S.deferredPrompt = null;
  show(installBtn, false);
});

if (initMap()) $("liveMap").querySelector(".map-fallback")?.remove();
else if ($("mapRefreshStatus")) $("mapRefreshStatus").textContent = "No s’ha pogut carregar el mapa; consulta la llista d’avisos.";

const savedName = localStorage.getItem("far_user_name");
if (savedName && $("userNameInput")) $("userNameInput").value = savedName;

migrateLegacy();
renderLiveMap();
renderMine();
loadAccountAlerts();
syncPending();
setInterval(renderLiveMap, 20000);
setInterval(syncPending, 60000);
W.addEventListener("online", syncPending);
if (W.EL_FAR_ACCOUNT_URL) setInterval(loadAccountAlerts, 30000);
$("refreshAlertsBtn")?.addEventListener("click", renderLiveMap);

if ("serviceWorker" in navigator && location.protocol !== "file:") {
  W.addEventListener("load", () => {
    navigator.serviceWorker.register(W.EL_FAR_SW_URL || "/sw.js").catch((e) => console.error("No s'ha pogut registrar el service worker.", e));
  });
}
