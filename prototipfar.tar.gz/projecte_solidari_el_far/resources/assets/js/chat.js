(() => {
  const W = window;
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content || "";
  const call = (url, body) => fetch(url, {
    method: body ? "POST" : "GET",
    headers: { Accept: "application/json", "X-CSRF-TOKEN": csrf, ...(body && { "Content-Type": "application/json" }) },
    ...(body && { body: JSON.stringify(body) }),
  });
  const when = (d) => new Date(d).toLocaleString([], { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

  const convId = W.EL_FAR_CHAT_CONVERSATION_ID;
  const messagesUrl = W.EL_FAR_CHAT_MESSAGES_URL;

  if (convId && messagesUrl) {
    const main = document.getElementById("chatMain");
    const input = document.getElementById("msgBody");
    const sendBtn = document.getElementById("msgSend");
    const sendUrl = input?.dataset.url;
    let polling = false;

    const bottom = () => main && (main.scrollTop = main.scrollHeight);

    function append(m) {
      const div = document.createElement("div");
      div.className = "msg " + (m.user_id == W.EL_FAR_ACCOUNT_USER_ID ? "me" : "them");
      // textContent/text nodes only, so user text is never parsed as HTML.
      String(m.body).split("\n").forEach((line, i) => {
        if (i) div.append(document.createElement("br"));
        div.append(document.createTextNode(line));
      });
      const meta = document.createElement("div");
      meta.className = "msg-meta";
      meta.textContent = `${m.user_name} · ${when(m.created_at)}`;
      div.append(meta);
      main?.append(div);
      bottom();
    }

    async function poll() {
      if (polling) return;
      polling = true;
      try {
        const res = await call(messagesUrl);
        if (!res.ok) return;
        const { messages = [] } = await res.json();
        main?.replaceChildren();
        messages.forEach(append);
        bottom();
      } catch (e) {
        console.error("Chat poll error", e);
      } finally {
        polling = false;
      }
    }

    async function send() {
      if (!input || !sendBtn || !sendUrl) return;
      const body = input.value.trim();
      if (!body) return;
      sendBtn.disabled = true;
      try {
        const res = await call(sendUrl, { body });
        if (!res.ok) throw 0;
        append((await res.json()).message);
        input.value = "";
        input.style.height = "auto";
      } catch {
        alert("No s’ha pogut enviar el missatge.");
      } finally {
        sendBtn.disabled = false;
      }
    }

    sendBtn?.addEventListener("click", send);
    input?.addEventListener("input", () => {
      input.style.height = "auto";
      input.style.height = input.scrollHeight + "px";
    });
    input?.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    });

    poll();
    setInterval(poll, 4000);
  }

  document.getElementById("newConvBtn")?.addEventListener("click", async () => {
    const users = (await (await call(W.EL_FAR_CHAT_USERS_URL)).json()).users || [];
    if (!users.length) return alert("No hi ha altres usuaris disponibles.");

    const list = users.map((u) => `${u.id}: ${u.name} (${u.role})`).join("\n");
    const answer = prompt("Selecciona l’ID de l’usuari amb qui voleu parlar:\n\n" + list);
    if (!answer) return;
    const id = parseInt(answer.trim(), 10);
    if (!users.some((u) => u.id === id)) return alert("Usuari no trobat.");

    try {
      const data = await (await call(W.EL_FAR_CHAT_API_URL, { participant_ids: [id], body: "Hola! Vull iniciar una conversa." })).json();
      if (data.conversation) location.href = "/chat/conversations/" + data.conversation.id;
      else alert(data.message || "No s’ha pogut iniciar la conversa.");
    } catch {
      alert("Error al iniciar la conversa.");
    }
  });
})();
