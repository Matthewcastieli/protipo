<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#102b3f">
  <title>Conversa privada · El Far</title>
  <link rel="stylesheet" href="{{ asset('css/admin.css') }}?v=2">
  <style>
    .conversation-panel { padding: 20px; }
    .conversation-messages { display: flex; flex-direction: column; gap: 12px; margin: 18px 0; }
    .conversation-message { max-width: min(720px, 90%); padding: 12px 14px; border-radius: 12px; background: #f3f7f9; overflow-wrap: anywhere; white-space: pre-wrap; }
    .conversation-message.admin { align-self: flex-end; background: #e4f2ff; }
    .conversation-message.reporter { align-self: flex-start; background: #f4f4f4; }
    .conversation-message small { display: block; margin-top: 6px; color: #647987; }
    .conversation-form { display: grid; gap: 10px; }
    .conversation-form textarea { min-height: 110px; }
    .conversation-alert { margin-top: 8px; color: #647987; }
  </style>
</head>
<body>
  <header class="topbar">
    <a class="brand" href="{{ route('admin.alerts.index') }}"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Gestió d’avisos</small></span></a>
    <a class="button secondary" href="{{ route('admin.alerts.index') }}">Torna als avisos</a>
  </header>
  <main class="dashboard">
    <div class="page-heading">
      <div>
        <p class="eyebrow">CONVERSA PRIVADA</p>
        <h1>Reportant anònim</h1>
        <p class="muted">Avís {{ $alert->id }} · {{ $alert->description ?: 'Sense detalls addicionals' }}</p>
      </div>
    </div>
    @if (session('status-message'))
      <p class="notice success" role="status">{{ session('status-message') }}</p>
    @endif
    @if ($errors->any())
      <p class="notice error" role="alert">{{ $errors->first() }}</p>
    @endif
    <section class="panel conversation-panel">
      <p class="conversation-alert">No es mostra la identitat del reportant en aquesta conversa. Fes servir aquest canal per demanar només la informació necessària.</p>
      <div class="conversation-messages" aria-live="polite">
        @forelse ($messages as $message)
          <article class="conversation-message {{ $message->sender_type }}">
            {{ $message->body }}
            <small>
              {{ $message->sender_type === 'reporter' ? 'Reportant anònim' : 'Equip El Far' }}
              · {{ $message->created_at?->format('d/m/Y H:i') }}
              @if ($message->sender_type === 'admin' && $message->admin_email)
                · {{ $message->admin_email }}
              @endif
            </small>
          </article>
        @empty
          <p class="muted">Encara no hi ha missatges.</p>
        @endforelse
      </div>
      <form class="conversation-form" method="post" action="{{ route('admin.alerts.conversation.store', $alert) }}">
        @csrf
        <label for="body">Resposta</label>
        <textarea id="body" name="body" maxlength="3000" required>{{ old('body') }}</textarea>
        <button class="button primary" type="submit">Envia la resposta</button>
      </form>
    </section>
  </main>
</body>
</html>
