<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#102b3f">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="format-detection" content="telephone=no">
  <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('icons/apple-touch-icon.png') }}">
  <title>Avisos resolts · El Far</title>
  <link rel="stylesheet" href="{{ asset('css/admin.css') }}?v=2">
</head>
<body>
  <header class="topbar">
    <a class="brand" href="{{ route('home') }}"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Gestió d’avisos</small></span></a>
    <a class="button secondary" href="{{ route('admin.alerts.index') }}">Tots els avisos</a>
    <form method="post" action="{{ route('admin.logout') }}">
      @csrf
      <button class="button secondary" type="submit">Tanca la sessió</button>
    </form>
  </header>
  <main class="dashboard">
    <div class="page-heading">
      <div><p class="eyebrow">ARXIU D’AVISOS RESOLTS</p><h1>Avisos tancats</h1><p class="muted">Avisos amb estat Resolt o Fals. Consulta l’historial de resolució.</p></div>
    </div>
    <section class="summary-grid" aria-label="Resum d’avisos resolts">
      <div class="summary-card"><span>Resolts</span><strong>{{ $counts['resolved'] ?? 0 }}</strong></div>
      <div class="summary-card"><span>Marats com a falsos</span><strong>{{ $counts['false'] ?? 0 }}</strong></div>
    </section>
    @if (session('status-message'))
      <p class="notice success" role="status">{{ session('status-message') }}</p>
    @endif
    @if ($errors->any())
      <p class="notice error" role="alert">{{ $errors->first() }}</p>
    @endif
    <section class="panel">
      <form class="filter-form" method="get" action="{{ route('admin.alerts.resolved') }}">
        <label for="category-filter">Categoria</label>
        <select id="category-filter" name="category">
          <option value="">Totes</option>
          @foreach ($categories as $key => $label)
            <option value="{{ $key }}" @selected($filters['category'] === $key)>{{ $label }}</option>
          @endforeach
        </select>
        <label for="confidence-filter">Confiança</label>
        <select id="confidence-filter" name="confidence">
          <option value="">Tots</option>
          @foreach (['high' => 'Alta', 'medium' => 'Mitjana', 'low' => 'Baixa'] as $key => $label)
            <option value="{{ $key }}" @selected($filters['confidence'] === $key)>{{ $label }}</option>
          @endforeach
        </select>
        <label for="type-filter">Urgència</label>
        <select id="type-filter" name="type">
          <option value="">Totes</option>
          <option value="urgent" @selected($filters['type'] === 'urgent')>Urgent</option>
          <option value="normal" @selected($filters['type'] === 'normal')>Normal</option>
        </select>
        <label for="date-from">Des de</label>
        <input id="date-from" type="date" name="date_from" value="{{ $filters['date_from'] }}">
        <label for="date-to">Fins a</label>
        <input id="date-to" type="date" name="date_to" value="{{ $filters['date_to'] }}">
        <button class="button secondary" type="submit">Filtra</button>
      </form>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Avís</th><th>Ubicació GPS</th><th>Confiança algorítmica</th><th>Rebut</th><th>Estat i decisió humana</th></tr></thead>
          <tbody>
          @forelse ($alerts as $alert)
            <tr>
              <td>
                <strong>{{ $alert->description ?: 'Incidència sense detalls' }}</strong>
                <small>ID {{ $alert->id }} · {{ $categories[$alert->category] ?? $alert->category }} · {{ $alert->type === 'urgent' ? 'Urgent' : 'Normal' }} · Risc {{ $alert->risk_level }}</small>
                <small>Reporter anònim {{ $alert->reporter_id ? substr($alert->reporter_id, 0, 8) : 'no identificat' }}</small>
              </td>
              <td>
                @if ($alert->latitude !== null && $alert->longitude !== null)
                  {{ number_format((float) $alert->latitude, 6) }}, {{ number_format((float) $alert->longitude, 6) }}
                  <small>Precisió GPS reportada ±{{ $alert->accuracy ?? '—' }} m</small>
                @else
                  <span class="muted">No indicada</span>
                @endif
              </td>
              <td>
                @if ($alert->confidence_score !== null)
                  <span class="status-chip confidence-{{ $alert->confidence_level }}">{{ $alert->confidence_score }}/100 · {{ ['high' => 'Alta', 'medium' => 'Mitjana', 'low' => 'Baixa'][$alert->confidence_level] ?? $alert->confidence_level }}</span>
                  <small>Emissor: {{ $alert->latestVerification->user_reliability_score ?? '—' }}/100 · Incidents propers: {{ count($alert->latestVerification->evidence_details['nearby_matches'] ?? []) }}</small>
                  <small>Última anàlisi: {{ $alert->verification_updated_at?->format('d/m/Y H:i:s') ?? '—' }}</small>
                @else
                  <span class="muted">No calculada</span>
                @endif
              </td>
              <td>{{ $alert->received_at?->format('d/m/Y H:i') ?? '—' }}</td>
              <td>
                <span class="status-chip status-{{ $alert->status }}">{{ $statuses[$alert->status] ?? $alert->status }}</span>
                <small>Resolt el: {{ $alert->verification_updated_at?->format('d/m/Y H:i') ?? '—' }}</small>
                <small>Decisió humana: {{ $alert->latestVerificationResult ? ['confirmed' => 'Confirmat', 'false_report' => 'Avís fals', 'inconclusive' => 'Inconclús'][$alert->latestVerificationResult->result] : 'Pendent' }}</small>
                @if ($alert->latestVerificationResult)
                  <small>{{ $alert->latestVerificationResult->verifier_id }} · {{ $alert->latestVerificationResult->created_at?->format('d/m/Y H:i') }}</small>
                  @if ($alert->latestVerificationResult->notes)
                    <small>{{ $alert->latestVerificationResult->notes }}</small>
                  @endif
                @endif
                <details class="verify-details">
                  <summary>Registrar decisió humana</summary>
                  <form method="post" action="{{ route('admin.alerts.verify', $alert) }}">
                    @csrf
                    <label class="sr-only" for="result-{{ $loop->index }}">Resultat de verificació humana</label>
                    <select id="result-{{ $loop->index }}" name="result" required>
                      <option value="">Selecciona el resultat</option>
                      <option value="confirmed">Confirmat</option>
                      <option value="false_report">Avís fals</option>
                      <option value="inconclusive">Inconclús</option>
                    </select>
                    <label class="sr-only" for="notes-{{ $loop->index }}">Notes de verificació</label>
                    <textarea id="notes-{{ $loop->index }}" name="notes" maxlength="1200" placeholder="Notes (opcional)"></textarea>
                    <button class="button secondary" type="submit">Registra decisió</button>
                  </form>
                </details>
              </td>
            </tr>
          @empty
            <tr><td class="empty" colspan="5">No s’han trobat avisos resolts.</td></tr>
          @endforelse
          </tbody>
        </table>
      </div>
      <div class="pagination">{{ $alerts->links() }}</div>
    </section>
  </main>
</body>
</html>
