<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <link rel="apple-touch-icon" sizes="180x180" href="{{ asset('icons/apple-touch-icon.png') }}">
  <title>Crea un compte · El Far</title>
  <link rel="stylesheet" href="{{ asset('css/admin.css') }}?v=2">
</head>
<body>
  <main class="auth-shell">
    <a class="brand" href="{{ route('home') }}"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Compte personal</small></span></a>
    <section class="auth-card">
      <p class="eyebrow">COMPTE PERSONAL</p>
      <h1>Crea un compte</h1>
      <p class="muted">El registre és opcional. També pots enviar avisos sense iniciar sessió.</p>
      @if ($errors->any())
        <p class="notice error" role="alert">{{ $errors->first() }}</p>
      @endif
      <form method="post" action="{{ route('account.register.store') }}">
        @csrf
        <label for="name">Nom</label>
        <input id="name" name="name" type="text" value="{{ old('name') }}" maxlength="80" autocomplete="name" required autofocus>
        <label for="email">Correu electrònic</label>
        <input id="email" name="email" type="email" value="{{ old('email') }}" maxlength="255" autocomplete="email" required>
        <label for="password">Contrasenya (com a mínim 10 caràcters)</label>
        <input id="password" name="password" type="password" minlength="10" autocomplete="new-password" required>
        <label for="password_confirmation">Repeteix la contrasenya</label>
        <input id="password_confirmation" name="password_confirmation" type="password" minlength="10" autocomplete="new-password" required>
        <button class="button primary" type="submit">Crea el compte</button>
      </form>
    </section>
    <p>Ja tens compte? <a class="back-link" href="{{ route('account.login') }}">Inicia sessió</a></p>
    <a class="back-link" href="{{ route('home') }}">← Torna a El Far</a>
  </main>
</body>
</html>
