<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <title>Sol·licituds d’ajuda · El Far</title>
  <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
  <link rel="icon" href="{{ asset('icons/icon.svg') }}" type="image/svg+xml">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}?v=14">
  <link rel="stylesheet" href="{{ asset('css/chat.css') }}?v=3">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <style>
    .hr-list { display: flex; flex-direction: column; gap: 0.5rem; }
    .hr-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 1rem; }
    .hr-card.open { border-left: 4px solid #48bb78; }
    .hr-card.closed { border-left: 4px solid #a0aec0; opacity: 0.85; }
    .hr-title { font-weight: 700; font-size: 1rem; color: #1a202c; margin-bottom: 0.25rem; }
    .hr-meta { font-size: 0.75rem; color: #718096; display: flex; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 0.5rem; }
    .hr-desc { font-size: 0.9rem; color: #2d3748; margin-bottom: 0.75rem; }
    .hr-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .btn { border: none; border-radius: 6px; padding: 0.45rem 0.9rem; font-size: 0.85rem; font-weight: 600; cursor: pointer; }
    .btn-primary { background: #102b3f; color: #fff; }
    .btn-secondary { background: #edf2f7; color: #2d3748; }
    .btn-success { background: #48bb78; color: #fff; }
    .btn-danger { background: #e53e3e; color: #fff; }
    .btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .new-hr-btn { display: inline-flex; align-items: center; gap: 0.4rem; background: #102b3f; color: #fff; border: none; border-radius: 8px; padding: 0.7rem 1.2rem; font-weight: 600; font-size: 0.95rem; cursor: pointer; margin-bottom: 1rem; }
    .responses-list { margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; }
    .response-item { display: flex; gap: 0.75rem; padding: 0.6rem 0; border-bottom: 1px solid #f7fafc; }
    .response-item:last-child { border-bottom: none; }
    .response-avatar { width: 32px; height: 32px; border-radius: 50%; background: #cbd5e0; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.85rem; flex-shrink: 0; }
    .response-body { flex: 1; font-size: 0.88rem; color: #2d3748; }
    .response-meta { font-size: 0.7rem; color: #a0aec0; margin-top: 0.15rem; }
    .respond-form { margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e2e8f0; display: flex; flex-direction: column; gap: 0.5rem; }
    .respond-form textarea { width: 100%; min-height: 80px; padding: 0.6rem; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 0.9rem; font-family: inherit; resize: vertical; }
    .status-badge { display: inline-block; font-size: 0.7rem; padding: 0.1rem 0.4rem; border-radius: 4px; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600; }
    .status-open { background: #c6f6d5; color: #22543d; }
    .status-closed { background: #fed7d7; color: #742a2a; }
  </style>
</head>
<body>
<header class="topbar">
  <a class="brand" href="/" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <nav class="account-nav" aria-label="Compte">
    @if ($accountUser)
      <span class="account-greeting">{{ $accountUser->name }}</span>
      <a class="account-link" href="{{ route('chat.index') }}">Xat</a>
      <a class="account-link" href="{{ route('chat.help_requests.index') }}">Ajuda</a>
      @if ($accountUser->isStaff())
        <a class="account-link" href="{{ route('chat.workers') }}">Treballadors</a>
      @endif
      @if ($accountUser->isAnonymous())
        <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
        <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
      @else
        <form method="post" action="{{ route('account.logout') }}">
          @csrf
          <button class="account-link" type="submit">Surt</button>
        </form>
      @endif
    @else
      <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
      <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
    @endif
  </nav>
</header>

<main style="max-width: 700px; margin: 0 auto; padding: 1rem;">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
    <h1 style="margin: 0; font-size: 1.25rem; color: #102b3f;">Sol·licituds d’ajuda</h1>
    @if ($accountUser->hasRole('worker') || $accountUser->hasRole('volunteer') || $accountUser->hasRole('admin'))
      <button class="new-hr-btn" type="button" id="newHRBtn">+ Sol·licita ajuda</button>
    @endif
  </div>

  <div id="hrList" class="hr-list">
    @if ($helpRequests === [])
      <div style="text-align: center; color: #718096; padding: 3rem 1rem;">
        <p>Sense sol·licituds d’ajuda.</p>
      </div>
    @else
      @foreach ($helpRequests as $hr)
        <div class="hr-card {{ $hr['status'] }}">
          <div style="display: flex; justify-content: space-between; align-items: start; gap: 0.5rem; margin-bottom: 0.25rem;">
            <div class="hr-title">{{ $hr['title'] }}</div>
            <span class="status-badge {{ $hr['status'] === 'open' ? 'status-open' : 'status-closed' }}">{{ $hr['status'] === 'open' ? 'Oberta' : 'Tancada' }}</span>
          </div>
          <div class="hr-meta">
            <span>{{ $hr['user_name'] }} ({{ $hr['user_role'] }})</span>
            <span>{{ \Carbon\Carbon::parse($hr['created_at'])->format('d/m/Y H:i') }}</span>
            <span>{{ $hr['category'] }}</span>
            <span>{{ $hr['response_count'] }} resposta{{ $hr['response_count'] !== 1 ? 's' : '' }}</span>
          </div>
          <div class="hr-desc">{{ $hr['description'] }}</div>

          <div class="responses-list">
            @if ($hr['response_count'] > 0)
              @php $responses = \App\Models\HelpRequest::find($hr['id'])->responses()->with('user')->orderBy('created_at')->get(); @endphp
              @foreach ($responses as $resp)
                <div class="response-item">
                  <div class="response-avatar">{{ strtoupper(substr($resp->user->name, 0, 1)) }}</div>
                  <div>
                    <div class="response-body">{{ $resp->body }}</div>
                    <div class="response-meta">{{ $resp->user->name }} · {{ \Carbon\Carbon::parse($resp->created_at)->format('d/m H:i') }}</div>
                  </div>
                </div>
              @endforeach
            @else
              <div style="font-size: 0.8rem; color: #a0aec0; font-style: italic;">Sense respostes encara.</div>
            @endif
          </div>

          @if ($hr['status'] === 'open')
            <form class="respond-form" data-url="{{ route('chat.help_requests.respond', $hr['id']) }}" data-close-url="{{ route('chat.help_requests.close', $hr['id']) }}">
              <textarea name="body" placeholder="Escriviu una resposta…" required></textarea>
              <div style="display: flex; gap: 0.5rem;">
                <button class="btn btn-primary" type="submit">Envia resposta</button>
                <button class="btn btn-danger" type="button" onclick="closeHR({{ $hr['id'] }}, this)">Tanca sol·licitud</button>
              </div>
              <div class="hr-msg" style="margin-top: 0.5rem; font-size: 0.8rem;"></div>
            </form>
          @endif
        </div>
      @endforeach
    @endif
  </div>
</main>

<script src="{{ asset('js/chat.js') }}?v=2"></script>
<script>
  window.EL_FAR_HELP_REQUESTS_URL = "{{ route('chat.help_requests.index') }}";
  window.EL_FAR_ACCOUNT_USER_ID = {{ $accountUser->id ?? 'null' }};
  window.EL_FAR_ACCOUNT_IS_STAFF = {{ ($accountUser->hasRole('worker') || $accountUser->hasRole('admin')) ? 'true' : 'false' }};
  window.EL_FAR_ACCOUNT_IS_WORKER_OR_VOLUNTEER = {{ (($accountUser->hasRole('worker') || $accountUser->hasRole('volunteer') || $accountUser->hasRole('admin')) ? 'true' : 'false') }};
  function closeHR(id, btn) {
    if (!confirm('Voleu tancar aquesta sol·licitud d’ajuda?')) return;
    fetch(`{{ route('chat.help_requests.close', 0) }}/`.replace('/0/', '/' + id + '/'), { method: 'POST', headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content, 'Accept': 'application/json' }, body: JSON.stringify({}) })
      .then(r => r.json()).then(() => location.reload()).catch(() => alert('Error al tancar.'));
  }
</script>
</body>
</html>
