<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <title>Conversacions · El Far</title>
  <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
  <link rel="icon" href="{{ asset('icons/icon.svg') }}" type="image/svg+xml">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}?v=14">
  <link rel="stylesheet" href="{{ asset('css/chat.css') }}?v=3">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <style>
    .conv-list { display: flex; flex-direction: column; gap: 0; }
    .conv-item { display: flex; align-items: center; padding: 0.85rem 1rem; border-bottom: 1px solid #e2e8f0; background: #fff; text-decoration: none; color: inherit; }
    .conv-item:hover { background: #f7fafc; }
    .conv-item.active { background: #e6f0ff; border-left: 4px solid #102b3f; padding-left: 0.85rem; }
    .conv-avatar { width: 48px; height: 48px; border-radius: 50%; background: #cbd5e0; display: flex; align-items: center; justify-content: center; color: #fff; font-weight: 700; font-size: 1.25rem; margin-right: 0.85rem; flex-shrink: 0; }
    .conv-info { flex: 1; min-width: 0; }
    .conv-title { font-weight: 700; font-size: 0.98rem; color: #1a202c; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .conv-subtitle { font-size: 0.8rem; color: #718096; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 0.15rem; }
    .conv-time { font-size: 0.75rem; color: #a0aec0; margin-left: 0.5rem; }
    .empty-state { text-align: center; color: #718096; padding: 3rem 1rem; }
    .new-conv-btn { display: inline-flex; align-items: center; gap: 0.4rem; background: #102b3f; color: #fff; border: none; border-radius: 8px; padding: 0.7rem 1.2rem; font-weight: 600; font-size: 0.95rem; cursor: pointer; margin-bottom: 1rem; }
    .new-conv-btn:hover { opacity: 0.9; }
    .role-badge { display: inline-block; font-size: 0.7rem; padding: 0.1rem 0.4rem; border-radius: 4px; background: #e2e8f0; color: #2d3748; margin-left: 0.3rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .badge-pill { display: inline-block; font-size: 0.7rem; padding: 0.1rem 0.4rem; border-radius: 8px; background: #48bb78; color: #fff; }
  </style>
</head>
<body>
<header class="topbar">
  <a class="brand" href="/" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <nav class="account-nav" aria-label="Compte">
    @if ($accountUser)
      <span class="account-greeting">{{ $accountUser->name }}</span>
      <a class="account-link" href="{{ route('chat.index') }}">Xat</a>
      <a class="account-link" href="{{ route('chat.help_requests.index') }}">Ajuda</a>
      @if ($accountUser->hasRole('worker') || $accountUser->hasRole('admin'))
        <a class="account-link" href="{{ route('chat.workers') }}">Treballadors</a>
      @endif
      @if ($accountUser->isAnonymous())
        <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
        <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
      @else
        <form method="post" action="{{ route('account.logout') }}">
          @csrf
          <button class="account-link" type="submit">Surt</button>
        </form>
      @endif
    @else
      <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
      <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
    @endif
  </nav>
</header>

<main style="max-width: 700px; margin: 0 auto; padding: 1rem;">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
    <h1 style="margin: 0; font-size: 1.25rem; color: #102b3f;">Conversacions</h1>
    <button class="new-conv-btn" type="button" id="newConvBtn">+ Nova conversa</button>
  </div>

  <div id="convList" class="conv-list">
    @if ($conversations === [])
      <div class="empty-state">
        <p>Sense conversacions encara.</p>
        <p style="font-size: 0.85rem; margin-top: 0.5rem;">Inicia una conversa amb un altre usuari, treballador o voluntari.</p>
      </div>
    @else
      @foreach ($conversations as $conv)
        <a href="{{ route('chat.conversations.show', $conv['id']) }}" class="conv-item{{ $conv['id'] === old('conversation_id') ? ' active' : '' }}">
          <div class="conv-avatar">{{ strtoupper(substr($conv['title'] ?? $conv['participants'][0]['name'] ?? '?', 0, 1)) }}</div>
          <div class="conv-info">
            <div class="conv-title">{{ $conv['title'] ?? ($conv['participants'][0]['name'] ?? 'Usuari desconegut') }}</div>
            <div class="conv-subtitle">
              @foreach ($conv['participants'] as $p)
                {{ $p['name'] }}<span class="role-badge">{{ $p['role'] }}</span>
              @endforeach
            </div>
          </div>
          @if ($conv['last_message_at'])
            <div class="conv-time">{{ \Carbon\Carbon::parse($conv['last_message_at'])->format('d/m H:i') }}</div>
          @endif
        </a>
      @endforeach
    @endif
  </div>
</main>

<script src="{{ asset('js/chat.js') }}?v=2"></script>
<script>window.EL_FAR_CHAT_API_URL = "{{ route('chat.conversations.store') }}"; window.EL_FAR_CHAT_USERS_URL = "{{ route('chat.users') }}";</script>
</body>
</html>
