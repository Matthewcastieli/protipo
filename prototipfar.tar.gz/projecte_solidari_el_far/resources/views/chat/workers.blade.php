<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <title>Treballadors i voluntaris · El Far</title>
  <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
  <link rel="icon" href="{{ asset('icons/icon.svg') }}" type="image/svg+xml">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}?v=14">
  <link rel="stylesheet" href="{{ asset('css/chat.css') }}?v=3">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <style>
    .user-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 1rem; display: flex; align-items: center; gap: 0.85rem; margin-bottom: 0.5rem; }
    .user-avatar { width: 48px; height: 48px; border-radius: 50%; background: #cbd5e0; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1.25rem; flex-shrink: 0; }
    .user-info { flex: 1; min-width: 0; }
    .user-name { font-weight: 700; font-size: 0.98rem; color: #1a202c; }
    .user-role { font-size: 0.8rem; color: #718096; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 0.15rem; }
    .chat-btn { background: #102b3f; color: #fff; border: none; border-radius: 6px; padding: 0.45rem 0.9rem; font-size: 0.85rem; font-weight: 600; cursor: pointer; white-space: nowrap; }
    .chat-btn:hover { opacity: 0.9; }
    .empty-state { text-align: center; color: #718096; padding: 3rem 1rem; }
    .role-group { margin-bottom: 1.5rem; }
    .role-group-title { font-size: 0.85rem; font-weight: 700; color: #102b3f; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.5rem; padding-left: 0.5rem; border-left: 3px solid #102b3f; }
  </style>
</head>
<body>
<header class="topbar">
  <a class="brand" href="/" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <nav class="account-nav" aria-label="Compte">
    @if ($accountUser)
      <span class="account-greeting">{{ $accountUser->name }}</span>
      <a class="account-link" href="{{ route('chat.index') }}">Xat</a>
      <a class="account-link" href="{{ route('chat.help_requests.index') }}">Ajuda</a>
      <a class="account-link" href="{{ route('chat.workers') }}">Treballadors</a>
      <form method="post" action="{{ route('account.logout') }}">
        @csrf
        <button class="account-link" type="submit">Surt</button>
      </form>
    @else
      <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
      <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
    @endif
  </nav>
</header>

<main style="max-width: 700px; margin: 0 auto; padding: 1rem;">
  <h1 style="font-size: 1.25rem; color: #102b3f; margin-bottom: 1rem;">Treballadors i voluntaris</h1>
  <p style="font-size: 0.9rem; color: #4a5568; margin-bottom: 1.5rem;">Trobeu i inicialitze una conversa amb el personal disponible.</p>

  <div class="role-group">
    <div class="role-group-title">Treballadors</div>
    @foreach ($workers as $w)
      <a href="{{ route('chat.conversations.show', 0) }}" class="user-card" onclick="startConv({{ $w['id'] }}, event)">
        <div class="user-avatar">{{ strtoupper(substr($w['name'], 0, 1)) }}</div>
        <div class="user-info">
          <div class="user-name">{{ $w['name'] }}</div>
          <div class="user-role">{{ $w['role'] }}</div>
        </div>
        <button class="chat-btn" type="button" onclick="event.stopPropagation(); startConv({{ $w['id'] }}, event)">Inicia xat</button>
      </a>
    @empty
      <p style="font-size: 0.85rem; color: #a0aec0;">Sense treballadors registrats.</p>
    @endforeach
  </div>

  <div class="role-group">
    <div class="role-group-title">Voluntaris</div>
    @foreach ($volunteers as $v)
      <a href="{{ route('chat.conversations.show', 0) }}" class="user-card" onclick="startConv({{ $v['id'] }}, event)">
        <div class=user-avatar>{{ strtoupper(substr($v['name'], 0, 1)) }}</div>
        <div class="user-info">
          <div class="user-name">{{ $v['name'] }}</div>
          <div class="user-role">{{ $v['role'] }}</div>
        </div>
        <button class="chat-btn" type="button" onclick="event.stopPropagation(); startConv({{ $v['id'] }}, event)">Inicia xat</button>
      </a>
    @empty
      <p style="font-size: 0.85rem; color: #a0aec0;">Sense voluntaris registrats.</p>
    @endforeach
  </div>
</main>

<script src="{{ asset('js/chat.js') }}?v=2"></script>
<script>
  window.EL_FAR_CHAT_CONVERSATIONS_URL = "{{ route('chat.conversations.index') }}";
  window.EL_FAR_CHAT_STORE_URL = "{{ route('chat.conversations.store') }}";
  window.EL_FAR_CHAT_USERS_URL = "{{ route('chat.users') }}";
  window.EL_FAR_ACCOUNT_USER_ID = {{ $accountUser->id ?? 'null' }};
  function startConv(otherUserId, event) {
    event.preventDefault();
    const body = { participant_ids: [otherUserId], body: 'Hola! Vull iniciar una conversa.' };
    fetch(window.EL_FAR_CHAT_STORE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
      body: JSON.stringify(body)
    }).then(r => r.json()).then(data => {
      if (data.conversation) {
        location.href = window.EL_FAR_CHAT_CONVERSATIONS_URL.replace('/conversations', '') + 'chat/conversations/' + data.conversation.id;
      } else {
        alert(data.message || 'No s’ha pogut iniciar la conversa.');
      }
    }).catch(() => alert('Error al iniciar la conversa.'));
  }
</script>
</body>
</html>
