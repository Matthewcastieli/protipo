<!doctype html>
<html lang="ca">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#102b3f">
  <title>Xat · El Far</title>
  <link rel="manifest" href="{{ asset('manifest.webmanifest') }}">
  <link rel="icon" href="{{ asset('icons/icon.svg') }}" type="image/svg+xml">
  <link rel="stylesheet" href="{{ asset('css/app.css') }}?v=14">
  <link rel="stylesheet" href="{{ asset('css/chat.css') }}?v=3">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <style>
    .chat-container { display: flex; flex-direction: column; height: 100vh; max-height: 100vh; }
    .chat-header { padding: 0.75rem 1rem; border-bottom: 1px solid #e2e8f0; background: #fff; display: flex; justify-content: space-between; align-items: center; }
    .chat-back { background: none; border: none; font-size: 1rem; cursor: pointer; color: #102b3f; padding: 0.25rem; }
    .chat-main { flex: 1; overflow-y: auto; padding: 1rem; display: flex; flex-direction: column; gap: 0.75rem; background: #f3f7f9; }
    .msg { max-width: 75%; padding: 0.6rem 0.9rem; border-radius: 12px; font-size: 0.95rem; line-height: 1.4; }
    .msg.me { background: #102b3f; color: #fff; align-self: flex-end; border-bottom-right-radius: 4px; }
    .msg.them { background: #fff; color: #1a202c; align-self: flex-start; border-bottom-left-radius: 4px; border: 1px solid #e2e8f0; }
    .msg-meta { font-size: 0.7rem; opacity: 0.7; margin-top: 0.25rem; }
    .msg-input-area { padding: 0.75rem 1rem; border-top: 1px solid #e2e8f0; background: #fff; display: flex; gap: 0.5rem; }
    .msg-input { flex: 1; padding: 0.6rem 0.9rem; border: 1px solid #cbd5e0; border-radius: 8px; font-size: 0.95rem; }
    .msg-send { background: #102b3f; color: #fff; border: none; border-radius: 8px; padding: 0.6rem 1rem; font-weight: 600; cursor: pointer; }
    .msg-send:disabled { opacity: 0.5; cursor: not-allowed; }
    .empty-state { align-self: center; color: #718096; font-size: 0.95rem; padding-top: 2rem; }
    .conversation-title { font-weight: 700; font-size: 1.1rem; color: #102b3f; }
    .participants-chip { font-size: 0.8rem; color: #718096; margin-top: 0.2rem; }
    .role-badge { display: inline-block; font-size: 0.7rem; padding: 0.1rem 0.4rem; border-radius: 4px; background: #e2e8f0; color: #2d3748; margin-left: 0.3rem; text-transform: uppercase; letter-spacing: 0.05em; }
    .system-msg { text-align: center; font-size: 0.8rem; color: #a0aec0; margin: 0.5rem 0; }
  </style>
</head>
<body>
<header class="topbar">
  <a class="brand" href="/" aria-label="Inici El Far"><span class="brand-mark">F</span><span><b>EL FAR</b><small>Projecte Solidari</small></span></a>
  <nav class="account-nav" aria-label="Compte">
    @if ($accountUser)
      <span class="account-greeting">{{ $accountUser->name }}</span>
      <a class="account-link" href="{{ route('chat.index') }}">Xat</a>
      <a class="account-link" href="{{ route('chat.help_requests.index') }}">Ajuda</a>
      @if ($accountUser->isAnonymous())
        <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
        <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
      @else
        <form method="post" action="{{ route('account.logout') }}">
          @csrf
          <button class="account-link" type="submit">Surt</button>
        </form>
      @endif
    @else
      <a class="account-link" href="{{ route('account.login') }}">Inicia sessió</a>
      <a class="account-link account-link-primary" href="{{ route('account.register') }}">Crea un compte</a>
    @endif
  </nav>
</header>

<main class="chat-container">
  <div class="chat-header">
    <div>
      <div class="conversation-title">{{ $conversation->title ?? 'Conversació' }}</div>
      <div class="participants-chip">
        @foreach ($participants as $p)
          <span>{{ $p['name'] }}<span class="role-badge">{{ $p['role'] }}</span></span>
        @endforeach
      </div>
    </div>
    <a class="account-link" href="{{ route('chat.index') }}">Torna a les conversacions</a>
  </div>

  <div class="chat-main" id="chatMain">
    @if ($messages === [])
      <div class="empty-state">Sense missatges encara. Escriviu el primer.</div>
    @else
      @foreach ($messages as $msg)
        <div class="msg {{ $msg['user_id'] === $accountUser->id ? 'me' : 'them' }}">
          {!! nl2br(e($msg['body'])) !!}
          <div class="msg-meta">{{ $msg['user_name'] }} · {{ \Carbon\Carbon::parse($msg['created_at'])->format('d/m H:i') }}</div>
        </div>
      @endforeach
    @endif
  </div>

  <div class="msg-input-area">
    <textarea id="msgBody" class="msg-input" rows="1" placeholder="Escriviu un missatge…" data-url="{{ route('chat.messages.store', $conversation->id) }}"></textarea>
    <button id="msgSend" class="msg-send" type="button">Envia</button>
  </div>
</main>

<script src="{{ asset('js/chat.js') }}?v=2"></script>
<script>window.EL_FAR_CHAT_CONVERSATION_ID = {{ $conversation->id }}; window.EL_FAR_CHAT_MESSAGES_URL = "{{ route('chat.messages.index', $conversation->id) }}"; window.EL_FAR_ACCOUNT_USER_ID = {{ $accountUser->id ?? 'null' }};</script>
</body>
</html>
